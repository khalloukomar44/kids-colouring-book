package com.kids.colouringbook.ui.screens

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kids.colouringbook.data.AnimalData
import com.kids.colouringbook.drawing.SvgOutlineRenderer
import com.kids.colouringbook.model.AnimalPage
import com.kids.colouringbook.sound.SoundEffects
import com.kids.colouringbook.ui.theme.SlateMuted
import com.kids.colouringbook.ui.theme.SlateText
import kotlin.random.Random

@Composable
fun HomeScreen(
    onSelectAnimal: (String) -> Unit,
    onOpenGallery: () -> Unit
) {
    var selectedCategoryId by remember { mutableStateOf("all") }

    val filteredAnimals = remember(selectedCategoryId) {
        if (selectedCategoryId == "all") {
            AnimalData.ANIMAL_PAGES
        } else {
            AnimalData.ANIMAL_PAGES.filter { it.category == selectedCategoryId }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFFFEF3C7), Color(0xFFFFFBEB), Color(0xFFFEF3C7))
                )
            )
    ) {
        // App Header Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xFFF59E0B), Color(0xFFEA580C), Color(0xFFF59E0B))
                    )
                )
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🎨", fontSize = 26.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Colouring Book for Kids",
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            color = Color.White
                        )
                    }
                    Text(
                        text = "Pick a cute animal & start colouring!",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = Color(0xFFFEF3C7)
                    )
                }

                // Gallery Button in Header
                Box(
                    modifier = Modifier
                        .shadow(3.dp, RoundedCornerShape(20.dp))
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.White)
                        .clickable {
                            SoundEffects.playPop()
                            onOpenGallery()
                        }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.PhotoLibrary,
                            contentDescription = "Gallery",
                            tint = Color(0xFFF59E0B),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Gallery",
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            color = SlateText
                        )
                    }
                }
            }
        }

        // Surprise Me / Quick Start Banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Button(
                onClick = {
                    val randomAnimal = AnimalData.ANIMAL_PAGES[Random.nextInt(AnimalData.ANIMAL_PAGES.size)]
                    SoundEffects.playMagic()
                    onSelectAnimal(randomAnimal.id)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .shadow(3.dp, RoundedCornerShape(24.dp)),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF10B981)
                ),
                shape = RoundedCornerShape(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "Surprise Me",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "🎲 Surprise Me! (Quick Start)",
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp,
                    color = Color.White
                )
            }
        }

        // Category Filter Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AnimalData.CATEGORIES.forEach { category ->
                val isSelected = selectedCategoryId == category.id
                Box(
                    modifier = Modifier
                        .height(38.dp)
                        .shadow(if (isSelected) 3.dp else 1.dp, RoundedCornerShape(19.dp))
                        .clip(RoundedCornerShape(19.dp))
                        .background(
                            if (isSelected) Color(0xFFF59E0B) else Color.White
                        )
                        .border(
                            2.dp,
                            if (isSelected) Color(0xFFFDE68A) else Color(0xFFE2E8F0),
                            RoundedCornerShape(19.dp)
                        )
                        .clickable {
                            selectedCategoryId = category.id
                            SoundEffects.playPop()
                        }
                        .padding(horizontal = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = category.emoji, fontSize = 16.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${category.label} (${category.count})",
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp,
                            color = if (isSelected) Color.White else SlateText
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 20 Animals Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(filteredAnimals, key = { it.id }) { animal ->
                AnimalCard(
                    animal = animal,
                    onClick = {
                        SoundEffects.playPop()
                        onSelectAnimal(animal.id)
                    }
                )
            }
        }
    }
}

@Composable
fun AnimalCard(
    animal: AnimalPage,
    onClick: () -> Unit
) {
    // Generate mini SVG preview bitmap
    val previewBitmap = remember(animal.id) {
        val size = 260
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        SvgOutlineRenderer.renderSvgToCanvas(animal.svgDrawing, canvas, size, size, renderWhiteFills = true)
        bitmap
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, RoundedCornerShape(22.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Animal SVG line art preview in square container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFFFFFBEB))
                    .border(2.dp, Color(0xFFFEF3C7), RoundedCornerShape(16.dp))
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    bitmap = previewBitmap.asImageBitmap(),
                    contentDescription = animal.name,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Emoji + Animal Name
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(text = animal.emoji, fontSize = 18.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = animal.name,
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = SlateText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Text(
                text = animal.subtitle,
                fontWeight = FontWeight.Medium,
                fontSize = 11.sp,
                color = SlateMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            // "Colour Me!" child-friendly button
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(34.dp)
                    .clip(RoundedCornerShape(17.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFFF59E0B), Color(0xFFEA580C))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "🎨 Colour Me!",
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp,
                    color = Color.White
                )
            }
        }
    }
}
