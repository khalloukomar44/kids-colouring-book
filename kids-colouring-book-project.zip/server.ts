import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

// Project export ZIP download route
app.get('/api/export-project-zip', (req: Request, res: Response) => {
  const zipPath = path.resolve(__dirname, 'kids-colouring-book-project.zip');
  if (fs.existsSync(zipPath)) {
    res.download(zipPath, 'kids-colouring-book-android-project.zip');
  } else {
    res.status(404).send('ZIP file not found. Generating...');
  }
});


const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Prompt generator helper
app.post('/api/prototype/generate', async (req: Request, res: Response) => {
  try {
    const { prompt, category = 'saas', device = 'desktop', style = 'dark' } = req.body;

    if (!prompt) {
      res.status(400).json({ error: 'Prompt is required' });
      return;
    }

    const systemPrompt = `You are a Principal Product Designer & UI/UX Architect at Google.
Generate a complete, production-grade interactive prototype specification in JSON for the following user request.

The output MUST be valid JSON adhering strictly to this schema:
{
  "id": "proto-unique-id",
  "title": "Clear Catchy App Title",
  "description": "2-3 sentence product summary explaining the value prop and core user loops.",
  "category": "saas" | "mobile" | "ecommerce" | "ai" | "fintech" | "health" | "devops" | "custom",
  "device": "${device}",
  "theme": {
    "primaryColor": "#6366f1",
    "accentColor": "#10b981",
    "bgStyle": "${style}",
    "fontFamily": "Inter",
    "borderRadius": "rounded-xl",
    "density": "comfortable"
  },
  "initialScreenId": "screen-1",
  "screens": [
    {
      "id": "screen-1",
      "name": "Screen Name (e.g., Executive Dashboard)",
      "type": "page",
      "badge": "Main Screen",
      "navBar": {
        "brandName": "Brand Name",
        "logoIcon": "Sparkles" | "Zap" | "Activity" | "Shield" | "Bot",
        "links": [
          { "id": "l-1", "label": "Link 1", "action": { "type": "navigate", "targetScreenId": "screen-2" }, "active": true }
        ],
        "rightActions": [
          { "id": "ra-1", "label": "Action Button", "icon": "Plus", "action": { "type": "open_modal", "modalId": "modal-1" }, "variant": "primary" }
        ]
      },
      "sideBar": {
        "header": "Workspace",
        "items": [
          { "id": "s-1", "label": "Menu Item", "icon": "LayoutDashboard", "active": true, "action": { "type": "navigate", "targetScreenId": "screen-1" } }
        ]
      },
      "blocks": [
        {
          "id": "b-1",
          "type": "hero" | "stats_grid" | "chart" | "data_table" | "card_grid" | "feature_list" | "form_card" | "pricing_table" | "ai_prompt_box" | "mobile_balance_card" | "activity_feed" | "banner_alert",
          "title": "Block Title",
          "subtitle": "Helpful subtitle",
          "props": { ... appropriate props for block type ... },
          "actions": {
            "onPrimaryClick": { "type": "open_modal", "modalId": "modal-1" },
            "onRowClick": { "type": "toast", "toastMessage": "Selected item details loaded", "toastType": "info" }
          }
        }
      ],
      "modals": [
        {
          "id": "modal-1",
          "title": "Modal Title",
          "subtitle": "Modal Description",
          "size": "md",
          "blocks": [
            {
              "id": "modal-form",
              "type": "form_card",
              "props": {
                "fields": [
                  { "id": "f-1", "label": "Field Name", "type": "text", "placeholder": "Enter value..." }
                ],
                "submitLabel": "Submit Action"
              },
              "actions": {
                "onSubmit": { "type": "toast", "toastMessage": "Action completed successfully!", "toastType": "success" }
              }
            }
          ]
        }
      ]
    }
  ]
}

Provide 2 to 3 connected screens with realistic content, great copy, KPI metrics, rich data rows, charts, and interactive actions (navigate, open_modal, toast).`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: `Design an interactive prototype for: ${prompt}. Category: ${category}, Device: ${device}, Theme: ${style}`,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        temperature: 0.7,
      },
    });

    const text = response.text || '{}';
    const parsedData = JSON.parse(text);
    res.json({ prototype: parsedData });
  } catch (error: any) {
    console.error('Error generating prototype:', error);
    res.status(500).json({ error: error.message || 'Failed to generate prototype' });
  }
});

// Refine screen with AI
app.post('/api/prototype/refine', async (req: Request, res: Response) => {
  try {
    const { currentScreen, prompt, theme } = req.body;

    if (!currentScreen || !prompt) {
      res.status(400).json({ error: 'currentScreen and prompt are required' });
      return;
    }

    const systemPrompt = `You are a Senior UI/UX Designer.
The user wants to refine an existing screen in their interactive prototype.
Modify the screen's component blocks, copy, layouts, or interactive actions according to their instruction: "${prompt}".

Return ONLY the updated Screen object in JSON format:
{
  "id": "${currentScreen.id}",
  "name": "${currentScreen.name}",
  "type": "page",
  "badge": "Updated with AI",
  "navBar": { ... },
  "sideBar": { ... },
  "bottomNav": { ... },
  "blocks": [ ... updated and enhanced ComponentBlocks ... ],
  "modals": [ ... updated modals ... ]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: `Refine this screen JSON according to this instruction: "${prompt}"\nCurrent Screen JSON:\n${JSON.stringify(currentScreen)}`,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        temperature: 0.6,
      },
    });

    const text = response.text || '{}';
    const updatedScreen = JSON.parse(text);
    res.json({ screen: updatedScreen });
  } catch (error: any) {
    console.error('Error refining screen:', error);
    res.status(500).json({ error: error.message || 'Failed to refine screen' });
  }
});

// Add linked screen flow
app.post('/api/prototype/add-screen', async (req: Request, res: Response) => {
  try {
    const { currentProject, goal } = req.body;

    if (!currentProject || !goal) {
      res.status(400).json({ error: 'currentProject and goal are required' });
      return;
    }

    const systemPrompt = `You are a UI/UX architect adding a new connected screen to an existing prototype.
Goal for new screen: "${goal}"
Existing project title: "${currentProject.title}"
Existing device: "${currentProject.device}"

Return a single Screen JSON object with rich blocks, realistic data, and links back to the main screens.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: `Create a new screen for: "${goal}". Existing screens: ${currentProject.screens.map((s: any) => s.name).join(', ')}`,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        temperature: 0.7,
      },
    });

    const text = response.text || '{}';
    const newScreen = JSON.parse(text);
    if (!newScreen.id) newScreen.id = 'screen-' + Date.now();
    res.json({ screen: newScreen });
  } catch (error: any) {
    console.error('Error adding screen:', error);
    res.status(500).json({ error: error.message || 'Failed to add screen' });
  }
});

// Usability persona audit
app.post('/api/prototype/persona-audit', async (req: Request, res: Response) => {
  try {
    const { project } = req.body;

    if (!project) {
      res.status(400).json({ error: 'project is required' });
      return;
    }

    const systemPrompt = `You are a World-Class UX Research & Cognitive Ergonomics Specialist.
Perform a simulated Persona Usability Audit for the provided prototype.
Evaluate Nielsen-Norman Usability Heuristics, friction points, cognitive load, accessibility (WCAG), and predict heatmap interest zones.

Return an array of 2 distinct PersonaAuditResult objects in JSON format:
[
  {
    "personaName": "Elena Vance",
    "personaRole": "VP of Growth & Enterprise Buyer",
    "avatar": "👩‍💼",
    "overallScore": 92,
    "summary": "2-3 sentences evaluating time-to-value and visual hierarchy.",
    "heuristics": [
      { "name": "Visibility of system status", "score": 5, "note": "..." },
      { "name": "Match between system & real world", "score": 4, "note": "..." },
      { "name": "User control and freedom", "score": 5, "note": "..." },
      { "name": "Recognition rather than recall", "score": 4, "note": "..." },
      { "name": "Aesthetic and minimalist design", "score": 5, "note": "..." }
    ],
    "positives": ["Point 1", "Point 2", "Point 3"],
    "frictionPoints": ["Friction 1", "Friction 2"],
    "recommendations": ["Recommendation 1", "Recommendation 2"],
    "predictedHeatmapAreas": [
      { "label": "Hero Primary CTA", "interestLevel": "high", "clickLikelihood": 84 },
      { "label": "KPI Metric Cards", "interestLevel": "high", "clickLikelihood": 72 },
      { "label": "Navigation Tabs", "interestLevel": "medium", "clickLikelihood": 50 }
    ]
  },
  {
    "personaName": "David Chen",
    "personaRole": "First-time Novice User",
    "avatar": "👨‍🎓",
    "overallScore": 86,
    "summary": "...",
    "heuristics": [ ... ],
    "positives": [ ... ],
    "frictionPoints": [ ... ],
    "recommendations": [ ... ],
    "predictedHeatmapAreas": [ ... ]
  }
]`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: `Run usability audit on this prototype:\nTitle: ${project.title}\nDescription: ${project.description}\nScreens: ${JSON.stringify(project.screens.map((s: any) => ({ name: s.name, blocks: s.blocks?.map((b: any) => ({ type: b.type, title: b.title })) })))}`,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        temperature: 0.6,
      },
    });

    const text = response.text || '[]';
    const audits = JSON.parse(text);
    res.json({ audits });
  } catch (error: any) {
    console.error('Error auditing prototype:', error);
    res.status(500).json({ error: error.message || 'Failed to audit prototype' });
  }
});

// A/B test variant generator
app.post('/api/prototype/ab-test', async (req: Request, res: Response) => {
  try {
    const { currentScreen, optimizationGoal = 'Maximize conversion & engagement' } = req.body;

    const systemPrompt = `You are a Conversion Rate Optimization (CRO) and Growth Design Master.
Generate an A/B test Variant B for this screen to achieve: "${optimizationGoal}".
Create alternative high-impact copywriting, improved visual hierarchy, sharper value proposition, and reduced friction.

Return a JSON object:
{
  "id": "variant-b-${Date.now()}",
  "name": "Variant B (High-Converting CRO)",
  "hypothesis": "Clear hypothesis why this variant should increase conversion by 18-35%",
  "predictedConversionLift": "+24.8%",
  "keyChanges": [
    "Reframed headline from feature-focus to outcome-driven benefit",
    "Added social proof badge with star ratings",
    "Increased primary CTA prominence with accent ring"
  ],
  "variantScreen": {
    "id": "${currentScreen.id}-var-b",
    "name": "${currentScreen.name} (Variant B)",
    "type": "page",
    "badge": "A/B Variant B",
    "navBar": { ... },
    "sideBar": { ... },
    "bottomNav": { ... },
    "blocks": [ ... optimized ComponentBlocks ... ],
    "modals": [ ... ]
  }
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: `Generate Variant B for optimization goal: "${optimizationGoal}"\nCurrent Screen:\n${JSON.stringify(currentScreen)}`,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        temperature: 0.7,
      },
    });

    const text = response.text || '{}';
    const variantData = JSON.parse(text);
    res.json({ variant: variantData });
  } catch (error: any) {
    console.error('Error generating AB test:', error);
    res.status(500).json({ error: error.message || 'Failed to generate AB variant' });
  }
});

// Serve frontend
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    try {
      const { createServer: createViteServer } = await import('vite');
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: 'spa',
      });
      app.use(vite.middlewares);
    } catch (e) {
      console.warn('Vite middleware initialization skipped or running independently:', e);
      app.use(express.static(path.resolve(__dirname, '.')));
    }
  }

  app.listen(PORT, () => {
    console.log(`ProtoCraft server running on port ${PORT}`);
  });
}

startServer();
