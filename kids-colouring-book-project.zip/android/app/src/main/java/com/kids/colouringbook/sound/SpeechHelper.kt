package com.kids.colouringbook.sound

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

class SpeechHelper(context: Context) {

    private var tts: TextToSpeech? = null
    private var isReady: Boolean = false

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                tts?.setPitch(1.2f) // Friendly cheerful voice pitch
                tts?.setSpeechRate(0.9f) // Clear speech rate for kids
                isReady = true
            }
        }
    }

    fun speak(text: String) {
        if (!SoundEffects.isEnabled || !isReady) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kid_speech_id")
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
