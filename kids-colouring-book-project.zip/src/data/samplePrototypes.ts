import { PrototypeProject } from '../types/prototype';

export const SAMPLE_PROTOTYPES: PrototypeProject[] = [
  {
    id: 'proto-pulse-ai',
    title: 'PulseAI - Intelligent SaaS Growth Engine',
    description: 'B2B Analytics & AI insights dashboard with automated workflow builder and team collaboration.',
    category: 'saas',
    device: 'desktop',
    theme: {
      primaryColor: '#6366f1',
      accentColor: '#10b981',
      bgStyle: 'dark',
      fontFamily: 'Inter',
      borderRadius: 'rounded-xl',
      density: 'comfortable',
    },
    initialScreenId: 'screen-pulse-dash',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    annotations: [
      {
        id: 'ann-1',
        screenId: 'screen-pulse-dash',
        xPercent: 35,
        yPercent: 22,
        author: 'Sarah Chen (Lead Designer)',
        avatarColor: '#ec4899',
        text: 'The MRR growth metric is performing 18% better after switching to the gradient sparkline.',
        resolved: false,
        createdAt: '10 mins ago',
      },
      {
        id: 'ann-2',
        screenId: 'screen-pulse-dash',
        xPercent: 78,
        yPercent: 12,
        author: 'Alex River (PM)',
        avatarColor: '#3b82f6',
        text: 'Clicking "Deploy Agent" triggers the new modal flow. Test with real users next sprint!',
        resolved: true,
        createdAt: '1 hour ago',
      },
    ],
    personaAudits: [
      {
        personaName: 'Elena Rostova',
        personaRole: 'VP of Growth & Data Analytics',
        avatar: '👩‍💼',
        overallScore: 94,
        summary: 'Exceptional visual hierarchy and rapid time-to-insight. The AI prompt co-pilot simplifies complex SQL queries for non-technical stakeholders.',
        heuristics: [
          { name: 'Visibility of system status', score: 5, note: 'Real-time telemetry and pulse indicators provide immediate feedback.' },
          { name: 'Match between system & real world', score: 5, note: 'KPI terminology (MRR, Churn, LTV, ARR) conforms to standard SaaS metrics.' },
          { name: 'User control and freedom', score: 4, note: 'Date picker and quick filters offer effortless undo and preset range switching.' },
          { name: 'Recognition rather than recall', score: 5, note: 'Prompt suggestion chips reduce cognitive load significantly.' },
        ],
        positives: [
          'Instant drill-down with interactive chart hover states',
          'High-contrast dark mode reduces eye fatigue during prolonged analytical sessions',
          'One-click export for weekly executive slide summaries',
        ],
        frictionPoints: [
          'Secondary metrics could benefit from customizable card reordering',
        ],
        recommendations: [
          'Add a pinned benchmark line against industry quartile average in the MRR chart',
          'Offer keyboard shortcut (Cmd+K) hint directly inside the AI search bar',
        ],
        predictedHeatmapAreas: [
          { label: 'AI Query Prompt Bar', interestLevel: 'high', clickLikelihood: 88 },
          { label: 'Primary KPI Revenue Card', interestLevel: 'high', clickLikelihood: 76 },
          { label: 'Deploy Agent CTA', interestLevel: 'high', clickLikelihood: 69 },
          { label: 'Customer Retention Table Filters', interestLevel: 'medium', clickLikelihood: 48 },
        ],
      },
      {
        personaName: 'Marcus Vance',
        personaRole: 'Enterprise Security Auditor',
        avatar: '👨‍💻',
        overallScore: 89,
        summary: 'Clean permissions structure and transparent workspace management. Clear data boundary indicators.',
        heuristics: [
          { name: 'Consistency and standards', score: 5, note: 'Strict adherence to design token conventions.' },
          { name: 'Error prevention', score: 4, note: 'Confirmation dialogues present on high-stakes operations.' },
        ],
        positives: ['Role-based badges visible in team list', 'Audit logs readily accessible from sidebar'],
        frictionPoints: ['Export button should clarify if PII is masked by default'],
        recommendations: ['Add SOC2 compliance watermark in settings screen'],
        predictedHeatmapAreas: [
          { label: 'Team Roles & Access Tab', interestLevel: 'high', clickLikelihood: 65 },
          { label: 'API Keys Drawer Button', interestLevel: 'high', clickLikelihood: 61 },
        ],
      },
    ],
    screens: [
      {
        id: 'screen-pulse-dash',
        name: 'Executive Dashboard',
        type: 'page',
        badge: 'Main View',
        navBar: {
          brandName: 'PulseAI',
          logoIcon: 'Sparkles',
          links: [
            { id: 'nav-1', label: 'Overview', action: { type: 'navigate', targetScreenId: 'screen-pulse-dash' }, active: true },
            { id: 'nav-2', label: 'AI Agents', action: { type: 'navigate', targetScreenId: 'screen-pulse-agents' } },
            { id: 'nav-3', label: 'Customers', action: { type: 'navigate', targetScreenId: 'screen-pulse-customers' } },
            { id: 'nav-4', label: 'Integrations', action: { type: 'toast', toastMessage: 'Integrations catalog loaded (42 connected)', toastType: 'info' } },
          ],
          rightActions: [
            { id: 'act-1', label: 'Upgrade Pro', icon: 'Zap', action: { type: 'open_modal', modalId: 'modal-upgrade' }, variant: 'secondary' },
            { id: 'act-2', label: '+ New Agent', icon: 'Plus', action: { type: 'open_modal', modalId: 'modal-new-agent' }, variant: 'primary' },
          ],
        },
        sideBar: {
          header: 'Workspace: Acme Global',
          items: [
            { id: 'sb-1', label: 'Live Metrics', icon: 'Activity', active: true, action: { type: 'navigate', targetScreenId: 'screen-pulse-dash' } },
            { id: 'sb-2', label: 'AI Agent Swarm', icon: 'Bot', badge: '3 Active', action: { type: 'navigate', targetScreenId: 'screen-pulse-agents' } },
            { id: 'sb-3', label: 'Customer Cohorts', icon: 'Users', badge: '1,420', action: { type: 'navigate', targetScreenId: 'screen-pulse-customers' } },
            { id: 'sb-4', label: 'Revenue Forecast', icon: 'TrendingUp', action: { type: 'toast', toastMessage: 'Q3 Forecast model updated with 98.4% confidence', toastType: 'success' } },
            { id: 'sb-5', label: 'Settings & Security', icon: 'ShieldCheck', action: { type: 'open_modal', modalId: 'modal-settings' } },
          ],
        },
        blocks: [
          {
            id: 'block-ai-prompt',
            type: 'ai_prompt_box',
            title: 'Gemini Copilot for Analytics',
            subtitle: 'Ask natural questions across your company data lake, CRM, and Stripe pipeline.',
            props: {
              placeholder: 'Ask: "Show me churn rate for enterprise accounts compared to last quarter..."',
              quickPrompts: [
                'Breakdown ARR by tier & geography',
                'Which accounts are at risk of churning?',
                'Forecast pipeline for next 90 days',
                'Simulate pricing increase by 15%',
              ],
            },
            actions: {
              onExecute: { type: 'toast', toastMessage: '🤖 Analyzing 482,000 data points across Stripe & HubSpot...', toastType: 'info' },
            },
          },
          {
            id: 'block-stats',
            type: 'stats_grid',
            props: {
              columns: 4,
              items: [
                { id: 'st-1', label: 'Monthly Recurring Revenue', value: '$148,290', change: '+23.4%', trend: 'up', subtext: 'vs. $120,100 last month' },
                { id: 'st-2', label: 'Active Enterprise Seats', value: '4,892', change: '+18.1%', trend: 'up', subtext: '99.98% uptime SLA' },
                { id: 'st-3', label: 'Net Revenue Retention', value: '134.2%', change: '+4.8%', trend: 'up', subtext: 'Top 5% SaaS quartile' },
                { id: 'st-4', label: 'AI Agent Automations', value: '89.4k', change: '+41.2%', trend: 'up', subtext: 'Saved ~620 team hours' },
              ],
            },
          },
          {
            id: 'block-revenue-chart',
            type: 'chart',
            title: 'Revenue Acceleration & Projection',
            subtitle: 'Real-time billing telemetry integrated with machine learning forecast',
            props: {
              chartType: 'area',
              timeframes: ['7D', '30D', '90D', '1Y', 'All'],
              activeTimeframe: '30D',
              dataPoints: [
                { label: 'Week 1', value: 32000, projected: 31000 },
                { label: 'Week 2', value: 48000, projected: 44000 },
                { label: 'Week 3', value: 71000, projected: 68000 },
                { label: 'Week 4', value: 112000, projected: 99000 },
                { label: 'Week 5 (Est)', value: 148290, projected: 142000 },
              ],
            },
            actions: {
              onTimeframeChange: { type: 'toast', toastMessage: 'Updated dataset for selected timeframe', toastType: 'info' },
            },
          },
          {
            id: 'block-customers-table',
            type: 'data_table',
            title: 'High-Value Accounts & Retention Health',
            subtitle: 'Live health scores computed from product telemetry and support sentiment',
            props: {
              searchPlaceholder: 'Search accounts by company, plan, or health score...',
              headers: ['Customer', 'Plan Tier', 'MRR Contribution', 'Health Score', 'Status', 'Action'],
              rows: [
                { id: 'c-1', name: 'Starlight Dynamics', sub: 'starlight.io • 840 seats', tier: 'Enterprise Plus', mrr: '$14,500/mo', health: '98/100 (Optimal)', status: 'Healthy', statusColor: 'green' },
                { id: 'c-2', name: 'CyberVanguard Inc.', sub: 'vanguard.tech • 420 seats', tier: 'Enterprise', mrr: '$8,900/mo', health: '92/100 (Strong)', status: 'Healthy', statusColor: 'green' },
                { id: 'c-3', name: 'Solaria BioLabs', sub: 'solariabio.com • 210 seats', tier: 'Growth Team', mrr: '$4,200/mo', health: '74/100 (Review)', status: 'Attention', statusColor: 'amber' },
                { id: 'c-4', name: 'Quantum Velocity', sub: 'quantum.ai • 1,200 seats', tier: 'Enterprise Custom', mrr: '$22,000/mo', health: '99/100 (Champion)', status: 'Healthy', statusColor: 'green' },
                { id: 'c-5', name: 'Aetheric Media', sub: 'aetheric.co • 95 seats', tier: 'Starter Team', mrr: '$1,800/mo', health: '61/100 (Needs Outreach)', status: 'At Risk', statusColor: 'red' },
              ],
            },
            actions: {
              onRowClick: { type: 'navigate', targetScreenId: 'screen-pulse-customers' },
            },
          },
        ],
        modals: [
          {
            id: 'modal-upgrade',
            title: '🚀 Upgrade to PulseAI Enterprise Scale',
            subtitle: 'Unlock unlimited autonomous agents, custom fine-tuning, and 24/7 dedicated support engineer.',
            size: 'lg',
            blocks: [
              {
                id: 'pricing-grid-modal',
                type: 'pricing_table',
                props: {
                  tiers: [
                    {
                      name: 'Growth Scale',
                      price: '$499',
                      period: '/month',
                      description: 'For scaling tech startups processing up to 10M records.',
                      features: ['10 Autonomous AI Agents', 'Real-time Webhook sync', 'SOC2 Type II certified', 'Unlimited custom dashboards', 'Priority Discord channel'],
                      ctaLabel: 'Choose Growth',
                      popular: false,
                    },
                    {
                      name: 'Enterprise Apex',
                      price: '$1,499',
                      period: '/month',
                      description: 'Custom fine-tuned models deployed in dedicated VPC with zero data retention.',
                      features: ['Unlimited AI Agent Swarms', 'Dedicated Data Architect', 'Custom SLA (99.99%)', 'On-premise LLM deployment option', 'Custom SSO & SAML'],
                      ctaLabel: 'Start 14-Day Free Trial',
                      popular: true,
                    },
                  ],
                },
                actions: {
                  onSelectTier: { type: 'toast', toastMessage: '🎉 Enterprise trial activated! Check your inbox for API credentials.', toastType: 'success' },
                },
              },
            ],
            closeAction: { type: 'close_modal' },
          },
          {
            id: 'modal-new-agent',
            title: '✨ Deploy New Autonomous Agent',
            subtitle: 'Configure your agent persona, connected data integrations, and execution schedule.',
            size: 'md',
            blocks: [
              {
                id: 'form-new-agent',
                type: 'form_card',
                props: {
                  fields: [
                    { id: 'agent-name', label: 'Agent Identifier', type: 'text', placeholder: 'e.g., ChurnPredictor-Alpha' },
                    { id: 'agent-role', label: 'Role / Objective', type: 'select', options: ['Revenue Churn Sentinel', 'Lead Qualification Bot', 'Competitor Price Tracker', 'Weekly Board Deck Generator'] },
                    { id: 'agent-model', label: 'Underlying Reasoning Model', type: 'select', options: ['Gemini 3.7 Flash (Ultra Low Latency)', 'Gemini 3.1 Pro (Deep Complex Reasoning)'] },
                    { id: 'agent-interval', label: 'Trigger Schedule', type: 'select', options: ['Real-time on Webhook Event', 'Hourly Sync', 'Daily at 08:00 AM UTC', 'Continuous Streaming'] },
                  ],
                  submitLabel: 'Launch Autonomous Agent',
                },
                actions: {
                  onSubmit: { type: 'toast', toastMessage: '🚀 Agent launched successfully! Monitoring live events.', toastType: 'success' },
                },
              },
            ],
            closeAction: { type: 'close_modal' },
          },
          {
            id: 'modal-settings',
            title: '⚙️ Workspace Security & API Settings',
            subtitle: 'Manage encrypted tokens, webhooks, and team access permissions.',
            size: 'md',
            blocks: [
              {
                id: 'form-settings',
                type: 'form_card',
                props: {
                  fields: [
                    { id: 'api-key', label: 'Live Secret API Key', type: 'text', placeholder: 'pk_live_839201948102938109', disabled: true },
                    { id: 'webhook-url', label: 'Event Webhook Endpoint', type: 'text', placeholder: 'https://api.yourdomain.com/webhooks/pulse' },
                    { id: '2fa-toggle', label: 'Require Hardware 2FA for all Admins', type: 'switch', defaultChecked: true },
                    { id: 'audit-log', label: 'Store immutable audit trail for 365 days', type: 'switch', defaultChecked: true },
                  ],
                  submitLabel: 'Save Preferences',
                },
                actions: {
                  onSubmit: { type: 'toast', toastMessage: 'Security policies updated successfully.', toastType: 'success' },
                },
              },
            ],
            closeAction: { type: 'close_modal' },
          },
        ],
      },
      {
        id: 'screen-pulse-agents',
        name: 'AI Agent Swarm Hub',
        type: 'page',
        badge: 'Agent Orchestration',
        navBar: {
          brandName: 'PulseAI',
          logoIcon: 'Sparkles',
          links: [
            { id: 'nav-1', label: 'Overview', action: { type: 'navigate', targetScreenId: 'screen-pulse-dash' } },
            { id: 'nav-2', label: 'AI Agents', action: { type: 'navigate', targetScreenId: 'screen-pulse-agents' }, active: true },
            { id: 'nav-3', label: 'Customers', action: { type: 'navigate', targetScreenId: 'screen-pulse-customers' } },
          ],
          rightActions: [
            { id: 'act-2', label: '+ Deploy Agent', icon: 'Plus', action: { type: 'open_modal', modalId: 'modal-new-agent' }, variant: 'primary' },
          ],
        },
        sideBar: {
          header: 'Workspace: Acme Global',
          items: [
            { id: 'sb-1', label: 'Live Metrics', icon: 'Activity', action: { type: 'navigate', targetScreenId: 'screen-pulse-dash' } },
            { id: 'sb-2', label: 'AI Agent Swarm', icon: 'Bot', badge: '3 Active', active: true, action: { type: 'navigate', targetScreenId: 'screen-pulse-agents' } },
            { id: 'sb-3', label: 'Customer Cohorts', icon: 'Users', badge: '1,420', action: { type: 'navigate', targetScreenId: 'screen-pulse-customers' } },
          ],
        },
        blocks: [
          {
            id: 'banner-agents',
            type: 'banner_alert',
            title: 'Autonomous Swarm Active',
            subtitle: '3 autonomous agents are continuously executing background jobs with a 99.94% accuracy rating.',
            props: {
              variant: 'indigo',
              icon: 'Bot',
              actionLabel: 'View Swarm Logs',
            },
            actions: {
              onAction: { type: 'toast', toastMessage: 'Streaming 120 agent execution events per minute', toastType: 'info' },
            },
          },
          {
            id: 'card-grid-agents',
            type: 'card_grid',
            title: 'Deployed Intelligence Agents',
            subtitle: 'Click any agent card to inspect memory graph and adjust prompt weights.',
            props: {
              columns: 3,
              cards: [
                {
                  id: 'ag-1',
                  title: 'Churn Sentinel V3',
                  badge: 'Online • 99.8% SLA',
                  badgeColor: 'green',
                  description: 'Monitors product login decay, declining API call frequencies, and support ticket sentiment.',
                  metrics: [{ label: 'Cases Resolved', value: '1,280' }, { label: 'Revenue Saved', value: '$84.2k' }],
                  ctaText: 'Tune Parameters',
                },
                {
                  id: 'ag-2',
                  title: 'Expansion Bot Pro',
                  badge: 'Running Jobs',
                  badgeColor: 'blue',
                  description: 'Identifies accounts crossing 85% plan capacity and drafts customized enterprise upgrade offers.',
                  metrics: [{ label: 'Leads Created', value: '412' }, { label: 'Conversion Rate', value: '38.4%' }],
                  ctaText: 'Tune Parameters',
                },
                {
                  id: 'ag-3',
                  title: 'Executive Briefing AI',
                  badge: 'Scheduled: 08:00 AM',
                  badgeColor: 'purple',
                  description: 'Synthesizes sales calls, GitHub commits, and Stripe revenue into daily 2-minute bullet summaries.',
                  metrics: [{ label: 'Briefs Sent', value: '184' }, { label: 'Avg Rating', value: '4.9/5' }],
                  ctaText: 'Tune Parameters',
                },
              ],
            },
            actions: {
              onCardClick: { type: 'toast', toastMessage: 'Opening Agent Neural Weights Inspector...', toastType: 'info' },
            },
          },
        ],
      },
      {
        id: 'screen-pulse-customers',
        name: 'Customer Cohorts & CRM',
        type: 'page',
        badge: 'Customer View',
        navBar: {
          brandName: 'PulseAI',
          logoIcon: 'Sparkles',
          links: [
            { id: 'nav-1', label: 'Overview', action: { type: 'navigate', targetScreenId: 'screen-pulse-dash' } },
            { id: 'nav-2', label: 'AI Agents', action: { type: 'navigate', targetScreenId: 'screen-pulse-agents' } },
            { id: 'nav-3', label: 'Customers', action: { type: 'navigate', targetScreenId: 'screen-pulse-customers' }, active: true },
          ],
          rightActions: [
            { id: 'act-1', label: 'Export CSV', icon: 'Download', action: { type: 'toast', toastMessage: 'Exported 1,420 customer records to secure CSV', toastType: 'success' }, variant: 'secondary' },
          ],
        },
        sideBar: {
          header: 'Workspace: Acme Global',
          items: [
            { id: 'sb-1', label: 'Live Metrics', icon: 'Activity', action: { type: 'navigate', targetScreenId: 'screen-pulse-dash' } },
            { id: 'sb-2', label: 'AI Agent Swarm', icon: 'Bot', badge: '3 Active', action: { type: 'navigate', targetScreenId: 'screen-pulse-agents' } },
            { id: 'sb-3', label: 'Customer Cohorts', icon: 'Users', badge: '1,420', active: true, action: { type: 'navigate', targetScreenId: 'screen-pulse-customers' } },
          ],
        },
        blocks: [
          {
            id: 'table-full-customers',
            type: 'data_table',
            title: 'Enterprise Directory & Health Matrix',
            subtitle: 'Showing all 1,420 active tenant workspaces across US-East and EU-West regions',
            props: {
              searchPlaceholder: 'Filter by name, country, or ARR bucket...',
              headers: ['Company Name', 'Primary Contact', 'Tier', 'Annual Value', 'Health Index', 'Next Renewal'],
              rows: [
                { id: 'cr-1', name: 'Starlight Dynamics', sub: 'San Francisco, CA', tier: 'Enterprise Plus', mrr: '$174,000 ARR', health: '98/100 (Optimal)', status: 'In 32 Days', statusColor: 'green' },
                { id: 'cr-2', name: 'Vanguard Cyber Tech', sub: 'London, UK', tier: 'Enterprise', mrr: '$106,800 ARR', health: '92/100 (Strong)', status: 'In 88 Days', statusColor: 'green' },
                { id: 'cr-3', name: 'Solaria BioLabs', sub: 'Boston, MA', tier: 'Growth Team', mrr: '$50,400 ARR', health: '74/100 (Needs Attention)', status: 'In 14 Days', statusColor: 'amber' },
                { id: 'cr-4', name: 'Quantum Velocity', sub: 'Austin, TX', tier: 'Enterprise Custom', mrr: '$264,000 ARR', health: '99/100 (Champion)', status: 'Auto-Renews', statusColor: 'green' },
              ],
            },
            actions: {
              onRowClick: { type: 'toast', toastMessage: 'Opening CRM deep profile...', toastType: 'info' },
            },
          },
        ],
      },
    ],
  },
  {
    id: 'proto-novapay',
    title: 'NovaPay - Next-Gen Fintech Mobile SuperApp',
    description: 'Sleek dark-glassmorphism financial wallet featuring multi-currency cards, crypto staking, and instant peer-to-peer payments.',
    category: 'fintech',
    device: 'mobile',
    theme: {
      primaryColor: '#10b981',
      accentColor: '#6366f1',
      bgStyle: 'dark',
      fontFamily: 'Plus Jakarta Sans',
      borderRadius: 'rounded-2xl',
      density: 'comfortable',
    },
    initialScreenId: 'screen-nova-wallet',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    annotations: [],
    screens: [
      {
        id: 'screen-nova-wallet',
        name: 'Home Wallet',
        type: 'page',
        badge: 'Main Screen',
        bottomNav: {
          items: [
            { id: 'bn-1', label: 'Wallet', icon: 'Wallet', active: true, action: { type: 'navigate', targetScreenId: 'screen-nova-wallet' } },
            { id: 'bn-2', label: 'Transfer', icon: 'ArrowRightLeft', action: { type: 'navigate', targetScreenId: 'screen-nova-transfer' } },
            { id: 'bn-3', label: 'Cards', icon: 'CreditCard', action: { type: 'toast', toastMessage: 'Virtual Titanium Card: Active • Apple Pay Ready', toastType: 'info' } },
            { id: 'bn-4', label: 'Activity', icon: 'Clock', action: { type: 'toast', toastMessage: '32 transactions verified on blockchain ledger', toastType: 'info' } },
          ],
        },
        blocks: [
          {
            id: 'block-balance',
            type: 'mobile_balance_card',
            props: {
              balance: '$48,920.50',
              currency: 'USD Net Worth',
              dailyChange: '+$1,420.30 (+2.98% today)',
              cardHolder: 'Alexandria Morgan',
              cardNumberMask: '•••• 8829',
              cardExpiry: '08/29',
              cardBrand: 'VISA Black Infinite',
              actions: [
                { id: 'ba-1', label: 'Send', icon: 'Send', action: { type: 'navigate', targetScreenId: 'screen-nova-transfer' } },
                { id: 'ba-2', label: 'Receive', icon: 'QrCode', action: { type: 'toast', toastMessage: 'Your NovaPay QR code is ready for scanning', toastType: 'info' } },
                { id: 'ba-3', label: 'Swap', icon: 'RefreshCw', action: { type: 'open_modal', modalId: 'modal-swap-crypto' } },
                { id: 'ba-4', label: 'Deposit', icon: 'PlusCircle', action: { type: 'toast', toastMessage: 'Instant wire details copied to clipboard', toastType: 'success' } },
              ],
            },
          },
          {
            id: 'block-activity',
            type: 'activity_feed',
            title: 'Recent Transactions',
            subtitle: 'Zero-fee instant settlement with smart receipt tagging',
            props: {
              items: [
                { id: 'tx-1', title: 'Apple Store 5th Ave', sub: 'Hardware purchase • Today, 2:40 PM', amount: '-$1,299.00', type: 'expense', icon: 'Laptop' },
                { id: 'tx-2', title: 'Stripe Settlement', sub: 'Client consulting payout • Today, 9:15 AM', amount: '+$8,450.00', type: 'income', icon: 'ArrowDownLeft' },
                { id: 'tx-3', title: 'ETH Staking Yield', sub: 'Automated compound yield • Yesterday', amount: '+$142.80', type: 'income', icon: 'Zap' },
                { id: 'tx-4', title: 'Uber Black Ride', sub: 'JFK to Manhattan • Yesterday', amount: '-$84.50', type: 'expense', icon: 'Car' },
              ],
            },
            actions: {
              onItemClick: { type: 'toast', toastMessage: 'Transaction receipt ID: #NV-892019 verified on chain', toastType: 'info' },
            },
          },
        ],
        modals: [
          {
            id: 'modal-swap-crypto',
            title: '⚡ Instant Currency & Crypto Swap',
            subtitle: 'Zero slippage guaranteed by NovaPay automated liquidity pool.',
            size: 'md',
            blocks: [
              {
                id: 'swap-form',
                type: 'form_card',
                props: {
                  fields: [
                    { id: 'pay-amt', label: 'You Pay', type: 'text', placeholder: '1,000 USD' },
                    { id: 'recv-asset', label: 'You Receive', type: 'select', options: ['0.384 Ethereum (ETH)', '0.016 Bitcoin (BTC)', '1,000 Solana (SOL)', '920 Euro (EUR)'] },
                    { id: 'slippage', label: 'Max Slippage Tolerance', type: 'select', options: ['0.1% (Recommended)', '0.5%', '1.0%'] },
                  ],
                  submitLabel: 'Execute Swap (0% Fees)',
                },
                actions: {
                  onSubmit: { type: 'toast', toastMessage: '🎉 Swap complete! $1,000 converted to 0.384 ETH instantly.', toastType: 'success' },
                },
              },
            ],
            closeAction: { type: 'close_modal' },
          },
        ],
      },
      {
        id: 'screen-nova-transfer',
        name: 'Instant Peer-to-Peer Transfer',
        type: 'page',
        badge: 'Transfer Screen',
        bottomNav: {
          items: [
            { id: 'bn-1', label: 'Wallet', icon: 'Wallet', action: { type: 'navigate', targetScreenId: 'screen-nova-wallet' } },
            { id: 'bn-2', label: 'Transfer', icon: 'ArrowRightLeft', active: true, action: { type: 'navigate', targetScreenId: 'screen-nova-transfer' } },
            { id: 'bn-3', label: 'Cards', icon: 'CreditCard', action: { type: 'toast', toastMessage: 'Virtual Card loaded', toastType: 'info' } },
            { id: 'bn-4', label: 'Activity', icon: 'Clock', action: { type: 'navigate', targetScreenId: 'screen-nova-wallet' } },
          ],
        },
        blocks: [
          {
            id: 'transfer-form',
            type: 'form_card',
            title: 'Send Money Instantly',
            subtitle: 'Transfer to any @cashtag, phone number, IBAN, or crypto wallet address.',
            props: {
              fields: [
                { id: 'recipient', label: 'Recipient Username / Phone', type: 'text', placeholder: '@sarahchen or +1 (555) 019-2834' },
                { id: 'amount', label: 'Transfer Amount ($)', type: 'text', placeholder: '$250.00' },
                { id: 'note', label: 'Payment Memo / Note', type: 'text', placeholder: 'Dinner & drinks split 🍕' },
                { id: 'speed', label: 'Transfer Rail', type: 'select', options: ['Nova Lightning Rail (Instant • Free)', 'FedNow Instant (Free)', 'Global SWIFT Wire ($15)'] },
              ],
              submitLabel: 'Confirm & Send Money',
            },
            actions: {
              onSubmit: { type: 'toast', toastMessage: '💸 $250.00 sent successfully! Receipt delivered via push notification.', toastType: 'success' },
            },
          },
        ],
      },
    ],
  },
  {
    id: 'proto-hyperstore',
    title: 'HyperStore - Minimalist Luxury E-Commerce',
    description: 'High-converting design showcase with interactive size/variant picker, dynamic cart drawer, and frictionless checkout flow.',
    category: 'ecommerce',
    device: 'desktop',
    theme: {
      primaryColor: '#0f172a',
      accentColor: '#f59e0b',
      bgStyle: 'light',
      fontFamily: 'Inter',
      borderRadius: 'rounded-xl',
      density: 'comfortable',
    },
    initialScreenId: 'screen-store-home',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    annotations: [],
    screens: [
      {
        id: 'screen-store-home',
        name: 'Product Showcase & Hero',
        type: 'page',
        badge: 'Storefront',
        navBar: {
          brandName: 'HYPER / ATELIER',
          links: [
            { id: 'sn-1', label: 'New Arrivals', action: { type: 'toast', toastMessage: 'Browsing Autumn/Winter 2026 Collection', toastType: 'info' } },
            { id: 'sn-2', label: 'Audio & Acoustics', action: { type: 'toast', toastMessage: 'Flagship studio headphones loaded', toastType: 'info' } },
            { id: 'sn-3', label: 'Apparel', action: { type: 'toast', toastMessage: 'Minimalist merino outerwear', toastType: 'info' } },
          ],
          rightActions: [
            { id: 'sa-1', label: 'Cart (2)', icon: 'ShoppingBag', action: { type: 'open_modal', modalId: 'modal-cart' }, variant: 'primary' },
          ],
        },
        blocks: [
          {
            id: 'hero-store',
            type: 'hero',
            title: 'HyperSonic Pro Acoustic Headphones',
            subtitle: 'Beryllium planar-magnetic drivers, active spatial acoustic cancellation, and 48-hour lossless battery in aerospace anodized aluminum.',
            props: {
              badge: 'Exclusive 2026 Studio Flagship',
              primaryCta: 'Add to Cart — $499',
              secondaryCta: 'Explore Engineering Specs',
              metrics: [
                { label: 'Acoustic Clarity', value: '99.8% Lossless' },
                { label: 'Battery Reserve', value: '48 Hours' },
                { label: 'Weight', value: '240 Grams' },
              ],
            },
            actions: {
              onPrimaryClick: { type: 'open_modal', modalId: 'modal-cart' },
              onSecondaryClick: { type: 'toast', toastMessage: 'Acoustic specs: 5Hz - 50kHz frequency response curve', toastType: 'info' },
            },
          },
          {
            id: 'card-grid-products',
            type: 'card_grid',
            title: 'Curated Audio Ecosystem',
            subtitle: 'Engineered for audio purists and modern creators.',
            props: {
              columns: 3,
              cards: [
                { id: 'p-1', title: 'HyperDesk DAC Amp', badge: 'Best Seller', badgeColor: 'amber', description: 'Dual ESS Sabre DAC with balanced 4.4mm output.', metrics: [{ label: 'Price', value: '$349' }, { label: 'In Stock', value: 'Ready to ship' }], ctaText: 'Quick Add' },
                { id: 'p-2', title: 'HyperPod Mini Earphones', badge: 'New', badgeColor: 'green', description: 'Micro planar magnetic drivers with active transparency.', metrics: [{ label: 'Price', value: '$199' }, { label: 'In Stock', value: 'Free express delivery' }], ctaText: 'Quick Add' },
                { id: 'p-3', title: 'Titanium Headphone Stand', badge: 'Accessory', badgeColor: 'purple', description: 'Precision CNC machined aircraft-grade titanium cradle.', metrics: [{ label: 'Price', value: '$89' }, { label: 'In Stock', value: 'Ships today' }], ctaText: 'Quick Add' },
              ],
            },
            actions: {
              onCardClick: { type: 'open_modal', modalId: 'modal-cart' },
            },
          },
        ],
        modals: [
          {
            id: 'modal-cart',
            title: '🛍️ Your Shopping Cart (2 Items)',
            subtitle: 'Free worldwide express courier shipping automatically applied.',
            size: 'md',
            blocks: [
              {
                id: 'cart-items-block',
                type: 'activity_feed',
                props: {
                  items: [
                    { id: 'ci-1', title: 'HyperSonic Pro Headphones (Obsidian Black)', sub: 'Qty: 1 • Spatial Audio Edition', amount: '$499.00', type: 'income', icon: 'Headphones' },
                    { id: 'ci-2', title: 'Titanium CNC Headphone Stand', sub: 'Qty: 1 • Space Grey Finish', amount: '$89.00', type: 'income', icon: 'ShieldCheck' },
                  ],
                },
              },
              {
                id: 'cart-checkout-form',
                type: 'form_card',
                props: {
                  fields: [
                    { id: 'promo', label: 'Promo Code', type: 'text', placeholder: 'Enter code: PROTOTYPE10' },
                    { id: 'shipping-method', label: 'Delivery Speed', type: 'select', options: ['DHL Express Air (2 Days • Free)', 'Same-Day Courier (NYC/SF/LDN)'] },
                  ],
                  submitLabel: 'Proceed to Secure 1-Click Checkout ($588.00)',
                },
                actions: {
                  onSubmit: { type: 'toast', toastMessage: '💳 Order #HY-99201 confirmed! Tracking code dispatched to your email.', toastType: 'success' },
                },
              },
            ],
            closeAction: { type: 'close_modal' },
          },
        ],
      },
    ],
  },
];
