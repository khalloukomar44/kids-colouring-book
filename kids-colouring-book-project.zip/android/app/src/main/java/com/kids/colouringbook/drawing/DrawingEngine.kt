package com.kids.colouringbook.drawing

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import com.kids.colouringbook.model.BrushSize
import com.kids.colouringbook.model.StickerType
import com.kids.colouringbook.model.ToolMode
import java.util.ArrayList
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class DrawingEngine {

    var canvasWidth: Int = 1000
        private set
    var canvasHeight: Int = 1000
        private set

    var coloringBitmap: Bitmap? = null
        private set
    var outlineBitmap: Bitmap? = null
        private set

    private var coloringCanvas: Canvas? = null
    private var outlineCanvas: Canvas? = null

    // Undo / Redo Stacks (Max 20 states)
    private val undoStack = ArrayList<Bitmap>()
    private val redoStack = ArrayList<Bitmap>()
    private val MAX_HISTORY = 20

    // Drawing state
    private var lastX: Float = 0f
    private var lastY: Float = 0f
    private var currentPath = Path()
    private var rainbowHue: Float = 0f

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val stickerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 90f
    }

    private val sparklePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#FDE047")
    }

    fun initialize(width: Int, height: Int, svgDrawing: String) {
        if (width <= 0 || height <= 0) return
        canvasWidth = width
        canvasHeight = height

        // Recycle old bitmaps
        coloringBitmap?.recycle()
        outlineBitmap?.recycle()
        clearHistory()

        // Create fresh mutable coloring bitmap & outline bitmap
        coloringBitmap = Bitmap.createBitmap(canvasWidth, canvasHeight, Bitmap.Config.ARGB_8888).apply {
            eraseColor(Color.WHITE)
        }
        coloringCanvas = Canvas(coloringBitmap!!)

        outlineBitmap = Bitmap.createBitmap(canvasWidth, canvasHeight, Bitmap.Config.ARGB_8888).apply {
            eraseColor(Color.TRANSPARENT)
        }
        outlineCanvas = Canvas(outlineBitmap!!)

        // Render SVG line art into outline bitmap
        SvgOutlineRenderer.renderSvgToCanvas(svgDrawing, outlineCanvas!!, canvasWidth, canvasHeight, renderWhiteFills = false)

        // Save initial state to undo stack
        saveState()
    }

    fun startStroke(
        x: Float,
        y: Float,
        toolMode: ToolMode,
        colorInt: Int,
        brushSize: BrushSize,
        stickerType: StickerType
    ) {
        val cCanvas = coloringCanvas ?: return

        when (toolMode) {
            ToolMode.FILL -> {
                saveState()
                // Render outline on a temp combined buffer to detect boundaries for flood fill
                val combined = Bitmap.createBitmap(coloringBitmap!!)
                val tempCanvas = Canvas(combined)
                outlineBitmap?.let { tempCanvas.drawBitmap(it, 0f, 0f, null) }

                val success = FloodFill.floodFill(combined, x.toInt(), y.toInt(), colorInt)
                if (success) {
                    // Update coloring bitmap with filled area
                    cCanvas.drawBitmap(combined, 0f, 0f, null)
                }
                combined.recycle()
            }
            ToolMode.STICKER -> {
                saveState()
                drawSticker(cCanvas, x, y, stickerType)
            }
            ToolMode.BRUSH, ToolMode.CRAYON, ToolMode.RAINBOW, ToolMode.SPARKLE, ToolMode.ERASER -> {
                saveState()
                lastX = x
                lastY = y
                currentPath.reset()
                currentPath.moveTo(x, y)

                // Draw initial point
                applyStroke(x, y, x, y, toolMode, colorInt, brushSize)
            }
        }
    }

    fun continueStroke(
        x: Float,
        y: Float,
        toolMode: ToolMode,
        colorInt: Int,
        brushSize: BrushSize
    ) {
        if (toolMode == ToolMode.FILL || toolMode == ToolMode.STICKER) return

        applyStroke(lastX, lastY, x, y, toolMode, colorInt, brushSize)
        lastX = x
        lastY = y
    }

    fun endStroke() {
        currentPath.reset()
    }

    private fun applyStroke(
        fromX: Float,
        fromY: Float,
        toX: Float,
        toY: Float,
        toolMode: ToolMode,
        colorInt: Int,
        brushSize: BrushSize
    ) {
        val cCanvas = coloringCanvas ?: return
        val scale = canvasWidth / 500f
        val strokeWidth = brushSize.strokeWidth * scale

        when (toolMode) {
            ToolMode.BRUSH -> {
                strokePaint.color = colorInt
                strokePaint.strokeWidth = strokeWidth
                strokePaint.xfermode = null
                strokePaint.alpha = 255
                cCanvas.drawLine(fromX, fromY, toX, toY, strokePaint)
                cCanvas.drawCircle(toX, toY, strokeWidth / 2f, Paint(strokePaint).apply { style = Paint.Style.FILL })
            }
            ToolMode.CRAYON -> {
                strokePaint.color = colorInt
                strokePaint.strokeWidth = strokeWidth * 1.1f
                strokePaint.xfermode = null
                strokePaint.alpha = 190 + Random.nextInt(55)

                // Chalk jitter
                val jitterX = (Random.nextFloat() - 0.5f) * (strokeWidth * 0.2f)
                val jitterY = (Random.nextFloat() - 0.5f) * (strokeWidth * 0.2f)
                cCanvas.drawLine(fromX, fromY, toX + jitterX, toY + jitterY, strokePaint)
            }
            ToolMode.RAINBOW -> {
                rainbowHue = (rainbowHue + 4f) % 360f
                val hsvColor = Color.HSVToColor(floatArrayOf(rainbowHue, 0.9f, 1f))
                strokePaint.color = hsvColor
                strokePaint.strokeWidth = strokeWidth
                strokePaint.xfermode = null
                strokePaint.alpha = 255
                cCanvas.drawLine(fromX, fromY, toX, toY, strokePaint)
                cCanvas.drawCircle(toX, toY, strokeWidth / 2f, Paint(strokePaint).apply { style = Paint.Style.FILL })
            }
            ToolMode.SPARKLE -> {
                strokePaint.color = colorInt
                strokePaint.strokeWidth = strokeWidth
                strokePaint.xfermode = null
                strokePaint.alpha = 230
                cCanvas.drawLine(fromX, fromY, toX, toY, strokePaint)

                // Random twinkling stars along stroke
                if (Random.nextFloat() < 0.4f) {
                    val starSize = strokeWidth * (0.8f + Random.nextFloat() * 0.6f)
                    val starX = toX + (Random.nextFloat() - 0.5f) * strokeWidth * 2
                    val starY = toY + (Random.nextFloat() - 0.5f) * strokeWidth * 2
                    drawStar(cCanvas, starX, starY, starSize)
                }
            }
            ToolMode.ERASER -> {
                strokePaint.color = Color.WHITE
                strokePaint.strokeWidth = strokeWidth * 1.4f
                strokePaint.xfermode = null
                strokePaint.alpha = 255
                cCanvas.drawLine(fromX, fromY, toX, toY, strokePaint)
                cCanvas.drawCircle(toX, toY, (strokeWidth * 1.4f) / 2f, Paint(strokePaint).apply { style = Paint.Style.FILL })
            }
            else -> {}
        }
    }

    private fun drawStar(canvas: Canvas, cx: Float, cy: Float, size: Float) {
        val path = Path()
        val spikes = 5
        val outerRadius = size / 2f
        val innerRadius = outerRadius / 2f
        var rot = (Math.PI / 2 * 3).toFloat()
        val step = (Math.PI / spikes).toFloat()

        path.moveTo(cx, cy - outerRadius)
        for (i in 0 until spikes) {
            var x = cx + cos(rot) * outerRadius
            var y = cy + sin(rot) * outerRadius
            path.lineTo(x, y)
            rot += step

            x = cx + cos(rot) * innerRadius
            y = cy + sin(rot) * innerRadius
            path.lineTo(x, y)
            rot += step
        }
        path.close()
        canvas.drawPath(path, sparklePaint)
    }

    private fun drawSticker(canvas: Canvas, x: Float, y: Float, sticker: StickerType) {
        stickerPaint.textSize = (canvasWidth / 500f) * 70f
        canvas.drawText(sticker.emoji, x, y + (stickerPaint.textSize / 3f), stickerPaint)
    }

    private fun saveState() {
        val current = coloringBitmap ?: return
        redoStack.clear()
        if (undoStack.size >= MAX_HISTORY) {
            val removed = undoStack.removeAt(0)
            removed.recycle()
        }
        undoStack.add(Bitmap.createBitmap(current))
    }

    fun canUndo(): Boolean = undoStack.size > 1

    fun canRedo(): Boolean = redoStack.isNotEmpty()

    fun undo() {
        if (!canUndo()) return
        val current = coloringBitmap ?: return
        redoStack.add(Bitmap.createBitmap(current))

        undoStack.removeAt(undoStack.size - 1)
        val previous = undoStack.last()

        val cCanvas = coloringCanvas ?: return
        cCanvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC)
        cCanvas.drawBitmap(previous, 0f, 0f, null)
    }

    fun redo() {
        if (!canRedo()) return
        val next = redoStack.removeAt(redoStack.size - 1)
        undoStack.add(Bitmap.createBitmap(next))

        val cCanvas = coloringCanvas ?: return
        cCanvas.drawColor(Color.WHITE, PorterDuff.Mode.SRC)
        cCanvas.drawBitmap(next, 0f, 0f, null)
    }

    fun clearCanvas() {
        saveState()
        coloringCanvas?.drawColor(Color.WHITE, PorterDuff.Mode.SRC)
    }

    fun getMergedArtworkBitmap(): Bitmap {
        val merged = Bitmap.createBitmap(canvasWidth, canvasHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(merged)
        coloringBitmap?.let { canvas.drawBitmap(it, 0f, 0f, null) }
        outlineBitmap?.let { canvas.drawBitmap(it, 0f, 0f, null) }
        return merged
    }

    private fun clearHistory() {
        for (b in undoStack) b.recycle()
        for (b in redoStack) b.recycle()
        undoStack.clear()
        redoStack.clear()
    }
}
