import React, { useState, useEffect } from 'react';
import { ANIMAL_PAGES, CATEGORIES } from '../data/animals';
import { AnimalPage } from '../types/colouring';
import { sounds } from '../utils/soundEffects';
import { Sparkles, Palette, Play, Image as ImageIcon, Volume2, VolumeX, Heart, Star } from 'lucide-react';

interface HomePageProps {
  onSelectAnimal: (animal: AnimalPage) => void;
  onOpenGallery: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onSelectAnimal, onOpenGallery }) => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [soundEnabled, setSoundEnabled] = useState(sounds.enabled);
  const [savedCount, setSavedCount] = useState(0);
  const [coloredAnimals, setColoredAnimals] = useState<Record<string, boolean>>({});

  useEffect(() => {
    // Check local storage for colored animals and gallery count
    try {
      const gallery = JSON.parse(localStorage.getItem('kids_colouring_gallery') || '[]');
      setSavedCount(gallery.length);

      const colored: Record<string, boolean> = {};
      ANIMAL_PAGES.forEach((animal) => {
        if (localStorage.getItem(`kids_art_${animal.id}`)) {
          colored[animal.id] = true;
        }
      });
      setColoredAnimals(colored);
    } catch {
      // ignore
    }
  }, []);

  const toggleSound = () => {
    sounds.enabled = !soundEnabled;
    setSoundEnabled(!soundEnabled);
    if (!soundEnabled) sounds.playPop(520);
  };

  const filteredAnimals =
    selectedCategory === 'all'
      ? ANIMAL_PAGES
      : ANIMAL_PAGES.filter((a) => a.category === selectedCategory);

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-100 via-orange-50 to-pink-100 text-slate-800 pb-16 select-none">
      {/* Playful Floating Background Decorations */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden opacity-30 z-0">
        <div className="absolute top-8 left-10 text-5xl animate-float-slow">☁️</div>
        <div className="absolute top-20 right-12 text-6xl animate-bounce-subtle">☀️</div>
        <div className="absolute top-64 left-6 text-4xl animate-float-slow">🎈</div>
        <div className="absolute top-96 right-8 text-5xl animate-wiggle">🌈</div>
        <div className="absolute bottom-20 left-16 text-5xl animate-float-slow">⭐</div>
        <div className="absolute bottom-32 right-20 text-4xl animate-bounce-subtle">✨</div>
      </div>

      {/* Top Navbar */}
      <nav className="relative z-10 max-w-5xl mx-auto px-4 pt-4 pb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-pink-500 to-amber-400 flex items-center justify-center text-2xl shadow-lg border-2 border-white animate-wiggle">
            🎨
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-amber-950 tracking-tight leading-none">
              Colouring Book for Kids
            </h1>
            <p className="text-xs font-bold text-amber-700">20 Cute Animals • Free to Play</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* My Saved Gallery Button */}
          <button
            onClick={() => {
              sounds.playPop(480);
              onOpenGallery();
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-white text-slate-800 font-black text-xs sm:text-sm btn-3d shadow-md hover:bg-amber-50 border-2 border-amber-300"
          >
            <ImageIcon className="w-4 h-4 text-amber-500" />
            <span className="hidden xs:inline">My Gallery</span>
            {savedCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-rose-500 text-white text-[10px] flex items-center justify-center font-black">
                {savedCount}
              </span>
            )}
          </button>

          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            className={`p-2.5 rounded-2xl btn-3d transition-all ${
              soundEnabled
                ? 'bg-emerald-400 text-emerald-950'
                : 'bg-slate-200 text-slate-400'
            }`}
            title={soundEnabled ? 'Sound On' : 'Sound Off'}
          >
            {soundEnabled ? (
              <Volume2 className="w-5 h-5 stroke-[2.5]" />
            ) : (
              <VolumeX className="w-5 h-5 stroke-[2.5]" />
            )}
          </button>
        </div>
      </nav>

      {/* Hero Welcome Banner */}
      <header className="relative z-10 max-w-4xl mx-auto px-4 text-center mt-3 mb-6">
        <div className="relative bg-gradient-to-r from-amber-400 via-pink-400 to-purple-500 rounded-3xl p-5 sm:p-7 shadow-2xl text-white border-4 border-white ring-4 ring-amber-200 overflow-hidden">
          <div className="relative z-10 flex flex-col items-center">
            <div className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-white/20 backdrop-blur-xs font-black text-xs sm:text-sm mb-2 shadow-sm">
              <Sparkles className="w-4 h-4 text-yellow-200 animate-spin" />
              <span>TOUCH & DRAG COLOURING FUN!</span>
            </div>

            <h2 className="text-3xl sm:text-5xl font-black mb-2 tracking-tight drop-shadow-md">
              Pick an Animal to Colour! 🦁✨
            </h2>
            <p className="text-amber-100 font-bold text-sm sm:text-base max-w-lg mb-4 drop-shadow">
              Choose from 20 cute animal friends! Use rainbow magic brushes, glitter sparkles, tap-to-fill, and colorful stickers.
            </p>

            <button
              onClick={() => {
                // Random cute animal or first
                const randAnimal = ANIMAL_PAGES[Math.floor(Math.random() * ANIMAL_PAGES.length)];
                sounds.playMagic();
                onSelectAnimal(randAnimal);
              }}
              className="px-6 py-3.5 rounded-2xl bg-white text-purple-700 font-black text-base sm:text-lg btn-3d shadow-xl hover:scale-105 transition-all flex items-center gap-2 ring-4 ring-white/50"
            >
              <Play className="w-5 h-5 fill-current text-purple-600" />
              <span>Surprise Me! (Quick Start)</span>
            </button>
          </div>
        </div>
      </header>

      {/* Category Tabs */}
      <section className="relative z-10 max-w-5xl mx-auto px-4 mb-6">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-2">
          {CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => {
                  sounds.playPop(450);
                  setSelectedCategory(cat.id);
                }}
                className={`flex items-center gap-1.5 px-4 py-2.5 rounded-2xl font-black text-sm sm:text-base btn-3d shrink-0 transition-all ${
                  isSelected
                    ? 'bg-amber-500 text-white ring-4 ring-amber-300 scale-105 shadow-md'
                    : 'bg-white text-slate-700 hover:bg-amber-50 border-2 border-amber-200'
                }`}
              >
                <span className="text-lg">{cat.emoji}</span>
                <span>{cat.label}</span>
                <span
                  className={`text-xs px-2 py-0.5 rounded-full font-black ${
                    isSelected ? 'bg-amber-700 text-white' : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {cat.count}
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* 20 Cute Animal Cards Grid */}
      <main className="relative z-10 max-w-5xl mx-auto px-4">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 sm:gap-5">
          {filteredAnimals.map((animal, idx) => {
            const isColored = coloredAnimals[animal.id];

            return (
              <div
                key={animal.id}
                onClick={() => {
                  sounds.playPop(520 + (idx % 8) * 30);
                  onSelectAnimal(animal);
                }}
                className="group relative bg-white rounded-3xl p-3 sm:p-4 shadow-xl border-4 border-amber-200 hover:border-amber-400 hover:shadow-2xl transition-all duration-200 btn-3d cursor-pointer flex flex-col items-center text-center"
              >
                {/* Animal Colored Status Badge */}
                {isColored && (
                  <div className="absolute top-2.5 right-2.5 z-20 px-2 py-0.5 rounded-full bg-emerald-500 text-white text-[10px] font-black flex items-center gap-1 shadow">
                    <span>✓</span> Colored!
                  </div>
                )}

                {/* Card Thumbnail Art Viewport */}
                <div className="relative w-full aspect-square bg-gradient-to-b from-amber-50 to-orange-50 rounded-2xl overflow-hidden mb-3 border-2 border-amber-100 p-2 flex items-center justify-center">
                  <div
                    className="w-full h-full transform group-hover:scale-108 transition-transform duration-300"
                    dangerouslySetInnerHTML={{ __html: animal.svgDrawing }}
                  />

                  {/* Play Overlay */}
                  <div className="absolute inset-0 bg-amber-900/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <div className="w-12 h-12 rounded-full bg-amber-500 text-white flex items-center justify-center shadow-xl transform scale-75 group-hover:scale-100 transition-transform">
                      <Play className="w-6 h-6 fill-current translate-x-0.5" />
                    </div>
                  </div>
                </div>

                {/* Animal Title & Emoji */}
                <div className="w-full">
                  <div className="flex items-center justify-center gap-1 mb-0.5">
                    <span className="text-xl">{animal.emoji}</span>
                    <h3 className="font-black text-sm sm:text-base text-slate-800 truncate">
                      {animal.name}
                    </h3>
                  </div>
                  <p className="text-[11px] font-bold text-slate-400 line-clamp-1">
                    {animal.subtitle}
                  </p>
                </div>

                {/* Big Kid-Friendly Start Button */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    sounds.playPop(550);
                    onSelectAnimal(animal);
                  }}
                  className="w-full mt-3 py-2 px-3 rounded-xl bg-gradient-to-r from-amber-400 to-orange-400 text-amber-950 font-black text-xs sm:text-sm btn-3d shadow flex items-center justify-center gap-1 hover:brightness-105"
                >
                  <Palette className="w-3.5 h-3.5 text-amber-950" />
                  <span>Colour Now</span>
                </button>
              </div>
            );
          })}
        </div>
      </main>

      {/* Footer Info */}
      <footer className="relative z-10 max-w-4xl mx-auto px-4 text-center mt-12 text-slate-500 text-xs font-bold">
        <p className="mb-1">🎨 Made with love for happy little artists • 100% Free & Kid Safe</p>
        <p className="text-slate-400 text-[10px]">Works offline on phones, tablets & computers</p>
      </footer>
    </div>
  );
};
