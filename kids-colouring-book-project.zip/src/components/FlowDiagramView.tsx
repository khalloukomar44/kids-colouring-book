import React from 'react';
import { Layers, ArrowRight, Play, Sparkles, ExternalLink, Plus } from 'lucide-react';
import { PrototypeProject, Screen } from '../types/prototype';

interface FlowDiagramViewProps {
  project: PrototypeProject;
  activeScreenId: string;
  onSelectScreen: (screenId: string) => void;
  onOpenAIModal: (tab: 'generate' | 'refine' | 'add-screen' | 'audit' | 'ab-test') => void;
}

export const FlowDiagramView: React.FC<FlowDiagramViewProps> = ({
  project,
  activeScreenId,
  onSelectScreen,
  onOpenAIModal,
}) => {
  return (
    <div className="flex-1 bg-[#060911] overflow-auto p-8 relative flex flex-col items-center select-none">
      {/* Blueprint Grid */}
      <div 
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, #6366f1 1px, transparent 0)`,
          backgroundSize: '24px 24px',
        }}
      />

      <div className="max-w-6xl w-full space-y-8 z-10">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/60 p-6 rounded-3xl border border-slate-800/80 backdrop-blur-md">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <Layers className="w-5 h-5 text-indigo-400" />
              <h2 className="text-lg font-bold text-white">Interactive Flow Topology</h2>
            </div>
            <p className="text-xs text-slate-400">
              Visual map of all {project.screens.length} screens and their clickable hotspots.
            </p>
          </div>

          <button
            onClick={() => onOpenAIModal('add-screen')}
            className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center space-x-2 transition-all"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Generate Connected Screen</span>
          </button>
        </div>

        {/* Screens Flow Grid / Graph */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {project.screens.map((screen, index) => {
            const isActive = screen.id === activeScreenId;
            const isInitial = screen.id === project.initialScreenId;

            // Find all outgoing transitions from this screen
            const outgoingTargets = new Set<string>();
            screen.navBar?.links?.forEach((l) => {
              if (l.action.type === 'navigate' && l.action.targetScreenId) {
                outgoingTargets.add(l.action.targetScreenId);
              }
            });
            screen.sideBar?.items?.forEach((i) => {
              if (i.action.type === 'navigate' && i.action.targetScreenId) {
                outgoingTargets.add(i.action.targetScreenId);
              }
            });
            screen.blocks?.forEach((b) => {
              if (b.actions) {
                Object.values(b.actions).forEach((act: any) => {
                  if (act && act.type === 'navigate' && act.targetScreenId) {
                    outgoingTargets.add(act.targetScreenId);
                  }
                });
              }
            });

            return (
              <div
                key={screen.id}
                onClick={() => onSelectScreen(screen.id)}
                className={`p-5 rounded-3xl border transition-all cursor-pointer flex flex-col justify-between space-y-4 relative ${
                  isActive
                    ? 'bg-slate-900/90 border-indigo-500 shadow-2xl shadow-indigo-950/80 ring-2 ring-indigo-500/40'
                    : 'bg-slate-900/40 border-slate-800/80 hover:border-slate-700 hover:bg-slate-900/70'
                }`}
              >
                {/* Initial Screen Badge */}
                {isInitial && (
                  <span className="absolute -top-3 left-6 px-3 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500 text-slate-950 shadow-md">
                    STARTING SCREEN
                  </span>
                )}

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2.5">
                      <span className="w-6 h-6 rounded-full bg-slate-800 text-xs font-mono font-bold flex items-center justify-center text-indigo-400">
                        {index + 1}
                      </span>
                      <h3 className="font-bold text-sm text-white">{screen.name}</h3>
                    </div>

                    <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                      {screen.type}
                    </span>
                  </div>

                  {/* Blocks preview summary */}
                  <div className="space-y-1.5 pt-2">
                    <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      Blocks ({screen.blocks.length})
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {screen.blocks.map((b) => (
                        <span
                          key={b.id}
                          className="text-[10px] px-2 py-0.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 font-mono"
                        >
                          {b.type}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Connected Nav Links */}
                  {outgoingTargets.size > 0 && (
                    <div className="pt-2 border-t border-slate-800/80 space-y-1">
                      <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                        Outgoing Transitions
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {Array.from(outgoingTargets).map((targetId) => {
                          const targetScreen = project.screens.find((s) => s.id === targetId);
                          return (
                            <span
                              key={targetId}
                              className="text-[10px] px-2 py-0.5 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 flex items-center space-x-1"
                            >
                              <ArrowRight className="w-3 h-3" />
                              <span>{targetScreen?.name || targetId}</span>
                            </span>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-medium">Click to inspect</span>
                  <div className="flex items-center space-x-1 text-indigo-400 font-semibold group-hover:translate-x-1 transition-transform">
                    <span>Open</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
