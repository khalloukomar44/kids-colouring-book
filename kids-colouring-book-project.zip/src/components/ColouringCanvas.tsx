import React, { useRef, useEffect, useState, useCallback } from 'react';
import { AnimalPage, ToolMode, BrushSize, StickerType } from '../types/colouring';
import { sounds } from '../utils/soundEffects';

interface ColouringCanvasProps {
  animal: AnimalPage;
  currentColor: string;
  toolMode: ToolMode;
  brushSize: BrushSize;
  activeSticker: StickerType;
  onHistoryChange?: (canUndo: boolean, canRedo: boolean) => void;
  undoTrigger?: number;
  redoTrigger?: number;
  clearTrigger?: number;
  canvasRefCallback?: (getCanvasDataUrl: () => string) => void;
}

const BRUSH_WIDTHS: Record<BrushSize, number> = {
  small: 8,
  medium: 18,
  large: 32,
  giant: 52,
};

export const ColouringCanvas: React.FC<ColouringCanvasProps> = ({
  animal,
  currentColor,
  toolMode,
  brushSize,
  activeSticker,
  onHistoryChange,
  undoTrigger,
  redoTrigger,
  clearTrigger,
  canvasRefCallback,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const paintCanvasRef = useRef<HTMLCanvasElement>(null);
  const outlineCanvasRef = useRef<HTMLCanvasElement>(null);

  const isDrawingRef = useRef(false);
  const lastPointRef = useRef<{ x: number; y: number } | null>(null);
  const rainbowHueRef = useRef(0);
  const [outlineLoaded, setOutlineLoaded] = useState(false);

  // Undo/Redo History
  const historyStackRef = useRef<ImageData[]>([]);
  const historyIndexRef = useRef<number>(-1);
  const maxHistory = 15;

  const width = 500;
  const height = 500;

  // Save current paint canvas state to history
  const pushHistory = useCallback(() => {
    const canvas = paintCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    // Truncate redo states
    const newStack = historyStackRef.current.slice(0, historyIndexRef.current + 1);
    newStack.push(imageData);
    if (newStack.length > maxHistory) {
      newStack.shift();
    } else {
      historyIndexRef.current++;
    }
    historyStackRef.current = newStack;

    if (onHistoryChange) {
      onHistoryChange(historyIndexRef.current > 0, historyIndexRef.current < newStack.length - 1);
    }

    // Also auto-save to localStorage
    try {
      localStorage.setItem(`kids_art_${animal.id}`, canvas.toDataURL());
    } catch {
      // quota or private mode
    }
  }, [animal.id, onHistoryChange]);

  // Load animal outline onto Outline Canvas
  useEffect(() => {
    setOutlineLoaded(false);
    const outlineCanvas = outlineCanvasRef.current;
    const paintCanvas = paintCanvasRef.current;
    if (!outlineCanvas || !paintCanvas) return;

    const outCtx = outlineCanvas.getContext('2d');
    const paintCtx = paintCanvas.getContext('2d');
    if (!outCtx || !paintCtx) return;

    // Reset paint canvas with white background or restore saved progress
    const saved = localStorage.getItem(`kids_art_${animal.id}`);

    const loadSavedOrBlank = () => {
      paintCtx.fillStyle = '#FFFFFF';
      paintCtx.fillRect(0, 0, width, height);

      if (saved) {
        const img = new Image();
        img.onload = () => {
          paintCtx.drawImage(img, 0, 0, width, height);
          const initial = paintCtx.getImageData(0, 0, width, height);
          historyStackRef.current = [initial];
          historyIndexRef.current = 0;
          if (onHistoryChange) onHistoryChange(false, false);
        };
        img.src = saved;
      } else {
        const initial = paintCtx.getImageData(0, 0, width, height);
        historyStackRef.current = [initial];
        historyIndexRef.current = 0;
        if (onHistoryChange) onHistoryChange(false, false);
      }
    };

    loadSavedOrBlank();

    // Render SVG line art into outline canvas
    const svgBlob = new Blob([animal.svgDrawing], { type: 'image/svg+xml;charset=utf-8' });
    const blobURL = URL.createObjectURL(svgBlob);
    const outlineImg = new Image();

    outlineImg.onload = () => {
      outCtx.clearRect(0, 0, width, height);
      outCtx.drawImage(outlineImg, 0, 0, width, height);
      URL.revokeObjectURL(blobURL);
      setOutlineLoaded(true);
    };
    outlineImg.src = blobURL;
  }, [animal.id, animal.svgDrawing, onHistoryChange]);

  // Undo Handler
  useEffect(() => {
    if (undoTrigger === undefined || undoTrigger === 0) return;
    if (historyIndexRef.current > 0) {
      historyIndexRef.current--;
      const canvas = paintCanvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.putImageData(historyStackRef.current[historyIndexRef.current], 0, 0);
      sounds.playPop(350);
      if (onHistoryChange) {
        onHistoryChange(historyIndexRef.current > 0, historyIndexRef.current < historyStackRef.current.length - 1);
      }
    }
  }, [undoTrigger, onHistoryChange]);

  // Redo Handler
  useEffect(() => {
    if (redoTrigger === undefined || redoTrigger === 0) return;
    if (historyIndexRef.current < historyStackRef.current.length - 1) {
      historyIndexRef.current++;
      const canvas = paintCanvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.putImageData(historyStackRef.current[historyIndexRef.current], 0, 0);
      sounds.playPop(480);
      if (onHistoryChange) {
        onHistoryChange(historyIndexRef.current > 0, historyIndexRef.current < historyStackRef.current.length - 1);
      }
    }
  }, [redoTrigger, onHistoryChange]);

  // Clear Handler
  useEffect(() => {
    if (clearTrigger === undefined || clearTrigger === 0) return;
    const canvas = paintCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, width, height);
    pushHistory();
    sounds.playClear();
    try {
      localStorage.removeItem(`kids_art_${animal.id}`);
    } catch {
      // ignore
    }
  }, [clearTrigger, animal.id, pushHistory]);

  // Export combined high-res canvas (paint + outline + border)
  useEffect(() => {
    if (!canvasRefCallback) return;
    canvasRefCallback(() => {
      const exportCanvas = document.createElement('canvas');
      exportCanvas.width = width;
      exportCanvas.height = height;
      const expCtx = exportCanvas.getContext('2d');
      if (!expCtx) return '';

      // Draw background
      expCtx.fillStyle = '#FFFFFF';
      expCtx.fillRect(0, 0, width, height);

      // Draw paint layer
      if (paintCanvasRef.current) {
        expCtx.drawImage(paintCanvasRef.current, 0, 0);
      }

      // Draw outline layer on top
      if (outlineCanvasRef.current) {
        expCtx.drawImage(outlineCanvasRef.current, 0, 0);
      }

      return exportCanvas.toDataURL('image/png');
    });
  }, [canvasRefCallback]);

  // Convert client touch/mouse coordinates to canvas pixel space
  const getCanvasCoords = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = paintCanvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  };

  // Flood Fill Algorithm for Bucket Tool
  const floodFill = (startX: number, startY: number, fillColorHex: string) => {
    const paintCanvas = paintCanvasRef.current;
    const outlineCanvas = outlineCanvasRef.current;
    if (!paintCanvas || !outlineCanvas) return;

    const pCtx = paintCanvas.getContext('2d');
    const oCtx = outlineCanvas.getContext('2d');
    if (!pCtx || !oCtx) return;

    const w = paintCanvas.width;
    const h = paintCanvas.height;

    // Get combined pixel data to detect black outlines
    const paintImg = pCtx.getImageData(0, 0, w, h);
    const outlineImg = oCtx.getImageData(0, 0, w, h);
    const pData = paintImg.data;
    const oData = outlineImg.data;

    // Parse fill color
    const tempDiv = document.createElement('div');
    tempDiv.style.color = fillColorHex;
    document.body.appendChild(tempDiv);
    const rgbStr = window.getComputedStyle(tempDiv).color;
    document.body.removeChild(tempDiv);
    const rgbMatch = rgbStr.match(/\d+/g);
    const fillR = rgbMatch ? parseInt(rgbMatch[0]) : 255;
    const fillG = rgbMatch ? parseInt(rgbMatch[1]) : 100;
    const fillB = rgbMatch ? parseInt(rgbMatch[2]) : 100;
    const fillA = 255;

    const x0 = Math.floor(startX);
    const y0 = Math.floor(startY);
    if (x0 < 0 || x0 >= w || y0 < 0 || y0 >= h) return;

    const startIdx = (y0 * w + x0) * 4;

    // Target start color on paint canvas
    const targetR = pData[startIdx];
    const targetG = pData[startIdx + 1];
    const targetB = pData[startIdx + 2];
    const targetA = pData[startIdx + 3];

    // If already the same color, skip
    if (targetR === fillR && targetG === fillG && targetB === fillB) return;

    // Helper: is this pixel an outline boundary?
    // In outline layer: dark stroke means black/gray
    const isBoundary = (idx: number) => {
      const alpha = oData[idx + 3];
      if (alpha > 80) {
        const r = oData[idx];
        const g = oData[idx + 1];
        const b = oData[idx + 2];
        // If it's dark line art
        if (r < 100 && g < 100 && b < 100) return true;
      }
      return false;
    };

    if (isBoundary(startIdx)) return;

    const colorMatch = (idx: number) => {
      if (isBoundary(idx)) return false;
      const r = pData[idx];
      const g = pData[idx + 1];
      const b = pData[idx + 2];
      const a = pData[idx + 3];

      // Tolerance check
      return (
        Math.abs(r - targetR) < 32 &&
        Math.abs(g - targetG) < 32 &&
        Math.abs(b - targetB) < 32 &&
        Math.abs(a - targetA) < 32
      );
    };

    // Scanline flood fill with stack
    const pixelStack: [number, number][] = [[x0, y0]];
    const visited = new Uint8Array(w * h);

    while (pixelStack.length > 0) {
      const [curX, curY] = pixelStack.pop()!;
      let y1 = curY;
      let idx = (y1 * w + curX) * 4;

      while (y1 >= 0 && colorMatch(idx) && !visited[y1 * w + curX]) {
        y1--;
        idx -= w * 4;
      }
      y1++;
      idx += w * 4;

      let spanLeft = false;
      let spanRight = false;

      while (y1 < h && colorMatch(idx) && !visited[y1 * w + curX]) {
        visited[y1 * w + curX] = 1;
        pData[idx] = fillR;
        pData[idx + 1] = fillG;
        pData[idx + 2] = fillB;
        pData[idx + 3] = fillA;

        // Left neighbor
        if (curX > 0) {
          const leftIdx = idx - 4;
          if (colorMatch(leftIdx) && !visited[y1 * w + (curX - 1)]) {
            if (!spanLeft) {
              pixelStack.push([curX - 1, y1]);
              spanLeft = true;
            }
          } else if (spanLeft) {
            spanLeft = false;
          }
        }

        // Right neighbor
        if (curX < w - 1) {
          const rightIdx = idx + 4;
          if (colorMatch(rightIdx) && !visited[y1 * w + (curX + 1)]) {
            if (!spanRight) {
              pixelStack.push([curX + 1, y1]);
              spanRight = true;
            }
          } else if (spanRight) {
            spanRight = false;
          }
        }

        y1++;
        idx += w * 4;
      }
    }

    pCtx.putImageData(paintImg, 0, 0);
    pushHistory();
    sounds.playFill();
  };

  // Stamp a sticker emoji on canvas
  const stampSticker = (x: number, y: number, sticker: StickerType) => {
    const canvas = paintCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const emojiMap: Record<StickerType, string> = {
      star: '⭐',
      heart: '💖',
      rainbow: '🌈',
      paw: '🐾',
      flower: '🌸',
      sparkle: '✨',
      crown: '👑',
      balloon: '🎈',
    };

    const emoji = emojiMap[sticker] || '⭐';
    ctx.save();
    ctx.font = '48px "Segoe UI Emoji", "Apple Color Emoji", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0, 0, 0, 0.2)';
    ctx.shadowBlur = 8;
    ctx.fillText(emoji, x, y);
    ctx.restore();

    pushHistory();
    sounds.playSticker();
  };

  // Draw sparkle particle
  const drawSparkle = (ctx: CanvasRenderingContext2D, x: number, y: number, size: number) => {
    ctx.save();
    ctx.fillStyle = `hsl(${Math.random() * 360}, 100%, 75%)`;
    ctx.shadowColor = '#FFE600';
    ctx.shadowBlur = 10;
    const r = size * (0.4 + Math.random() * 0.6);

    // Draw little four-point star
    ctx.beginPath();
    ctx.moveTo(x, y - r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.quadraticCurveTo(x, y, x, y + r);
    ctx.quadraticCurveTo(x, y, x - r, y);
    ctx.quadraticCurveTo(x, y, x, y - r);
    ctx.fill();

    // Extra little dot
    ctx.beginPath();
    ctx.arc(x + (Math.random() - 0.5) * 20, y + (Math.random() - 0.5) * 20, 2.5, 0, Math.PI * 2);
    ctx.fillStyle = '#FFFFFF';
    ctx.fill();
    ctx.restore();
  };

  // Pointer Down (Mouse, Touch, Stylus)
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    (e.target as HTMLCanvasElement).setPointerCapture(e.pointerId);

    const { x, y } = getCanvasCoords(e);

    if (toolMode === 'fill') {
      floodFill(x, y, currentColor);
      return;
    }

    if (toolMode === 'sticker') {
      stampSticker(x, y, activeSticker);
      return;
    }

    isDrawingRef.current = true;
    lastPointRef.current = { x, y };

    const canvas = paintCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.save();
    const baseWidth = BRUSH_WIDTHS[brushSize];

    if (toolMode === 'eraser') {
      ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.arc(x, y, baseWidth / 2, 0, Math.PI * 2);
      ctx.fill();
      sounds.playEraser();
    } else if (toolMode === 'rainbow') {
      rainbowHueRef.current = (rainbowHueRef.current + 25) % 360;
      ctx.fillStyle = `hsl(${rainbowHueRef.current}, 100%, 55%)`;
      ctx.beginPath();
      ctx.arc(x, y, baseWidth / 2, 0, Math.PI * 2);
      ctx.fill();
      sounds.playMagic();
    } else if (toolMode === 'sparkle') {
      drawSparkle(ctx, x, y, baseWidth);
      sounds.playMagic();
    } else if (toolMode === 'crayon') {
      ctx.fillStyle = currentColor;
      ctx.globalAlpha = 0.65;
      ctx.beginPath();
      ctx.arc(x, y, baseWidth / 2, 0, Math.PI * 2);
      ctx.fill();
    } else {
      // Normal brush
      ctx.fillStyle = currentColor;
      ctx.beginPath();
      ctx.arc(x, y, baseWidth / 2, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  };

  // Pointer Move
  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current || !lastPointRef.current) return;
    e.preventDefault();

    const { x, y } = getCanvasCoords(e);
    const canvas = paintCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const baseWidth = BRUSH_WIDTHS[brushSize];
    const prev = lastPointRef.current;

    ctx.save();
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (toolMode === 'eraser') {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = baseWidth * 1.3;
      ctx.beginPath();
      ctx.moveTo(prev.x, prev.y);
      ctx.lineTo(x, y);
      ctx.stroke();
    } else if (toolMode === 'rainbow') {
      rainbowHueRef.current = (rainbowHueRef.current + 4) % 360;
      ctx.strokeStyle = `hsl(${rainbowHueRef.current}, 100%, 55%)`;
      ctx.lineWidth = baseWidth;
      ctx.beginPath();
      ctx.moveTo(prev.x, prev.y);
      ctx.lineTo(x, y);
      ctx.stroke();
    } else if (toolMode === 'sparkle') {
      // Sparkle line + glittering stars along the path
      rainbowHueRef.current = (rainbowHueRef.current + 10) % 360;
      ctx.strokeStyle = `hsl(${rainbowHueRef.current}, 90%, 65%)`;
      ctx.lineWidth = baseWidth * 0.6;
      ctx.beginPath();
      ctx.moveTo(prev.x, prev.y);
      ctx.lineTo(x, y);
      ctx.stroke();

      if (Math.random() > 0.4) {
        drawSparkle(ctx, x + (Math.random() - 0.5) * 15, y + (Math.random() - 0.5) * 15, baseWidth);
      }
    } else if (toolMode === 'crayon') {
      // Textured pastel crayon stroke
      ctx.strokeStyle = currentColor;
      ctx.lineWidth = baseWidth;
      ctx.globalAlpha = 0.5;
      ctx.beginPath();
      ctx.moveTo(prev.x, prev.y);
      ctx.lineTo(x, y);
      ctx.stroke();

      // Granular scatter
      for (let i = 0; i < 3; i++) {
        const ox = (Math.random() - 0.5) * (baseWidth * 0.8);
        const oy = (Math.random() - 0.5) * (baseWidth * 0.8);
        ctx.fillStyle = currentColor;
        ctx.beginPath();
        ctx.arc(x + ox, y + oy, 1.5 + Math.random() * 2, 0, Math.PI * 2);
        ctx.fill();
      }
    } else {
      // Smooth paint marker
      ctx.strokeStyle = currentColor;
      ctx.lineWidth = baseWidth;
      ctx.beginPath();
      ctx.moveTo(prev.x, prev.y);
      ctx.lineTo(x, y);
      ctx.stroke();
    }

    ctx.restore();
    lastPointRef.current = { x, y };
  };

  // Pointer Up / Cancel
  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawingRef.current) return;
    try {
      (e.target as HTMLCanvasElement).releasePointerCapture(e.pointerId);
    } catch {
      // ignore
    }
    isDrawingRef.current = false;
    lastPointRef.current = null;
    pushHistory();
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full max-w-[500px] aspect-square mx-auto rounded-3xl overflow-hidden shadow-2xl bg-white border-4 border-amber-300 ring-4 ring-amber-100 select-none touch-none"
    >
      {/* Loading state indicator */}
      {!outlineLoaded && (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-amber-50/90 backdrop-blur-xs">
          <div className="text-5xl animate-bounce mb-2">{animal.emoji}</div>
          <span className="text-amber-800 font-bold text-lg">Loading {animal.name}...</span>
        </div>
      )}

      {/* Layer 1: Child's Painting Canvas */}
      <canvas
        ref={paintCanvasRef}
        width={width}
        height={height}
        className="absolute inset-0 w-full h-full z-10 cursor-crosshair touch-none"
      />

      {/* Layer 2: Clean Animal Outline Layer on Top (Blended with multiply so line art is always crisp) */}
      <canvas
        ref={outlineCanvasRef}
        width={width}
        height={height}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerUp}
        className="absolute inset-0 w-full h-full z-20 cursor-crosshair touch-none mix-blend-multiply"
      />
    </div>
  );
};
