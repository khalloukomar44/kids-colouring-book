import React, { useState, useRef, useCallback } from 'react';
import { ANIMAL_PAGES } from './data/animals';
import { AnimalPage, ToolMode, BrushSize, StickerType } from './types/colouring';
import { HomePage } from './components/HomePage';
import { ColouringCanvas } from './components/ColouringCanvas';
import { NavigationHeader } from './components/NavigationHeader';
import { ColorPalette } from './components/ColorPalette';
import { ToolBar } from './components/ToolBar';
import { SaveModal } from './components/SaveModal';
import { ClearConfirmModal } from './components/ClearConfirmModal';
import { MyGalleryModal } from './components/MyGalleryModal';
import { sounds } from './utils/soundEffects';

export function App() {
  // App View State ('home' or 'canvas')
  const [currentView, setCurrentView] = useState<'home' | 'canvas'>('home');

  // Currently Selected Animal Page
  const [currentAnimalIndex, setCurrentAnimalIndex] = useState(0);

  // Drawing Tools State
  const [currentColor, setCurrentColor] = useState('#EF4444');
  const [toolMode, setToolMode] = useState<ToolMode>('brush');
  const [brushSize, setBrushSize] = useState<BrushSize>('medium');
  const [activeSticker, setActiveSticker] = useState<StickerType>('star');

  // History & Undo/Redo State
  const [canUndo, setCanUndo] = useState(false);
  const [canRedo, setCanRedo] = useState(false);
  const [undoTrigger, setUndoTrigger] = useState(0);
  const [redoTrigger, setRedoTrigger] = useState(0);
  const [clearTrigger, setClearTrigger] = useState(0);

  // Modals
  const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);
  const [isClearModalOpen, setIsClearModalOpen] = useState(false);
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);
  const [savedImageDataUrl, setSavedImageDataUrl] = useState('');

  // Canvas Data Exporter Callback
  const getCanvasDataUrlRef = useRef<(() => string) | null>(null);

  const currentAnimal: AnimalPage = ANIMAL_PAGES[currentAnimalIndex] || ANIMAL_PAGES[0];

  // Open specific animal
  const handleSelectAnimal = (animal: AnimalPage) => {
    const idx = ANIMAL_PAGES.findIndex((a) => a.id === animal.id);
    if (idx !== -1) {
      setCurrentAnimalIndex(idx);
      if (animal.defaultColors && animal.defaultColors.length > 0) {
        setCurrentColor(animal.defaultColors[0]);
      }
    }
    setCurrentView('canvas');
  };

  // Select animal by ID (from gallery)
  const handleSelectAnimalById = (animalId: string) => {
    const idx = ANIMAL_PAGES.findIndex((a) => a.id === animalId);
    if (idx !== -1) {
      setCurrentAnimalIndex(idx);
      setCurrentView('canvas');
    }
  };

  // Next Animal Page
  const handleNextAnimal = () => {
    setCurrentAnimalIndex((prev) => (prev + 1) % ANIMAL_PAGES.length);
  };

  // Previous Animal Page
  const handlePrevAnimal = () => {
    setCurrentAnimalIndex((prev) => (prev - 1 + ANIMAL_PAGES.length) % ANIMAL_PAGES.length);
  };

  // Handle Save
  const handleOpenSave = () => {
    if (getCanvasDataUrlRef.current) {
      const dataUrl = getCanvasDataUrlRef.current();
      setSavedImageDataUrl(dataUrl);
      setIsSaveModalOpen(true);
    }
  };

  // Handle Clear Confirmation
  const handleConfirmClear = () => {
    setClearTrigger((prev) => prev + 1);
    setIsClearModalOpen(false);
  };

  // Register canvas exporter callback
  const handleCanvasRefCallback = useCallback((fn: () => string) => {
    getCanvasDataUrlRef.current = fn;
  }, []);

  return (
    <div className="min-h-screen bg-amber-50 font-sans text-slate-800 antialiased selection:bg-amber-300 select-none">
      {/* Home View */}
      {currentView === 'home' && (
        <HomePage
          onSelectAnimal={handleSelectAnimal}
          onOpenGallery={() => setIsGalleryOpen(true)}
        />
      )}

      {/* Colouring Canvas Studio View */}
      {currentView === 'canvas' && (
        <div className="min-h-screen bg-gradient-to-b from-amber-100 via-orange-50 to-pink-100 p-2 sm:p-4 flex flex-col items-center justify-between max-w-2xl mx-auto">
          {/* Navigation Header */}
          <div className="w-full mb-2 sm:mb-3">
            <NavigationHeader
              currentAnimal={currentAnimal}
              currentIndex={currentAnimalIndex}
              totalCount={ANIMAL_PAGES.length}
              onPrev={handlePrevAnimal}
              onNext={handleNextAnimal}
              onGoHome={() => {
                sounds.playPop(400);
                setCurrentView('home');
              }}
              onSaveClick={handleOpenSave}
            />
          </div>

          {/* Interactive Colouring Canvas */}
          <div className="w-full flex-1 flex items-center justify-center my-1 sm:my-2 px-1">
            <ColouringCanvas
              animal={currentAnimal}
              currentColor={currentColor}
              toolMode={toolMode}
              brushSize={brushSize}
              activeSticker={activeSticker}
              onHistoryChange={(undoable, redoable) => {
                setCanUndo(undoable);
                setCanRedo(redoable);
              }}
              undoTrigger={undoTrigger}
              redoTrigger={redoTrigger}
              clearTrigger={clearTrigger}
              canvasRefCallback={handleCanvasRefCallback}
            />
          </div>

          {/* ToolBar & Palette Section */}
          <div className="w-full flex flex-col gap-2 sm:gap-3 mt-1 sm:mt-2">
            <ToolBar
              toolMode={toolMode}
              onSelectToolMode={setToolMode}
              brushSize={brushSize}
              onSelectBrushSize={setBrushSize}
              canUndo={canUndo}
              canRedo={canRedo}
              onUndo={() => setUndoTrigger((prev) => prev + 1)}
              onRedo={() => setRedoTrigger((prev) => prev + 1)}
              onClearClick={() => setIsClearModalOpen(true)}
            />

            <ColorPalette
              currentColor={currentColor}
              onSelectColor={setCurrentColor}
              toolMode={toolMode}
              onSelectToolMode={setToolMode}
              activeSticker={activeSticker}
              onSelectSticker={setActiveSticker}
              recommendedColors={currentAnimal.defaultColors}
            />
          </div>
        </div>
      )}

      {/* Save Modal */}
      <SaveModal
        isOpen={isSaveModalOpen}
        onClose={() => setIsSaveModalOpen(false)}
        imageDataUrl={savedImageDataUrl}
        animal={currentAnimal}
      />

      {/* Clear Confirmation Modal */}
      <ClearConfirmModal
        isOpen={isClearModalOpen}
        onConfirm={handleConfirmClear}
        onCancel={() => setIsClearModalOpen(false)}
      />

      {/* In-App Saved Gallery Modal */}
      <MyGalleryModal
        isOpen={isGalleryOpen}
        onClose={() => setIsGalleryOpen(false)}
        onSelectAnimal={handleSelectAnimalById}
      />
    </div>
  );
}

export default App;
