import React from 'react';
import { COLOR_PALETTE, STICKER_LIST } from '../data/animals';
import { ToolMode, StickerType } from '../types/colouring';
import { sounds } from '../utils/soundEffects';
import { Sparkles, Paintbrush, Pipette, Stamp, Palette } from 'lucide-react';

interface ColorPaletteProps {
  currentColor: string;
  onSelectColor: (color: string) => void;
  toolMode: ToolMode;
  onSelectToolMode: (mode: ToolMode) => void;
  activeSticker: StickerType;
  onSelectSticker: (sticker: StickerType) => void;
  recommendedColors?: string[];
}

export const ColorPalette: React.FC<ColorPaletteProps> = ({
  currentColor,
  onSelectColor,
  toolMode,
  onSelectToolMode,
  activeSticker,
  onSelectSticker,
  recommendedColors,
}) => {
  return (
    <div className="w-full bg-white/95 backdrop-blur-md rounded-3xl p-3 sm:p-4 shadow-xl border-4 border-amber-200 ring-2 ring-amber-100 flex flex-col gap-3">
      {/* Magic Brushes & Special Tool Modes Bar */}
      <div className="flex items-center justify-between gap-1.5 sm:gap-2 overflow-x-auto no-scrollbar py-1">
        {/* Paint Brush (Classic) */}
        <button
          onClick={() => {
            onSelectToolMode('brush');
            sounds.playPop(520);
          }}
          className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-2xl font-bold text-sm sm:text-base btn-3d transition-all shrink-0 ${
            toolMode === 'brush'
              ? 'bg-amber-500 text-white shadow-lg ring-4 ring-amber-300 scale-105'
              : 'bg-amber-100 text-amber-900 hover:bg-amber-200'
          }`}
        >
          <Paintbrush className="w-4 h-4 sm:w-5 sm:h-5" />
          <span>Paint</span>
        </button>

        {/* Crayon / Pastel Texture */}
        <button
          onClick={() => {
            onSelectToolMode('crayon');
            sounds.playPop(480);
          }}
          className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-2xl font-bold text-sm sm:text-base btn-3d transition-all shrink-0 ${
            toolMode === 'crayon'
              ? 'bg-orange-500 text-white shadow-lg ring-4 ring-orange-300 scale-105'
              : 'bg-orange-100 text-orange-900 hover:bg-orange-200'
          }`}
        >
          <span className="text-base sm:text-lg">🖍️</span>
          <span>Crayon</span>
        </button>

        {/* Rainbow Brush */}
        <button
          onClick={() => {
            onSelectToolMode('rainbow');
            sounds.playMagic();
          }}
          className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-2xl font-bold text-sm sm:text-base btn-3d transition-all shrink-0 ${
            toolMode === 'rainbow'
              ? 'bg-gradient-to-r from-red-500 via-yellow-400 via-green-400 to-blue-500 text-white shadow-lg ring-4 ring-purple-300 scale-105'
              : 'bg-gradient-to-r from-red-200 via-yellow-200 via-green-200 to-blue-200 text-slate-800 hover:opacity-90'
          }`}
        >
          <span className="text-base sm:text-lg">🌈</span>
          <span>Rainbow</span>
        </button>

        {/* Sparkle Glitter Brush */}
        <button
          onClick={() => {
            onSelectToolMode('sparkle');
            sounds.playMagic();
          }}
          className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-2xl font-bold text-sm sm:text-base btn-3d transition-all shrink-0 ${
            toolMode === 'sparkle'
              ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg ring-4 ring-pink-300 scale-105'
              : 'bg-purple-100 text-purple-900 hover:bg-purple-200'
          }`}
        >
          <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-amber-300 animate-spin" />
          <span>Glitter</span>
        </button>

        {/* Bucket Fill (Tap-to-Color) */}
        <button
          onClick={() => {
            onSelectToolMode('fill');
            sounds.playFill();
          }}
          className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-2xl font-bold text-sm sm:text-base btn-3d transition-all shrink-0 ${
            toolMode === 'fill'
              ? 'bg-sky-500 text-white shadow-lg ring-4 ring-sky-300 scale-105'
              : 'bg-sky-100 text-sky-900 hover:bg-sky-200'
          }`}
        >
          <span className="text-base sm:text-lg">🪣</span>
          <span>Fill</span>
        </button>

        {/* Sticker Stamp Tool */}
        <button
          onClick={() => {
            onSelectToolMode('sticker');
            sounds.playSticker();
          }}
          className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-2xl font-bold text-sm sm:text-base btn-3d transition-all shrink-0 ${
            toolMode === 'sticker'
              ? 'bg-rose-500 text-white shadow-lg ring-4 ring-rose-300 scale-105'
              : 'bg-rose-100 text-rose-900 hover:bg-rose-200'
          }`}
        >
          <Stamp className="w-4 h-4 sm:w-5 sm:h-5" />
          <span>Stickers</span>
        </button>
      </div>

      {/* Stickers Sub-drawer if sticker tool active */}
      {toolMode === 'sticker' && (
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-2 px-1 bg-rose-50 rounded-2xl border-2 border-rose-200">
          <span className="text-xs font-bold text-rose-800 uppercase tracking-wider shrink-0 pl-1">
            Pick Stamp:
          </span>
          {STICKER_LIST.map((st) => (
            <button
              key={st.id}
              onClick={() => {
                onSelectSticker(st.id as StickerType);
                sounds.playPop(600);
              }}
              title={st.label}
              className={`p-2 rounded-xl text-2xl btn-3d shrink-0 transition-transform ${
                activeSticker === st.id
                  ? 'bg-white shadow-md ring-4 ring-rose-400 scale-125'
                  : 'bg-white/70 hover:bg-white'
              }`}
            >
              {st.emoji}
            </button>
          ))}
        </div>
      )}

      {/* Recommended starter colors for this animal */}
      {recommendedColors && recommendedColors.length > 0 && (
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-1">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider shrink-0 flex items-center gap-1">
            <Palette className="w-3.5 h-3.5 text-amber-500" /> Animal Match:
          </span>
          <div className="flex gap-2">
            {recommendedColors.map((hex, idx) => (
              <button
                key={`rec-${idx}`}
                onClick={() => {
                  onSelectColor(hex);
                  if (toolMode === 'eraser' || toolMode === 'sticker') {
                    onSelectToolMode('brush');
                  }
                  sounds.playPop(440 + idx * 30);
                }}
                style={{ backgroundColor: hex }}
                className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full btn-3d shrink-0 transition-all ${
                  currentColor.toLowerCase() === hex.toLowerCase() && toolMode !== 'rainbow' && toolMode !== 'sparkle'
                    ? 'ring-4 ring-offset-2 ring-amber-500 scale-115 shadow-md'
                    : 'border-2 border-white shadow-sm hover:scale-105'
                }`}
              />
            ))}
          </div>
        </div>
      )}

      {/* Main Chunky Colour Palette Grid */}
      <div className="grid grid-cols-8 sm:grid-cols-12 gap-2 sm:gap-2.5 max-h-36 overflow-y-auto p-1 bg-amber-50/70 rounded-2xl border border-amber-200/60 no-scrollbar">
        {COLOR_PALETTE.map((col) => {
          const isSelected =
            currentColor.toLowerCase() === col.hex.toLowerCase() &&
            toolMode !== 'rainbow' &&
            toolMode !== 'sparkle' &&
            toolMode !== 'eraser' &&
            toolMode !== 'sticker';

          return (
            <button
              key={col.hex}
              onClick={() => {
                onSelectColor(col.hex);
                if (toolMode === 'eraser' || toolMode === 'sticker') {
                  onSelectToolMode('brush');
                }
                sounds.playPop(500);
              }}
              title={col.label}
              aria-label={col.label}
              style={{ backgroundColor: col.hex }}
              className={`w-9 h-9 sm:w-10 sm:h-10 rounded-full btn-3d mx-auto relative transition-transform ${
                isSelected
                  ? `ring-4 ring-offset-2 ring-slate-800 scale-120 z-10 shadow-lg`
                  : 'border-2 border-white shadow hover:scale-110'
              }`}
            >
              {isSelected && (
                <span className="absolute inset-0 flex items-center justify-center text-xs font-black drop-shadow text-white">
                  ✓
                </span>
              )}
            </button>
          );
        })}

        {/* Custom Color Input for Endless Creativity */}
        <label
          className="w-9 h-9 sm:w-10 sm:h-10 rounded-full btn-3d mx-auto flex items-center justify-center bg-gradient-to-tr from-pink-400 via-amber-300 to-sky-400 border-2 border-white shadow cursor-pointer hover:scale-110 relative"
          title="Pick any custom color"
        >
          <Pipette className="w-4 h-4 text-white drop-shadow" />
          <input
            type="color"
            value={currentColor}
            onChange={(e) => {
              onSelectColor(e.target.value);
              if (toolMode === 'eraser' || toolMode === 'sticker') {
                onSelectToolMode('brush');
              }
              sounds.playPop(580);
            }}
            className="opacity-0 absolute inset-0 w-full h-full cursor-pointer"
          />
        </label>
      </div>
    </div>
  );
};
