import React, { useEffect } from 'react';
import { ChevronLeft, ChevronRight, X, Sparkles, Monitor } from 'lucide-react';
import { PrototypeProject, Screen, Action } from '../types/prototype';
import { InteractiveScreenRenderer } from './InteractiveScreenRenderer';

interface PresentationModeProps {
  project: PrototypeProject;
  activeScreen: Screen;
  onSelectScreen: (screenId: string) => void;
  onDispatchAction: (action: Action) => void;
  onExit: () => void;
}

export const PresentationMode: React.FC<PresentationModeProps> = ({
  project,
  activeScreen,
  onSelectScreen,
  onDispatchAction,
  onExit,
}) => {
  const currentIdx = project.screens.findIndex((s) => s.id === activeScreen.id);

  const handleNext = () => {
    if (currentIdx < project.screens.length - 1) {
      onSelectScreen(project.screens[currentIdx + 1].id);
    }
  };

  const handlePrev = () => {
    if (currentIdx > 0) {
      onSelectScreen(project.screens[currentIdx - 1].id);
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onExit();
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'ArrowLeft') handlePrev();
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIdx, project.screens]);

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col select-none">
      {/* Top Minimalist Presenter Bar */}
      <div className="h-14 bg-slate-950/90 border-b border-slate-800/80 px-6 flex items-center justify-between z-30 shrink-0">
        <div className="flex items-center space-x-3">
          <span className="font-extrabold text-sm text-white">{project.title}</span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400 font-mono">
            {activeScreen.name} ({currentIdx + 1}/{project.screens.length})
          </span>
        </div>

        {/* Screen Switcher */}
        <div className="flex items-center space-x-2">
          <button
            onClick={handlePrev}
            disabled={currentIdx === 0}
            className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white disabled:opacity-40"
            title="Previous Screen (Left Arrow)"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <div className="flex items-center space-x-1">
            {project.screens.map((s, idx) => (
              <button
                key={s.id}
                onClick={() => onSelectScreen(s.id)}
                className={`w-2.5 h-2.5 rounded-full transition-all ${
                  idx === currentIdx ? 'bg-indigo-500 scale-125' : 'bg-slate-700 hover:bg-slate-600'
                }`}
                title={s.name}
              />
            ))}
          </div>
          <button
            onClick={handleNext}
            disabled={currentIdx === project.screens.length - 1}
            className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white disabled:opacity-40"
            title="Next Screen (Right Arrow)"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <button
          onClick={onExit}
          className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold flex items-center space-x-1.5 transition-all"
        >
          <X className="w-3.5 h-3.5" />
          <span>Exit (Esc)</span>
        </button>
      </div>

      {/* Main Fullscreen Interactive Stage */}
      <div className="flex-1 overflow-auto relative">
        <InteractiveScreenRenderer
          screen={activeScreen}
          theme={project.theme}
          onDispatchAction={onDispatchAction}
        />
      </div>
    </div>
  );
};
