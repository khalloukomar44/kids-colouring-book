package com.kids.colouringbook.ui.theme

import androidx.compose.ui.graphics.Color

val AmberPrimary = Color(0xFFF59E0B)
val AmberDark = Color(0xFFD97706)
val AmberLight = Color(0xFFFEF3C7)
val AmberSoft = Color(0xFFFFFBEB)

val SlateText = Color(0xFF1E293B)
val SlateMuted = Color(0xFF64748B)
val SlateLight = Color(0xFFF1F5F9)

val RainbowPink = Color(0xFFEC4899)
val RainbowPurple = Color(0xFF8B5CF6)
val RainbowBlue = Color(0xFF3B82F6)
val RainbowGreen = Color(0xFF10B981)
val RainbowYellow = Color(0xFFFBBF24)
val RainbowOrange = Color(0xFFF97316)
val RainbowRed = Color(0xFFEF4444)
