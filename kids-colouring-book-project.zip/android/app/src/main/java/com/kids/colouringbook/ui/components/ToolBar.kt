package com.kids.colouringbook.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kids.colouringbook.model.BrushSize
import com.kids.colouringbook.model.ToolMode
import com.kids.colouringbook.ui.theme.SlateMuted
import com.kids.colouringbook.ui.theme.SlateText

@Composable
fun ToolBar(
    currentTool: ToolMode,
    brushSize: BrushSize,
    canUndo: Boolean,
    canRedo: Boolean,
    onToolSelect: (ToolMode) -> Unit,
    onBrushSizeSelect: (BrushSize) -> Unit,
    onUndoClick: () -> Unit,
    onRedoClick: () -> Unit,
    onClearClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Eraser button
        val isEraser = currentTool == ToolMode.ERASER
        Box(
            modifier = Modifier
                .height(44.dp)
                .shadow(if (isEraser) 4.dp else 2.dp, RoundedCornerShape(22.dp))
                .clip(RoundedCornerShape(22.dp))
                .background(if (isEraser) Color(0xFFF43F5E) else Color.White)
                .border(
                    2.dp,
                    if (isEraser) Color(0xFFFDA4AF) else Color(0xFFE2E8F0),
                    RoundedCornerShape(22.dp)
                )
                .clickable {
                    if (isEraser) onToolSelect(ToolMode.BRUSH) else onToolSelect(ToolMode.ERASER)
                }
                .padding(horizontal = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "🧹",
                    fontSize = 18.sp
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Eraser",
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp,
                    color = if (isEraser) Color.White else SlateText
                )
            }
        }

        // Brush Size Selector (Fine, Medium, Thick, Giant)
        Row(
            modifier = Modifier
                .shadow(2.dp, RoundedCornerShape(22.dp))
                .clip(RoundedCornerShape(22.dp))
                .background(Color.White)
                .border(2.dp, Color(0xFFFDE68A), RoundedCornerShape(22.dp))
                .padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BrushSize.values().forEach { size ->
                val isSelected = brushSize == size && currentTool != ToolMode.ERASER
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) Color(0xFFFEF3C7) else Color.Transparent)
                        .border(
                            if (isSelected) 2.dp else 0.dp,
                            if (isSelected) Color(0xFFF59E0B) else Color.Transparent,
                            CircleShape
                        )
                        .clickable { onBrushSizeSelect(size) },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size((size.dotRadiusDp * 2).dp)
                            .clip(CircleShape)
                            .background(if (isSelected) Color(0xFFF59E0B) else Color(0xFF94A3B8))
                    )
                }
            }
        }

        // Undo & Redo & Clean Page buttons
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Undo
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .shadow(2.dp, CircleShape)
                    .clip(CircleShape)
                    .background(if (canUndo) Color.White else Color(0xFFF1F5F9))
                    .border(
                        2.dp,
                        if (canUndo) Color(0xFFE2E8F0) else Color.Transparent,
                        CircleShape
                    )
                    .clickable(enabled = canUndo) { onUndoClick() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Undo,
                    contentDescription = "Undo",
                    tint = if (canUndo) Color(0xFF3B82F6) else Color(0xFFCBD5E1),
                    modifier = Modifier.size(22.dp)
                )
            }

            // Redo
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .shadow(2.dp, CircleShape)
                    .clip(CircleShape)
                    .background(if (canRedo) Color.White else Color(0xFFF1F5F9))
                    .border(
                        2.dp,
                        if (canRedo) Color(0xFFE2E8F0) else Color.Transparent,
                        CircleShape
                    )
                    .clickable(enabled = canRedo) { onRedoClick() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Redo,
                    contentDescription = "Redo",
                    tint = if (canRedo) Color(0xFF3B82F6) else Color(0xFFCBD5E1),
                    modifier = Modifier.size(22.dp)
                )
            }

            // Clean Page Trash button
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .shadow(2.dp, CircleShape)
                    .clip(CircleShape)
                    .background(Color.White)
                    .border(2.dp, Color(0xFFFCA5A5), CircleShape)
                    .clickable { onClearClick() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Clear Page",
                    tint = Color(0xFFEF4444),
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}
