package com.kids.colouringbook.storage

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.kids.colouringbook.model.AnimalPage
import com.kids.colouringbook.model.SavedArtwork
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object GalleryStorage {

    private const val PREFS_NAME = "kids_colouring_gallery_prefs"
    private const val KEY_GALLERY_JSON = "saved_artworks_json"

    fun saveArtwork(context: Context, animal: AnimalPage, bitmap: Bitmap): SavedArtwork {
        val timestamp = System.currentTimeMillis()
        val dateString = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(timestamp))
        val fileName = "art_${animal.id}_$timestamp.png"

        val dir = File(context.filesDir, "gallery")
        if (!dir.exists()) dir.mkdirs()

        val file = File(dir, fileName)
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }

        val newArtwork = SavedArtwork(
            id = "art_$timestamp",
            animalId = animal.id,
            animalName = animal.name,
            animalEmoji = animal.emoji,
            filePath = file.absolutePath,
            createdAt = dateString
        )

        // Save to SharedPreferences JSON
        val currentList = loadAllArtworks(context).toMutableList()
        currentList.add(0, newArtwork)
        saveArtworkList(context, currentList)

        return newArtwork
    }

    fun loadAllArtworks(context: Context): List<SavedArtwork> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_GALLERY_JSON, null) ?: return emptyList()

        val list = mutableListOf<SavedArtwork>()
        try {
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val artwork = SavedArtwork(
                    id = obj.getString("id"),
                    animalId = obj.getString("animalId"),
                    animalName = obj.getString("animalName"),
                    animalEmoji = obj.getString("animalEmoji"),
                    filePath = obj.getString("filePath"),
                    createdAt = obj.getString("createdAt")
                )
                // Only include if the image file still exists
                if (File(artwork.filePath).exists()) {
                    list.add(artwork)
                }
            }
        } catch (e: Exception) {
            // parsing error fallback
        }
        return list
    }

    fun deleteArtwork(context: Context, id: String): Boolean {
        val currentList = loadAllArtworks(context).toMutableList()
        val item = currentList.find { it.id == id }
        if (item != null) {
            try {
                File(item.filePath).delete()
            } catch (e: Exception) {}
            currentList.remove(item)
            saveArtworkList(context, currentList)
            return true
        }
        return false
    }

    fun loadArtworkBitmap(filePath: String): Bitmap? {
        val file = File(filePath)
        if (!file.exists()) return null
        return BitmapFactory.decodeFile(file.absolutePath)
    }

    fun shareArtwork(context: Context, artwork: SavedArtwork) {
        val file = File(artwork.filePath)
        if (!file.exists()) return

        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "Look at my ${artwork.animalName} drawing! 🎨")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share Drawing").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            // Sharing error fallback
        }
    }

    fun exportToPictures(context: Context, bitmap: Bitmap, animalName: String): Boolean {
        val fileName = "${animalName.replace(" ", "_")}_Colouring_${System.currentTimeMillis()}.png"

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/KidsColouringBook")
                }
                val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    }
                    true
                } else false
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "KidsColouringBook")
                if (!dir.exists()) dir.mkdirs()
                val file = File(dir, fileName)
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun saveArtworkList(context: Context, list: List<SavedArtwork>) {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("animalId", item.animalId)
                put("animalName", item.animalName)
                put("animalEmoji", item.animalEmoji)
                put("filePath", item.filePath)
                put("createdAt", item.createdAt)
            }
            array.put(obj)
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_GALLERY_JSON, array.toString())
            .apply()
    }
}
