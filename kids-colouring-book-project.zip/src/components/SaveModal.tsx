import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { AnimalPage } from '../types/colouring';
import { sounds } from '../utils/soundEffects';
import { Download, Printer, Heart, Sparkles, X, Check, Share2 } from 'lucide-react';

interface SaveModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageDataUrl: string;
  animal: AnimalPage;
  onSavedToGallery?: () => void;
}

export const SaveModal: React.FC<SaveModalProps> = ({
  isOpen,
  onClose,
  imageDataUrl,
  animal,
  onSavedToGallery,
}) => {
  const [savedToApp, setSavedToApp] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    if (isOpen) {
      // Fire celebration confetti!
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#FF6B8B', '#FFD166', '#06D6A0', '#118AB2', '#9D4EDD'],
      });
      setSavedToApp(false);
      setCopiedLink(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Download high-resolution PNG
  const handleDownload = () => {
    sounds.playSuccess();
    const link = document.createElement('a');
    link.download = `${animal.id}_colouring_masterpiece.png`;
    link.href = imageDataUrl;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Save to In-App Local Gallery
  const handleSaveToGallery = () => {
    sounds.playMagic();
    try {
      const existing = JSON.parse(localStorage.getItem('kids_colouring_gallery') || '[]');
      const newArtwork = {
        id: 'art_' + Date.now(),
        animalId: animal.id,
        animalName: animal.name,
        animalEmoji: animal.emoji,
        dataUrl: imageDataUrl,
        createdAt: new Date().toLocaleDateString(),
        thumbnailUrl: imageDataUrl,
      };
      existing.unshift(newArtwork);
      localStorage.setItem('kids_colouring_gallery', JSON.stringify(existing));
      setSavedToApp(true);
      if (onSavedToGallery) onSavedToGallery();
    } catch {
      setSavedToApp(true);
    }
  };

  // Print artwork
  const handlePrint = () => {
    sounds.playPop(480);
    const win = window.open('', '_blank');
    if (win) {
      win.document.write(`
        <html>
          <head>
            <title>${animal.name} - Colouring Book for Kids</title>
            <style>
              body { display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; margin: 0; font-family: sans-serif; background: #fff; }
              img { max-width: 90%; max-height: 80vh; border: 8px solid #F59E0B; border-radius: 20px; box-shadow: 0 10px 20px rgba(0,0,0,0.1); }
              h1 { color: #D97706; margin-bottom: 12px; }
            </style>
          </head>
          <body>
            <h1>🎨 ${animal.name} Masterpiece!</h1>
            <img src="${imageDataUrl}" />
            <script>
              window.onload = function() { window.print(); window.close(); }
            </script>
          </body>
        </html>
      `);
      win.document.close();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md bg-white rounded-3xl p-5 sm:p-6 shadow-2xl border-4 border-amber-300 ring-4 ring-amber-100 flex flex-col items-center text-center">
        {/* Close Button */}
        <button
          onClick={() => {
            sounds.playPop(300);
            onClose();
          }}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 transition-all btn-3d"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-100 text-amber-900 font-black text-sm mb-3">
          <Sparkles className="w-4 h-4 text-amber-500 animate-spin" />
          <span>AWESOME ARTIST! ⭐⭐⭐⭐⭐</span>
        </div>

        <h2 className="text-2xl sm:text-3xl font-black text-slate-800 mb-1">
          Look at Your Artwork! 🎨
        </h2>
        <p className="text-slate-500 font-bold text-sm mb-4">
          You made {animal.name} look so vibrant and happy!
        </p>

        {/* Framed Artwork Preview */}
        <div className="relative w-56 h-56 sm:w-64 sm:h-64 rounded-2xl overflow-hidden shadow-inner border-4 border-amber-400 p-2 bg-gradient-to-tr from-amber-50 to-orange-50 mb-5 flex items-center justify-center">
          <img
            src={imageDataUrl}
            alt={animal.name}
            className="w-full h-full object-contain rounded-xl"
          />
          <div className="absolute bottom-2 right-2 bg-white/90 px-2 py-0.5 rounded-lg text-xs font-black text-slate-700 shadow">
            {animal.emoji} {animal.name}
          </div>
        </div>

        {/* Big Action Buttons for Kids */}
        <div className="w-full flex flex-col gap-2.5">
          {/* Download Image Button */}
          <button
            onClick={handleDownload}
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 text-white font-black text-lg btn-3d shadow-lg hover:opacity-95 flex items-center justify-center gap-2"
          >
            <Download className="w-6 h-6 stroke-[2.5]" />
            <span>Download Picture</span>
          </button>

          <div className="grid grid-cols-2 gap-2.5">
            {/* Save to My Gallery */}
            <button
              onClick={handleSaveToGallery}
              className={`py-3 px-3 rounded-2xl font-black text-sm btn-3d flex items-center justify-center gap-1.5 transition-all ${
                savedToApp
                  ? 'bg-amber-100 text-amber-900 border-2 border-amber-400'
                  : 'bg-amber-500 text-white hover:bg-amber-600 shadow-md'
              }`}
            >
              {savedToApp ? (
                <>
                  <Check className="w-5 h-5 text-emerald-600 stroke-[3]" />
                  <span>Saved in App!</span>
                </>
              ) : (
                <>
                  <Heart className="w-5 h-5 fill-current" />
                  <span>Save to Gallery</span>
                </>
              )}
            </button>

            {/* Print Button */}
            <button
              onClick={handlePrint}
              className="py-3 px-3 rounded-2xl bg-sky-500 text-white font-black text-sm btn-3d hover:bg-sky-600 shadow-md flex items-center justify-center gap-1.5"
            >
              <Printer className="w-5 h-5 stroke-[2.5]" />
              <span>Print Page</span>
            </button>
          </div>

          {/* Continue Coloring */}
          <button
            onClick={() => {
              sounds.playPop(500);
              onClose();
            }}
            className="mt-1 py-2 text-slate-500 font-black text-sm hover:text-slate-800 transition-colors"
          >
            Keep Coloring ✏️
          </button>
        </div>
      </div>
    </div>
  );
};
