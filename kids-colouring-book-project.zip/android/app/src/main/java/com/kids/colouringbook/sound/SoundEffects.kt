package com.kids.colouringbook.sound

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.sin

object SoundEffects {

    var isEnabled: Boolean = true
    private val scope = CoroutineScope(Dispatchers.Default)

    /**
     * Synthesizes and plays a friendly pop tone for button taps and brush selection.
     */
    fun playPop(frequency: Float = 520f) {
        if (!isEnabled) return
        scope.launch {
            playTone(frequency, 0.08f, decay = true)
        }
    }

    /**
     * Playful page turning whoosh sound effect.
     */
    fun playPageTurn() {
        if (!isEnabled) return
        scope.launch {
            playToneSweep(300f, 600f, 0.12f)
        }
    }

    /**
     * Magic sparkle chime for rainbow / sparkles.
     */
    fun playMagic() {
        if (!isEnabled) return
        scope.launch {
            val notes = floatArrayOf(523.25f, 659.25f, 783.99f, 1046.50f)
            for (note in notes) {
                playTone(note, 0.08f, decay = true)
            }
        }
    }

    /**
     * Victory celebration chime when saving artwork.
     */
    fun playSuccess() {
        if (!isEnabled) return
        scope.launch {
            val chord = floatArrayOf(523.25f, 659.25f, 783.99f, 1046.50f)
            for (f in chord) {
                playTone(f, 0.15f, decay = true)
            }
        }
    }

    /**
     * Eraser scrub sound.
     */
    fun playEraser() {
        if (!isEnabled) return
        scope.launch {
            playToneSweep(450f, 250f, 0.09f)
        }
    }

    /**
     * Clear / Trash sound.
     */
    fun playClear() {
        if (!isEnabled) return
        scope.launch {
            playToneSweep(600f, 200f, 0.15f)
        }
    }

    private fun playTone(freq: Float, durationSec: Float, decay: Boolean = false) {
        val sampleRate = 22050
        val numSamples = (durationSec * sampleRate).toInt()
        val buffer = ShortArray(numSamples)

        for (i in 0 until numSamples) {
            val time = i.toDouble() / sampleRate
            val angle = 2.0 * Math.PI * freq * time
            val envelope = if (decay) (1.0 - (i.toDouble() / numSamples)) else 1.0
            buffer[i] = (sin(angle) * 32767.0 * envelope * 0.4).toInt().toShort()
        }

        playBuffer(buffer, sampleRate)
    }

    private fun playToneSweep(startFreq: Float, endFreq: Float, durationSec: Float) {
        val sampleRate = 22050
        val numSamples = (durationSec * sampleRate).toInt()
        val buffer = ShortArray(numSamples)

        for (i in 0 until numSamples) {
            val progress = i.toDouble() / numSamples
            val currentFreq = startFreq + (endFreq - startFreq) * progress
            val time = i.toDouble() / sampleRate
            val angle = 2.0 * Math.PI * currentFreq * time
            val envelope = 1.0 - progress
            buffer[i] = (sin(angle) * 32767.0 * envelope * 0.35).toInt().toShort()
        }

        playBuffer(buffer, sampleRate)
    }

    private fun playBuffer(buffer: ShortArray, sampleRate: Int) {
        try {
            val audioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            audioTrack.write(buffer, 0, buffer.size)
            audioTrack.play()
        } catch (e: Exception) {
            // AudioTrack error handling
        }
    }
}
