import React, { useState } from 'react';
import { Code2, Copy, Check, Download, FileJson, FileCode, Globe } from 'lucide-react';
import { PrototypeProject, Screen } from '../types/prototype';
import { generateReactCode, generateHTMLCode } from '../utils/codeExport';

interface CodeExportModalProps {
  project: PrototypeProject;
  activeScreen: Screen;
  onClose: () => void;
}

export const CodeExportModal: React.FC<CodeExportModalProps> = ({
  project,
  activeScreen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'react' | 'html' | 'json'>('react');
  const [copied, setCopied] = useState(false);

  const reactCode = generateReactCode(project, activeScreen);
  const htmlCode = generateHTMLCode(project, activeScreen);
  const jsonCode = JSON.stringify(project, null, 2);

  const currentCode = activeTab === 'react' ? reactCode : activeTab === 'html' ? htmlCode : jsonCode;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const filename =
      activeTab === 'react'
        ? `${activeScreen.name.replace(/\s+/g, '')}.tsx`
        : activeTab === 'html'
        ? `${activeScreen.name.replace(/\s+/g, '')}.html`
        : `${project.title.replace(/\s+/g, '_').toLowerCase()}.json`;

    const blob = new Blob([currentCode], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 select-none animate-in fade-in zoom-in-95 duration-150">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-4xl w-full h-[85vh] shadow-2xl flex flex-col text-white space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
              <Code2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold">Export Prototype Code</h3>
              <p className="text-xs text-slate-400">Production-ready React + Tailwind TSX or Standalone HTML</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white"
          >
            ✕
          </button>
        </div>

        {/* Tab Controls & Copy / Download Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 space-x-1">
            <button
              onClick={() => setActiveTab('react')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
                activeTab === 'react' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>React (TSX)</span>
            </button>

            <button
              onClick={() => setActiveTab('html')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
                activeTab === 'html' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>Single HTML</span>
            </button>

            <button
              onClick={() => setActiveTab('json')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
                activeTab === 'json' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
              }`}
            >
              <FileJson className="w-3.5 h-3.5" />
              <span>JSON Blueprint</span>
            </button>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopy}
              className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center space-x-1.5 transition-all"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied to Clipboard!' : 'Copy Code'}</span>
            </button>

            <button
              onClick={handleDownload}
              className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md shadow-indigo-600/30 flex items-center space-x-1.5 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download File</span>
            </button>
          </div>
        </div>

        {/* Code Viewer */}
        <div className="flex-1 bg-slate-950 rounded-2xl border border-slate-800 p-4 overflow-auto font-mono text-xs text-slate-300 select-text">
          <pre className="whitespace-pre-wrap">{currentCode}</pre>
        </div>
      </div>
    </div>
  );
};
