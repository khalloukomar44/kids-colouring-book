import React from 'react';
import { sounds } from '../utils/soundEffects';
import { Trash2, Sparkles, X } from 'lucide-react';

interface ClearConfirmModalProps {
  isOpen: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ClearConfirmModal: React.FC<ClearConfirmModalProps> = ({
  isOpen,
  onConfirm,
  onCancel,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-fade-in">
      <div className="relative w-full max-w-sm bg-white rounded-3xl p-5 sm:p-6 shadow-2xl border-4 border-rose-300 ring-4 ring-rose-100 flex flex-col items-center text-center">
        <div className="w-16 h-16 rounded-full bg-rose-100 flex items-center justify-center text-3xl mb-3 animate-wiggle">
          🧹
        </div>

        <h3 className="text-2xl font-black text-slate-800 mb-1">
          Clean Page?
        </h3>
        <p className="text-slate-500 font-bold text-sm mb-5">
          Do you want to erase all your colors and start a fresh new drawing?
        </p>

        <div className="w-full flex flex-col gap-2.5">
          <button
            onClick={() => {
              onConfirm();
            }}
            className="w-full py-3.5 px-4 rounded-2xl bg-rose-500 text-white font-black text-base btn-3d shadow-lg hover:bg-rose-600 flex items-center justify-center gap-2"
          >
            <Trash2 className="w-5 h-5 stroke-[2.5]" />
            <span>Yes, Clean Page!</span>
          </button>

          <button
            onClick={() => {
              sounds.playPop(500);
              onCancel();
            }}
            className="w-full py-3 px-4 rounded-2xl bg-slate-100 text-slate-700 font-black text-base btn-3d hover:bg-slate-200"
          >
            No, Keep Drawing! 🎨
          </button>
        </div>
      </div>
    </div>
  );
};
