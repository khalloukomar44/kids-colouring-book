package com.kids.colouringbook.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.kids.colouringbook.data.AnimalData
import com.kids.colouringbook.ui.components.ClearConfirmDialog
import com.kids.colouringbook.ui.components.ColorPalette
import com.kids.colouringbook.ui.components.ColouringCanvasCompose
import com.kids.colouringbook.ui.components.NavigationHeader
import com.kids.colouringbook.ui.components.SaveDialog
import com.kids.colouringbook.ui.components.ToolBar
import com.kids.colouringbook.ui.viewmodel.ColouringViewModel

@Composable
fun ColouringScreen(
    viewModel: ColouringViewModel,
    onNavigateHome: () -> Unit,
    onNavigateGallery: () -> Unit
) {
    val currentIndex by viewModel.currentAnimalIndex.collectAsState()
    val currentTool by viewModel.currentTool.collectAsState()
    val selectedColorHex by viewModel.selectedColorHex.collectAsState()
    val brushSize by viewModel.brushSize.collectAsState()
    val selectedSticker by viewModel.selectedSticker.collectAsState()
    val canUndo by viewModel.canUndo.collectAsState()
    val canRedo by viewModel.canRedo.collectAsState()
    val isSaved by viewModel.isSaved.collectAsState()
    val showSaveDialog by viewModel.showSaveDialog.collectAsState()
    val showClearDialog by viewModel.showClearDialog.collectAsState()
    val soundEnabled by viewModel.soundEnabled.collectAsState()
    val savedBitmap by viewModel.savedArtworkBitmap.collectAsState()

    val currentAnimal = viewModel.currentAnimal

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFEF3C7))
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // 1. Navigation Header
            NavigationHeader(
                animal = currentAnimal,
                currentIndex = currentIndex,
                totalCount = AnimalData.ANIMAL_PAGES.size,
                soundEnabled = soundEnabled,
                isSaved = isSaved,
                onHomeClick = onNavigateHome,
                onPrevClick = { viewModel.prevAnimal() },
                onNextClick = { viewModel.nextAnimal() },
                onSoundToggle = { viewModel.toggleSound() },
                onAnimalFactClick = { viewModel.speakAnimalFact() },
                onSaveClick = { viewModel.saveArtwork() }
            )

            // 2. Interactive Canvas
            Box(modifier = Modifier.weight(1f)) {
                ColouringCanvasCompose(
                    animal = currentAnimal,
                    drawingEngine = viewModel.drawingEngine,
                    currentTool = currentTool,
                    selectedColorHex = selectedColorHex,
                    brushSize = brushSize,
                    selectedSticker = selectedSticker,
                    onDrawingChange = { viewModel.onDrawingAction() }
                )
            }

            // 3. ToolBar (Eraser, Brush size, Undo, Redo, Clean Page)
            ToolBar(
                currentTool = currentTool,
                brushSize = brushSize,
                canUndo = canUndo,
                canRedo = canRedo,
                onToolSelect = { viewModel.setTool(it) },
                onBrushSizeSelect = { viewModel.setBrushSize(it) },
                onUndoClick = { viewModel.undo() },
                onRedoClick = { viewModel.redo() },
                onClearClick = { viewModel.showClearConfirm() }
            )

            // 4. Color Palette & Stickers
            ColorPalette(
                selectedColorHex = selectedColorHex,
                currentTool = currentTool,
                selectedSticker = selectedSticker,
                defaultColors = currentAnimal.defaultColors,
                onColorSelect = { viewModel.setColor(it) },
                onToolSelect = { viewModel.setTool(it) },
                onStickerSelect = { viewModel.setSticker(it) }
            )
        }

        // Save Artwork Celebration Dialog
        if (showSaveDialog) {
            SaveDialog(
                animal = currentAnimal,
                artworkBitmap = savedBitmap,
                onDismiss = { viewModel.dismissSaveDialog() },
                onSaveToPictures = { viewModel.exportToPictures() },
                onShare = { viewModel.shareCurrentArtwork() },
                onGoToGallery = {
                    viewModel.dismissSaveDialog()
                    onNavigateGallery()
                }
            )
        }

        // Clean Page Confirmation Dialog
        if (showClearDialog) {
            ClearConfirmDialog(
                onConfirm = { viewModel.clearDrawing() },
                onDismiss = { viewModel.hideClearConfirm() }
            )
        }
    }
}
