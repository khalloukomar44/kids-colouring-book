package com.kids.colouringbook.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.kids.colouringbook.drawing.DrawingEngine
import com.kids.colouringbook.model.AnimalPage
import com.kids.colouringbook.model.BrushSize
import com.kids.colouringbook.model.StickerType
import com.kids.colouringbook.model.ToolMode

@Composable
fun ColouringCanvasCompose(
    animal: AnimalPage,
    drawingEngine: DrawingEngine,
    currentTool: ToolMode,
    selectedColorHex: Long,
    brushSize: BrushSize,
    selectedSticker: StickerType,
    onDrawingChange: () -> Unit
) {
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    var updateCounter by remember { mutableIntStateOf(0) }

    // Initialize or reload drawing when animal changes
    LaunchedEffect(animal.id, canvasSize) {
        if (canvasSize.width > 0 && canvasSize.height > 0) {
            drawingEngine.initialize(canvasSize.width, canvasSize.height, animal.svgDrawing)
            updateCounter++
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
            .aspectRatio(1f)
            .shadow(6.dp, RoundedCornerShape(24.dp))
            .clip(RoundedCornerShape(24.dp))
            .background(Color.White)
            .border(4.dp, Color(0xFFFDE68A), RoundedCornerShape(24.dp))
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .onSizeChanged { size ->
                    if (size.width > 0 && size.height > 0) {
                        canvasSize = size
                    }
                }
                .pointerInput(currentTool, selectedColorHex, brushSize, selectedSticker) {
                    detectTapGestures(
                        onTap = { offset ->
                            val colorInt = (selectedColorHex and 0xFFFFFFFFL).toInt()
                            drawingEngine.startStroke(
                                offset.x,
                                offset.y,
                                currentTool,
                                colorInt,
                                brushSize,
                                selectedSticker
                            )
                            drawingEngine.endStroke()
                            updateCounter++
                            onDrawingChange()
                        }
                    )
                }
                .pointerInput(currentTool, selectedColorHex, brushSize, selectedSticker) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            val colorInt = (selectedColorHex and 0xFFFFFFFFL).toInt()
                            drawingEngine.startStroke(
                                offset.x,
                                offset.y,
                                currentTool,
                                colorInt,
                                brushSize,
                                selectedSticker
                            )
                            updateCounter++
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            val colorInt = (selectedColorHex and 0xFFFFFFFFL).toInt()
                            drawingEngine.continueStroke(
                                change.position.x,
                                change.position.y,
                                currentTool,
                                colorInt,
                                brushSize
                            )
                            updateCounter++
                        },
                        onDragEnd = {
                            drawingEngine.endStroke()
                            updateCounter++
                            onDrawingChange()
                        },
                        onDragCancel = {
                            drawingEngine.endStroke()
                            updateCounter++
                            onDrawingChange()
                        }
                    )
                }
        ) {
            // Read updateCounter to force recomposition upon drawing strokes
            if (updateCounter >= 0) {
                // 1. Draw Coloring layer (underneath)
                drawingEngine.coloringBitmap?.let { bmp ->
                    if (!bmp.isRecycled) {
                        drawImage(
                            image = bmp.asImageBitmap(),
                            dstOffset = IntOffset.Zero,
                            dstSize = IntSize(size.width.toInt(), size.height.toInt())
                        )
                    }
                }

                // 2. Draw Outlines layer (on top)
                drawingEngine.outlineBitmap?.let { outBmp ->
                    if (!outBmp.isRecycled) {
                        drawImage(
                            image = outBmp.asImageBitmap(),
                            dstOffset = IntOffset.Zero,
                            dstSize = IntSize(size.width.toInt(), size.height.toInt())
                        )
                    }
                }
            }
        }
    }
}
