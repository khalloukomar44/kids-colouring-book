package com.kids.colouringbook

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.kids.colouringbook.ui.screens.ColouringScreen
import com.kids.colouringbook.ui.screens.GalleryScreen
import com.kids.colouringbook.ui.screens.HomeScreen
import com.kids.colouringbook.ui.viewmodel.ColouringViewModel
import com.kids.colouringbook.ui.viewmodel.GalleryViewModel

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Colouring : Screen("colouring")
    object Gallery : Screen("gallery")
}

@Composable
fun ColouringApp(
    navController: NavHostController = rememberNavController(),
    colouringViewModel: ColouringViewModel = viewModel(),
    galleryViewModel: GalleryViewModel = viewModel()
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route,
        modifier = Modifier.fillMaxSize(),
        enterTransition = { fadeIn(animationSpec = tween(250)) },
        exitTransition = { fadeOut(animationSpec = tween(250)) }
    ) {
        // Home Screen
        composable(Screen.Home.route) {
            HomeScreen(
                onSelectAnimal = { animalId ->
                    colouringViewModel.selectAnimal(animalId)
                    navController.navigate(Screen.Colouring.route)
                },
                onOpenGallery = {
                    navController.navigate(Screen.Gallery.route)
                }
            )
        }

        // Colouring Studio Screen
        composable(Screen.Colouring.route) {
            ColouringScreen(
                viewModel = colouringViewModel,
                onNavigateHome = {
                    navController.popBackStack(Screen.Home.route, inclusive = false)
                },
                onNavigateGallery = {
                    navController.navigate(Screen.Gallery.route)
                }
            )
        }

        // Gallery Screen
        composable(Screen.Gallery.route) {
            GalleryScreen(
                viewModel = galleryViewModel,
                onNavigateBack = {
                    navController.popBackStack()
                },
                onColorAnimal = { animalId ->
                    colouringViewModel.selectAnimal(animalId)
                    navController.navigate(Screen.Colouring.route) {
                        popUpTo(Screen.Home.route)
                    }
                }
            )
        }
    }
}
