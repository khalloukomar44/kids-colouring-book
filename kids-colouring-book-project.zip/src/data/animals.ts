import { AnimalPage } from '../types/colouring';

// 20 Adorable, clean vector animal line art coloring pages (500x500 standard viewport)
export const ANIMAL_PAGES: AnimalPage[] = [
  {
    id: 'lion',
    name: 'Leo the Lion',
    subtitle: 'The Cheerful Jungle King',
    emoji: '🦁',
    category: 'safari',
    badgeColor: 'bg-amber-400',
    soundName: 'Leo the Lion',
    funFact: 'Lions love to snooze in the shade for up to 20 hours a day! Roar!',
    defaultColors: ['#F59E0B', '#FDE047', '#D97706', '#F87171', '#34D399'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Jungle leaves background -->
      <path d="M 50 120 C 30 70 80 40 120 70 C 100 120 70 130 50 120 Z" fill="#ffffff" />
      <path d="M 450 120 C 470 70 420 40 380 70 C 400 120 430 130 450 120 Z" fill="#ffffff" />
      <path d="M 80 90 L 60 70 M 90 85 L 100 65" />
      <path d="M 420 90 L 440 70 M 410 85 L 400 65" />
      <!-- Fluffy Mane (outer bumpy circle) -->
      <path d="M 250 70 C 290 70 320 85 350 110 C 380 135 410 160 420 200 C 430 240 420 280 400 315 C 380 350 340 375 300 385 C 260 395 240 395 200 385 C 160 375 120 350 100 315 C 80 280 70 240 80 200 C 90 160 120 135 150 110 C 180 85 210 70 250 70 Z" fill="#ffffff" />
      <path d="M 180 95 C 190 75 220 70 250 75 C 280 70 310 75 320 95 C 350 90 380 110 390 140 C 410 170 420 210 410 240 C 415 280 390 320 370 340 C 340 370 300 380 250 380 C 200 380 160 370 130 340 C 110 320 85 280 90 240 C 80 210 90 170 110 140 C 120 110 150 90 180 95 Z" fill="#ffffff" />
      <!-- Body -->
      <path d="M 180 360 C 160 390 150 430 150 470 L 350 470 C 350 430 340 390 320 360" fill="#ffffff" />
      <!-- Paws -->
      <path d="M 150 470 C 150 440 210 440 210 470 Z" fill="#ffffff" />
      <path d="M 290 470 C 290 440 350 440 350 470 Z" fill="#ffffff" />
      <path d="M 170 455 L 170 470 M 190 455 L 190 470" />
      <path d="M 310 455 L 310 470 M 330 455 L 330 470" />
      <!-- Tail -->
      <path d="M 340 430 C 400 440 440 400 430 350 C 425 330 440 310 450 330 C 460 350 445 390 410 430 C 380 460 340 450 335 440" fill="#ffffff" />
      <circle cx="440" cy="320" r="16" fill="#ffffff" />
      <!-- Head Circle -->
      <circle cx="250" cy="230" r="95" fill="#ffffff" />
      <!-- Ears -->
      <path d="M 175 160 C 160 130 190 110 210 135" fill="#ffffff" />
      <path d="M 182 153 C 172 135 192 122 205 138" fill="#ffffff" />
      <path d="M 325 160 C 340 130 310 110 290 135" fill="#ffffff" />
      <path d="M 318 153 C 328 135 308 122 295 138" fill="#ffffff" />
      <!-- Eyes with cute sparkles -->
      <ellipse cx="205" cy="215" rx="14" ry="18" fill="#1E293B" />
      <circle cx="200" cy="210" r="6" fill="#ffffff" stroke="none" />
      <circle cx="212" cy="222" r="3" fill="#ffffff" stroke="none" />
      <ellipse cx="295" cy="215" rx="14" ry="18" fill="#1E293B" />
      <circle cx="290" cy="210" r="6" fill="#ffffff" stroke="none" />
      <circle cx="302" cy="222" r="3" fill="#ffffff" stroke="none" />
      <!-- Cheeks -->
      <ellipse cx="175" cy="245" rx="12" ry="7" fill="#ffffff" opacity="0.6" />
      <ellipse cx="325" cy="245" rx="12" ry="7" fill="#ffffff" opacity="0.6" />
      <!-- Cute Heart/Triangle Nose -->
      <path d="M 230 235 C 230 235 250 225 270 235 C 265 255 250 265 250 265 C 250 265 235 255 230 235 Z" fill="#1E293B" />
      <!-- Happy Mouth -->
      <path d="M 250 265 L 250 280 M 250 280 C 235 295 215 285 210 275 M 250 280 C 265 295 285 285 290 275" />
      <!-- Whiskers -->
      <path d="M 160 255 L 120 250 M 160 268 L 125 275" />
      <path d="M 340 255 L 380 250 M 340 268 L 375 275" />
      <!-- Little Crown -->
      <path d="M 220 138 L 230 100 L 250 120 L 270 100 L 280 138 Z" fill="#ffffff" />
      <circle cx="230" cy="98" r="4" fill="#ffffff" />
      <circle cx="250" cy="118" r="4" fill="#ffffff" />
      <circle cx="270" cy="98" r="4" fill="#ffffff" />
    </svg>`
  },
  {
    id: 'elephant',
    name: 'Ellie the Elephant',
    subtitle: 'Gentle Giant with a Happy Trunk',
    emoji: '🐘',
    category: 'safari',
    badgeColor: 'bg-sky-400',
    soundName: 'Ellie the Elephant',
    funFact: 'Elephants can say hello by blowing gentle trumpets with their trunks!',
    defaultColors: ['#93C5FD', '#60A5FA', '#F472B6', '#38BDF8', '#FDE047'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Water Droplets from trunk -->
      <path d="M 120 100 C 110 80 130 60 140 80 C 145 90 135 105 120 100 Z" fill="#ffffff" />
      <path d="M 160 80 C 150 65 170 50 180 65 C 185 75 175 85 160 80 Z" fill="#ffffff" />
      <path d="M 90 120 C 80 105 100 90 110 105 C 115 115 105 125 90 120 Z" fill="#ffffff" />
      <!-- Left Big Ear -->
      <path d="M 180 180 C 110 130 50 180 70 270 C 85 340 170 330 190 290" fill="#ffffff" />
      <path d="M 165 200 C 120 160 80 200 95 265 C 105 310 160 300 175 270" fill="#ffffff" />
      <!-- Right Big Ear -->
      <path d="M 320 180 C 390 130 450 180 430 270 C 415 340 330 330 310 290" fill="#ffffff" />
      <path d="M 335 200 C 380 160 420 200 405 265 C 395 310 340 300 325 270" fill="#ffffff" />
      <!-- Body -->
      <path d="M 170 300 C 130 340 140 460 140 470 L 360 470 C 360 460 370 340 330 300" fill="#ffffff" />
      <!-- Legs & Toenails -->
      <path d="M 140 470 L 190 470 L 190 400 M 310 400 L 310 470 L 360 470" />
      <circle cx="155" cy="460" r="5" fill="#ffffff" />
      <circle cx="175" cy="460" r="5" fill="#ffffff" />
      <circle cx="325" cy="460" r="5" fill="#ffffff" />
      <circle cx="345" cy="460" r="5" fill="#ffffff" />
      <!-- Head -->
      <circle cx="250" cy="220" r="85" fill="#ffffff" />
      <!-- Eyes -->
      <ellipse cx="210" cy="205" rx="12" ry="16" fill="#1E293B" />
      <circle cx="205" cy="200" r="5" fill="#ffffff" stroke="none" />
      <ellipse cx="290" cy="205" rx="12" ry="16" fill="#1E293B" />
      <circle cx="285" cy="200" r="5" fill="#ffffff" stroke="none" />
      <!-- Cheeks -->
      <ellipse cx="185" cy="235" rx="12" ry="7" fill="#ffffff" />
      <ellipse cx="315" cy="235" rx="12" ry="7" fill="#ffffff" />
      <!-- Happy Trunk curvin up with water -->
      <path d="M 230 245 C 230 310 200 340 170 330 C 140 320 130 250 145 200 C 150 170 120 140 140 130 C 160 120 175 160 165 210 C 155 245 165 295 190 295 C 215 295 255 290 270 245 Z" fill="#ffffff" />
      <!-- Trunk fold lines -->
      <path d="M 215 270 L 245 270 M 195 290 L 225 290" />
    </svg>`
  },
  {
    id: 'puppy',
    name: 'Buddy the Puppy',
    subtitle: 'Always Ready to Play Fetch',
    emoji: '🐶',
    category: 'pets',
    badgeColor: 'bg-amber-500',
    soundName: 'Buddy the Puppy',
    funFact: 'Puppies have super cute cold wet noses that help them smell yummy treats!',
    defaultColors: ['#FBBF24', '#B45309', '#F87171', '#6EE7B7', '#60A5FA'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Floppy Left Ear -->
      <path d="M 170 150 C 110 130 80 200 100 270 C 115 310 155 300 170 240 Z" fill="#ffffff" />
      <path d="M 125 200 C 105 230 115 270 135 270 C 145 270 155 240 155 210" fill="#ffffff" />
      <!-- Floppy Right Ear -->
      <path d="M 330 150 C 390 130 420 200 400 270 C 385 310 345 300 330 240 Z" fill="#ffffff" />
      <path d="M 375 200 C 395 230 385 270 365 270 C 355 270 345 240 345 210" fill="#ffffff" />
      <!-- Head -->
      <ellipse cx="250" cy="205" rx="90" ry="80" fill="#ffffff" />
      <!-- Cute eye patch -->
      <path d="M 275 160 C 325 160 335 220 315 240 C 285 250 265 220 275 160 Z" fill="#ffffff" />
      <!-- Eyes -->
      <ellipse cx="205" cy="195" rx="14" ry="17" fill="#1E293B" />
      <circle cx="200" cy="190" r="6" fill="#ffffff" stroke="none" />
      <circle cx="212" cy="202" r="3" fill="#ffffff" stroke="none" />
      <ellipse cx="295" cy="195" rx="14" ry="17" fill="#1E293B" />
      <circle cx="290" cy="190" r="6" fill="#ffffff" stroke="none" />
      <circle cx="302" cy="202" r="3" fill="#ffffff" stroke="none" />
      <!-- Snout -->
      <ellipse cx="250" cy="245" rx="42" ry="32" fill="#ffffff" />
      <path d="M 235 230 C 235 220 265 220 265 230 C 265 245 250 252 250 252 C 250 252 235 245 235 230 Z" fill="#1E293B" />
      <!-- Cute smiling tongue -->
      <path d="M 250 252 L 250 265 M 250 265 C 240 272 230 265 225 258 M 250 265 C 260 272 270 265 275 258" />
      <path d="M 240 267 C 240 290 260 290 260 267 Z" fill="#ffffff" />
      <path d="M 250 268 L 250 282" />
      <!-- Body -->
      <path d="M 175 275 C 150 320 140 430 140 470 L 360 470 C 360 430 350 320 325 275" fill="#ffffff" />
      <!-- Collar with Bell/Tag -->
      <path d="M 170 280 C 210 305 290 305 330 280 L 335 295 C 290 320 210 320 165 295 Z" fill="#ffffff" />
      <circle cx="250" cy="325" r="16" fill="#ffffff" />
      <path d="M 245 320 L 255 330 M 255 320 L 245 330" stroke-width="4" />
      <!-- Paws -->
      <path d="M 170 470 C 170 425 225 425 225 470 Z" fill="#ffffff" />
      <path d="M 275 470 C 275 425 330 425 330 470 Z" fill="#ffffff" />
      <!-- Wagging Tail -->
      <path d="M 345 380 C 420 340 440 270 420 250 C 400 245 390 280 340 330" fill="#ffffff" />
      <!-- Bone in corner -->
      <path d="M 60 420 C 45 405 60 390 75 405 C 90 390 105 405 90 420 L 90 440 C 105 455 90 470 75 455 C 60 470 45 455 60 440 Z" fill="#ffffff" />
    </svg>`
  },
  {
    id: 'kitten',
    name: 'Mittens the Kitten',
    subtitle: 'Purring with a Ball of Yarn',
    emoji: '🐱',
    category: 'pets',
    badgeColor: 'bg-rose-400',
    soundName: 'Mittens the Kitten',
    funFact: 'Cats can jump up to six times their height! Meow meow!',
    defaultColors: ['#F472B6', '#FB7185', '#FDE047', '#A78BFA', '#34D399'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Triangle Ears -->
      <path d="M 160 170 L 140 80 L 220 130 Z" fill="#ffffff" />
      <path d="M 165 155 L 155 105 L 205 135 Z" fill="#ffffff" />
      <path d="M 340 170 L 360 80 L 280 130 Z" fill="#ffffff" />
      <path d="M 335 155 L 345 105 L 295 135 Z" fill="#ffffff" />
      <!-- Round Head -->
      <circle cx="250" cy="210" r="90" fill="#ffffff" />
      <!-- Cute Eyes -->
      <ellipse cx="205" cy="200" rx="14" ry="18" fill="#1E293B" />
      <circle cx="200" cy="195" r="6" fill="#ffffff" stroke="none" />
      <circle cx="212" cy="207" r="3" fill="#ffffff" stroke="none" />
      <ellipse cx="295" cy="200" rx="14" ry="18" fill="#1E293B" />
      <circle cx="290" cy="195" r="6" fill="#ffffff" stroke="none" />
      <circle cx="302" cy="207" r="3" fill="#ffffff" stroke="none" />
      <!-- Heart Nose -->
      <path d="M 242 230 C 242 225 258 225 258 230 C 258 240 250 245 250 245 C 250 245 242 240 242 230 Z" fill="#1E293B" />
      <!-- W Mouth -->
      <path d="M 250 245 L 250 255 M 250 255 C 240 265 228 258 220 250 M 250 255 C 260 265 272 258 280 250" />
      <!-- Long Whiskers -->
      <path d="M 175 235 L 95 220 M 170 248 L 90 250 M 175 260 L 100 280" />
      <path d="M 325 235 L 405 220 M 330 248 L 410 250 M 325 260 L 400 280" />
      <!-- Body -->
      <path d="M 180 290 C 150 330 145 420 145 470 L 355 470 C 355 420 350 330 320 290" fill="#ffffff" />
      <!-- Big Bow on Collar -->
      <path d="M 220 300 C 190 280 190 330 220 315 L 250 310 L 280 315 C 310 330 310 280 280 300 Z" fill="#ffffff" />
      <circle cx="250" cy="308" r="9" fill="#ffffff" />
      <!-- Paws -->
      <path d="M 175 470 C 175 435 225 435 225 470 Z" fill="#ffffff" />
      <path d="M 275 470 C 275 435 325 435 325 470 Z" fill="#ffffff" />
      <!-- Swirly Cat Tail -->
      <path d="M 345 400 C 430 420 460 320 420 270 C 390 240 370 270 395 295 C 415 315 390 385 330 370" fill="#ffffff" />
      <!-- Ball of yarn in foreground -->
      <circle cx="80" cy="420" r="35" fill="#ffffff" />
      <path d="M 60 400 C 80 430 100 405 110 430 M 50 425 C 80 410 95 445 105 410" />
      <path d="M 115 425 C 140 435 150 460 165 465" />
    </svg>`
  },
  {
    id: 'teddy',
    name: 'Barnaby the Bear',
    subtitle: 'Warm Hugs and Honey Pots',
    emoji: '🧸',
    category: 'forest',
    badgeColor: 'bg-amber-600',
    soundName: 'Barnaby the Bear',
    funFact: 'Bears love sweet wild berries and dipping their paws in golden honey!',
    defaultColors: ['#B45309', '#D97706', '#FDE047', '#F43F5E', '#60A5FA'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Round Ears -->
      <circle cx="160" cy="140" r="38" fill="#ffffff" />
      <circle cx="160" cy="140" r="22" fill="#ffffff" />
      <circle cx="340" cy="140" r="38" fill="#ffffff" />
      <circle cx="340" cy="140" r="22" fill="#ffffff" />
      <!-- Head -->
      <circle cx="250" cy="205" r="95" fill="#ffffff" />
      <!-- Big Snout Area -->
      <ellipse cx="250" cy="235" rx="46" ry="36" fill="#ffffff" />
      <!-- Eyes with sparkle -->
      <ellipse cx="205" cy="190" rx="13" ry="16" fill="#1E293B" />
      <circle cx="200" cy="185" r="5" fill="#ffffff" stroke="none" />
      <ellipse cx="295" cy="190" rx="13" ry="16" fill="#1E293B" />
      <circle cx="290" cy="185" r="5" fill="#ffffff" stroke="none" />
      <!-- Nose & Mouth -->
      <ellipse cx="250" cy="225" rx="20" ry="14" fill="#1E293B" />
      <circle cx="245" cy="221" r="4" fill="#ffffff" stroke="none" />
      <path d="M 250 239 L 250 252 M 250 252 C 235 264 220 255 215 248 M 250 252 C 265 264 280 255 285 248" />
      <!-- Plump Bear Body -->
      <path d="M 175 285 C 130 330 120 430 120 470 L 380 470 C 380 430 370 330 325 285" fill="#ffffff" />
      <!-- Belly Patch with Heart -->
      <ellipse cx="250" cy="385" rx="60" ry="55" fill="#ffffff" />
      <path d="M 250 365 C 240 345 220 345 220 365 C 220 385 250 405 250 405 C 250 405 280 385 280 365 C 280 345 260 345 250 365 Z" fill="#ffffff" />
      <!-- Paws -->
      <path d="M 130 470 C 130 420 190 420 190 470 Z" fill="#ffffff" />
      <path d="M 310 470 C 310 420 370 420 370 470 Z" fill="#ffffff" />
      <!-- Honey Pot in corner -->
      <ellipse cx="80" cy="380" rx="30" ry="10" fill="#ffffff" />
      <path d="M 55 385 C 50 420 60 460 80 460 C 100 460 110 420 105 385" fill="#ffffff" />
      <path d="M 70 385 C 70 405 90 405 90 385" />
      <!-- Little buzzing bee -->
      <ellipse cx="420" cy="120" rx="14" ry="10" fill="#ffffff" />
      <path d="M 415 110 C 415 95 425 95 425 110 M 422 110 C 428 98 438 102 432 112" />
      <path d="M 412 115 L 412 125 M 418 115 L 418 125 M 424 115 L 424 125" />
    </svg>`
  },
  {
    id: 'giraffe',
    name: 'Gigi the Giraffe',
    subtitle: 'Tall and Gentle with Cute Spots',
    emoji: '🦒',
    category: 'safari',
    badgeColor: 'bg-yellow-400',
    soundName: 'Gigi the Giraffe',
    funFact: 'Giraffes have beautiful purple-blue tongues that can be 50 cm long!',
    defaultColors: ['#FBBF24', '#D97706', '#F59E0B', '#34D399', '#38BDF8'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Little horns (Ossicones) -->
      <path d="M 215 95 L 210 50" />
      <circle cx="210" cy="45" r="10" fill="#ffffff" />
      <path d="M 285 95 L 290 50" />
      <circle cx="290" cy="45" r="10" fill="#ffffff" />
      <!-- Leafy Ears -->
      <path d="M 180 120 C 130 90 120 130 160 140 Z" fill="#ffffff" />
      <path d="M 320 120 C 370 90 380 130 340 140 Z" fill="#ffffff" />
      <!-- Cute Head -->
      <ellipse cx="250" cy="130" rx="65" ry="55" fill="#ffffff" />
      <!-- Snout -->
      <ellipse cx="250" cy="165" rx="42" ry="30" fill="#ffffff" />
      <ellipse cx="235" cy="155" rx="5" ry="7" fill="#1E293B" />
      <ellipse cx="265" cy="155" rx="5" ry="7" fill="#1E293B" />
      <path d="M 235 175 C 245 185 255 185 265 175" />
      <!-- Eyes -->
      <ellipse cx="215" cy="115" rx="12" ry="16" fill="#1E293B" />
      <circle cx="210" cy="110" r="5" fill="#ffffff" stroke="none" />
      <ellipse cx="285" cy="115" rx="12" ry="16" fill="#1E293B" />
      <circle cx="280" cy="110" r="5" fill="#ffffff" stroke="none" />
      <!-- Long Neck -->
      <path d="M 205 180 L 175 420 L 325 420 L 295 180" fill="#ffffff" />
      <!-- Mane on Neck -->
      <path d="M 295 180 C 310 200 310 240 298 260 C 312 280 312 320 300 340 C 314 360 314 400 302 420" />
      <!-- Spots on Neck -->
      <path d="M 215 220 C 230 205 255 215 250 235 C 240 250 220 245 215 220 Z" fill="#ffffff" />
      <path d="M 255 270 C 275 255 295 270 285 290 C 270 305 250 295 255 270 Z" fill="#ffffff" />
      <path d="M 205 330 C 225 315 250 325 245 350 C 235 365 210 360 205 330 Z" fill="#ffffff" />
      <path d="M 250 380 C 270 365 295 375 290 400 C 280 415 255 410 250 380 Z" fill="#ffffff" />
      <!-- Body Base -->
      <path d="M 175 420 C 130 440 100 470 100 470 L 400 470 C 400 470 370 440 325 420" fill="#ffffff" />
      <!-- Acacia Tree in background -->
      <path d="M 60 300 C 30 260 70 220 110 250 C 140 220 170 260 140 290 Z" fill="#ffffff" />
      <path d="M 95 290 L 80 440 M 110 285 L 90 440" />
    </svg>`
  },
  {
    id: 'panda',
    name: 'Pip the Panda',
    subtitle: 'Roly-Poly Bamboo Muncher',
    emoji: '🐼',
    category: 'safari',
    badgeColor: 'bg-emerald-400',
    soundName: 'Pip the Panda',
    funFact: 'Pandas spend half of their entire day eating crispy green bamboo!',
    defaultColors: ['#10B981', '#34D399', '#F472B6', '#38BDF8', '#FDE047'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Black Panda Ears -->
      <circle cx="160" cy="130" r="38" fill="#ffffff" />
      <circle cx="340" cy="130" r="38" fill="#ffffff" />
      <!-- Head -->
      <circle cx="250" cy="205" r="95" fill="#ffffff" />
      <!-- Iconic Panda Eye Patches -->
      <ellipse cx="200" cy="195" rx="25" ry="32" transform="rotate(-15 200 195)" fill="#ffffff" />
      <ellipse cx="300" cy="195" rx="25" ry="32" transform="rotate(15 300 195)" fill="#ffffff" />
      <!-- Eyes inside patches -->
      <ellipse cx="205" cy="195" rx="10" ry="12" fill="#1E293B" />
      <circle cx="202" cy="190" r="4" fill="#ffffff" stroke="none" />
      <ellipse cx="295" cy="195" rx="10" ry="12" fill="#1E293B" />
      <circle cx="292" cy="190" r="4" fill="#ffffff" stroke="none" />
      <!-- Nose & Mouth -->
      <ellipse cx="250" cy="235" rx="16" ry="12" fill="#1E293B" />
      <path d="M 250 247 L 250 258 M 250 258 C 235 268 222 260 215 252 M 250 258 C 265 268 278 260 285 252" />
      <!-- Plump Body -->
      <path d="M 175 285 C 130 330 120 430 120 470 L 380 470 C 380 430 370 330 325 285" fill="#ffffff" />
      <!-- White Tummy -->
      <ellipse cx="250" cy="385" rx="65" ry="60" fill="#ffffff" />
      <!-- Paws -->
      <path d="M 130 470 C 130 420 190 420 190 470 Z" fill="#ffffff" />
      <path d="M 310 470 C 310 420 370 420 370 470 Z" fill="#ffffff" />
      <!-- Holding Green Bamboo Stalk -->
      <path d="M 190 320 L 190 440 M 175 350 L 205 350 M 175 390 L 205 390 M 175 430 L 205 430" stroke-width="8" />
      <!-- Bamboo Leaves -->
      <path d="M 190 340 C 220 320 230 340 195 350 Z" fill="#ffffff" />
      <path d="M 175 380 C 140 370 145 395 180 395 Z" fill="#ffffff" />
      <path d="M 190 410 C 225 400 230 425 195 425 Z" fill="#ffffff" />
    </svg>`
  },
  {
    id: 'monkey',
    name: 'Milo the Monkey',
    subtitle: 'Playful Banana Lover',
    emoji: '🐵',
    category: 'safari',
    badgeColor: 'bg-orange-400',
    soundName: 'Milo the Monkey',
    funFact: 'Monkeys use their curly tails like an extra helping hand to swing in trees!',
    defaultColors: ['#D97706', '#FBBF24', '#FDE047', '#34D399', '#F43F5E'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Big Round Ears -->
      <circle cx="145" cy="190" r="42" fill="#ffffff" />
      <circle cx="145" cy="190" r="26" fill="#ffffff" />
      <circle cx="355" cy="190" r="42" fill="#ffffff" />
      <circle cx="355" cy="190" r="26" fill="#ffffff" />
      <!-- Head -->
      <circle cx="250" cy="195" r="90" fill="#ffffff" />
      <!-- Heart-Shaped Face Mask -->
      <path d="M 250 170 C 230 130 175 130 175 180 C 175 220 205 260 250 270 C 295 260 325 220 325 180 C 325 130 270 130 250 170 Z" fill="#ffffff" />
      <!-- Eyes -->
      <ellipse cx="215" cy="180" rx="12" ry="16" fill="#1E293B" />
      <circle cx="210" cy="175" r="5" fill="#ffffff" stroke="none" />
      <ellipse cx="285" cy="180" rx="12" ry="16" fill="#1E293B" />
      <circle cx="280" cy="175" r="5" fill="#ffffff" stroke="none" />
      <!-- Nostrils & Big Smiling Mouth -->
      <circle cx="240" cy="215" r="4" fill="#1E293B" />
      <circle cx="260" cy="215" r="4" fill="#1E293B" />
      <path d="M 210 230 C 230 260 270 260 290 230" />
      <path d="M 230 248 C 240 260 260 260 270 248" />
      <!-- Body -->
      <path d="M 180 275 C 145 320 140 430 140 470 L 360 470 C 360 430 355 320 320 275" fill="#ffffff" />
      <!-- Belly -->
      <ellipse cx="250" cy="380" rx="55" ry="50" fill="#ffffff" />
      <!-- Paws -->
      <path d="M 145 470 C 145 425 205 425 205 470 Z" fill="#ffffff" />
      <path d="M 295 470 C 295 425 355 425 355 470 Z" fill="#ffffff" />
      <!-- Long Curly Tail -->
      <path d="M 350 380 C 440 370 480 270 420 220 C 380 180 340 220 370 260 C 390 280 420 270 410 250" stroke-width="8" />
      <!-- Banana Held in Hand -->
      <path d="M 130 320 C 110 330 90 370 120 390 C 150 410 170 360 150 330 Z" fill="#ffffff" />
      <path d="M 115 330 C 105 355 125 385 145 375" />
    </svg>`
  },
  {
    id: 'butterfly',
    name: 'Bella the Butterfly',
    subtitle: 'Dancing with Flowers in the Sun',
    emoji: '🦋',
    category: 'forest',
    badgeColor: 'bg-violet-400',
    soundName: 'Bella the Butterfly',
    funFact: 'Butterflies taste sweet flower nectar with their tiny little feet!',
    defaultColors: ['#A78BFA', '#EC4899', '#F472B6', '#FDE047', '#38BDF8'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Antennae with curly tops -->
      <path d="M 235 150 C 210 90 170 80 170 110 C 170 130 190 130 190 115" />
      <path d="M 265 150 C 290 90 330 80 330 110 C 330 130 310 130 310 115" />
      <!-- Left Upper Wing (large decorative) -->
      <path d="M 230 180 C 160 80 50 100 40 210 C 30 300 150 310 225 250 Z" fill="#ffffff" />
      <!-- Left Wing Patterns -->
      <circle cx="100" cy="180" r="22" fill="#ffffff" />
      <circle cx="150" cy="220" r="16" fill="#ffffff" />
      <path d="M 80 240 C 110 220 140 260 110 270 Z" fill="#ffffff" />
      <!-- Left Lower Wing -->
      <path d="M 225 260 C 150 300 70 370 120 440 C 170 490 230 400 235 330 Z" fill="#ffffff" />
      <circle cx="150" cy="380" r="18" fill="#ffffff" />
      <!-- Right Upper Wing -->
      <path d="M 270 180 C 340 80 450 100 460 210 C 470 300 350 310 275 250 Z" fill="#ffffff" />
      <!-- Right Wing Patterns -->
      <circle cx="400" cy="180" r="22" fill="#ffffff" />
      <circle cx="350" cy="220" r="16" fill="#ffffff" />
      <path d="M 420 240 C 390 220 360 260 390 270 Z" fill="#ffffff" />
      <!-- Right Lower Wing -->
      <path d="M 275 260 C 350 300 430 370 380 440 C 330 490 270 400 265 330 Z" fill="#ffffff" />
      <circle cx="350" cy="380" r="18" fill="#ffffff" />
      <!-- Body Center -->
      <circle cx="250" cy="170" r="24" fill="#ffffff" />
      <ellipse cx="250" cy="270" rx="20" ry="75" fill="#ffffff" />
      <!-- Body Stripes -->
      <path d="M 235 230 L 265 230 M 232 260 L 268 260 M 235 290 L 265 290 M 238 320 L 262 320" />
      <!-- Cute Eyes & Smile -->
      <circle cx="242" cy="168" r="4" fill="#1E293B" />
      <circle cx="258" cy="168" r="4" fill="#1E293B" />
      <path d="M 245 178 C 250 183 255 183 255 178" />
      <!-- Little Flowers at bottom -->
      <circle cx="60" cy="460" r="12" fill="#ffffff" />
      <circle cx="440" cy="460" r="12" fill="#ffffff" />
    </svg>`
  },
  {
    id: 'dolphin',
    name: 'Flipper the Dolphin',
    subtitle: 'Jumping Over Sparkling Waves',
    emoji: '🐬',
    category: 'ocean',
    badgeColor: 'bg-cyan-400',
    soundName: 'Flipper the Dolphin',
    funFact: 'Dolphins have special names for each other using high-pitched whistles!',
    defaultColors: ['#38BDF8', '#0284C7', '#BAE6FD', '#FDE047', '#F472B6'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Ocean Waves at bottom -->
      <path d="M 20 440 C 70 410 110 460 160 430 C 210 400 250 450 300 420 C 350 390 390 440 440 410 C 470 390 490 420 500 430 L 500 480 L 0 480 Z" fill="#ffffff" />
      <!-- Jumping Dolphin Body -->
      <path d="M 120 280 C 130 190 200 120 310 130 C 390 140 440 210 460 280 C 410 270 350 250 280 270 C 200 290 140 330 120 280 Z" fill="#ffffff" />
      <!-- Cute Snout & Beak -->
      <path d="M 120 280 C 70 295 60 320 90 330 C 120 340 145 325 155 300" fill="#ffffff" />
      <!-- Smiling mouth -->
      <path d="M 85 315 C 105 325 125 320 135 310" />
      <!-- Eye -->
      <ellipse cx="160" cy="265" rx="10" ry="14" fill="#1E293B" />
      <circle cx="157" cy="260" r="4" fill="#ffffff" stroke="none" />
      <!-- White Belly Underbelly -->
      <path d="M 90 330 C 130 350 200 330 270 300 C 350 270 410 280 460 280" />
      <!-- Dorsal Fin (Top) -->
      <path d="M 280 130 C 300 70 350 80 340 135 Z" fill="#ffffff" />
      <!-- Flippers (Side) -->
      <path d="M 210 290 C 220 360 260 380 260 340 C 260 310 240 285 210 290 Z" fill="#ffffff" />
      <!-- Tail Flukes -->
      <path d="M 460 280 C 470 270 490 240 480 220 C 460 250 440 280 460 300 C 475 320 495 340 490 360 C 470 330 450 300 460 280 Z" fill="#ffffff" />
      <!-- Playful Beach Ball in air -->
      <circle cx="360" cy="80" r="30" fill="#ffffff" />
      <path d="M 360 50 C 340 70 340 90 360 110 M 360 50 C 380 70 380 90 360 110" />
      <!-- Water splash drops -->
      <circle cx="120" cy="390" r="6" fill="#ffffff" />
      <circle cx="100" cy="370" r="8" fill="#ffffff" />
      <circle cx="430" cy="380" r="7" fill="#ffffff" />
    </svg>`
  },
  {
    id: 'owl',
    name: 'Oliver the Owl',
    subtitle: 'Wise and Cozy Under the Stars',
    emoji: '🦉',
    category: 'forest',
    badgeColor: 'bg-indigo-400',
    soundName: 'Oliver the Owl',
    funFact: 'Owls can turn their heads almost all the way around to look behind them!',
    defaultColors: ['#818CF8', '#6366F1', '#FDE047', '#FB923C', '#34D399'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Crescent Moon & Stars -->
      <path d="M 80 80 C 110 80 130 110 130 140 C 130 170 100 200 60 190 C 90 190 110 160 105 130 C 100 100 80 90 80 80 Z" fill="#ffffff" />
      <path d="M 420 80 L 425 95 L 440 95 L 428 105 L 432 120 L 420 110 L 408 120 L 412 105 L 400 95 L 415 95 Z" fill="#ffffff" />
      <path d="M 370 150 L 373 160 L 385 160 L 375 167 L 378 178 L 370 170 L 362 178 L 365 167 L 355 160 L 367 160 Z" fill="#ffffff" />
      <!-- Tree Branch -->
      <path d="M 30 420 C 120 400 260 410 470 410 L 470 440 C 300 440 180 430 30 450 Z" fill="#ffffff" />
      <path d="M 380 410 C 410 370 440 380 420 410 Z" fill="#ffffff" />
      <!-- Feather Tuft Ears -->
      <path d="M 180 130 L 150 70 L 220 100" fill="#ffffff" />
      <path d="M 320 130 L 350 70 L 280 100" fill="#ffffff" />
      <!-- Owl Body / Head Egg Shape -->
      <ellipse cx="250" cy="250" rx="105" ry="140" fill="#ffffff" />
      <!-- Big Owl Eye Circles -->
      <circle cx="195" cy="180" r="42" fill="#ffffff" />
      <circle cx="305" cy="180" r="42" fill="#ffffff" />
      <circle cx="195" cy="180" r="26" fill="#ffffff" />
      <circle cx="305" cy="180" r="26" fill="#ffffff" />
      <!-- Pupils -->
      <ellipse cx="195" cy="180" rx="15" ry="18" fill="#1E293B" />
      <circle cx="190" cy="172" r="6" fill="#ffffff" stroke="none" />
      <ellipse cx="305" cy="180" rx="15" ry="18" fill="#1E293B" />
      <circle cx="300" cy="172" r="6" fill="#ffffff" stroke="none" />
      <!-- Sharp Beak -->
      <path d="M 238 200 L 262 200 L 250 230 Z" fill="#ffffff" />
      <!-- Wings Folded -->
      <path d="M 150 240 C 130 300 150 370 180 380 C 170 330 160 280 170 230" fill="#ffffff" />
      <path d="M 350 240 C 370 300 350 370 320 380 C 330 330 340 280 330 230" fill="#ffffff" />
      <!-- Belly Feathers Patterns -->
      <ellipse cx="250" cy="310" rx="55" ry="60" fill="#ffffff" />
      <path d="M 220 280 C 235 295 245 280 245 280 M 255 280 C 265 295 275 280 275 280" />
      <path d="M 210 310 C 225 325 235 310 235 310 M 245 310 C 255 325 265 310 265 310 M 275 310 C 285 325 295 310 295 310" />
      <!-- Talons Clasping Branch -->
      <path d="M 200 390 C 200 420 220 420 220 390 M 210 390 C 210 425 230 425 230 390" />
      <path d="M 270 390 C 270 420 290 420 290 390 M 280 390 C 280 425 300 425 300 390" />
    </svg>`
  },
  {
    id: 'dino',
    name: 'Dino the T-Rex',
    subtitle: 'Friendly Baby Dinosaur with Tiny Arms',
    emoji: '🦖',
    category: 'magical',
    badgeColor: 'bg-lime-500',
    soundName: 'Dino the Dinosaur',
    funFact: 'Some dinosaurs had feathers just like cheerful little songbirds!',
    defaultColors: ['#84CC16', '#22C55E', '#FDE047', '#FB923C', '#38BDF8'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Friendly Dinosaur Head & Snout -->
      <path d="M 160 210 C 150 130 240 100 310 120 C 370 140 370 210 340 230 C 310 245 280 240 260 230 L 220 250 C 200 250 170 240 160 210 Z" fill="#ffffff" />
      <!-- Spikes on Head and Back -->
      <path d="M 220 105 L 235 80 L 250 105 M 265 110 L 280 85 L 295 115 M 190 240 L 165 255 L 180 275 M 165 295 L 140 310 L 155 330 M 145 350 L 120 365 L 135 385" />
      <!-- Big Happy Eye -->
      <ellipse cx="285" cy="155" rx="16" ry="20" fill="#1E293B" />
      <circle cx="278" cy="148" r="7" fill="#ffffff" stroke="none" />
      <circle cx="292" cy="162" r="3" fill="#ffffff" stroke="none" />
      <!-- Cute Tooth sticking up -->
      <path d="M 310 235 L 320 220 L 330 235" fill="#ffffff" />
      <!-- Happy Smile Line -->
      <path d="M 350 210 C 330 240 290 240 260 230" />
      <!-- Dinosaur Body -->
      <path d="M 180 250 C 150 300 140 390 150 450 L 300 450 C 310 400 320 340 300 250" fill="#ffffff" />
      <!-- Striped Belly -->
      <path d="M 260 240 C 290 280 290 380 280 450" />
      <path d="M 265 280 L 285 290 M 260 320 L 285 330 M 255 360 L 282 370 M 250 400 L 280 410" />
      <!-- Cute Tiny Dino Arms -->
      <path d="M 290 280 C 330 280 340 305 325 315 C 310 325 285 305 280 295" fill="#ffffff" />
      <!-- Big Tail -->
      <path d="M 150 410 C 90 400 40 370 20 330 C 50 360 100 430 150 450 Z" fill="#ffffff" />
      <!-- Big Feet -->
      <path d="M 170 450 C 170 430 230 430 240 450 L 245 470 C 230 475 160 475 150 470 Z" fill="#ffffff" />
      <path d="M 175 465 L 175 473 M 195 465 L 195 473 M 215 465 L 215 473" />
      <path d="M 270 450 C 270 430 330 430 340 450 L 345 470 C 330 475 260 475 250 470 Z" fill="#ffffff" />
      <!-- Prehistoric hatching egg in corner -->
      <path d="M 390 410 C 370 410 360 440 370 470 L 450 470 C 460 440 450 410 430 410 Z" fill="#ffffff" />
      <path d="M 375 440 L 395 450 L 410 435 L 425 450 L 445 440" />
    </svg>`
  },
  {
    id: 'bunny',
    name: 'Hop the Bunny',
    subtitle: 'Soft Floppy Ears and Big Carrots',
    emoji: '🐰',
    category: 'pets',
    badgeColor: 'bg-pink-400',
    soundName: 'Hop the Bunny',
    funFact: 'When rabbits are super happy, they do a joyful twisting leap called a binky!',
    defaultColors: ['#F472B6', '#FBCFE8', '#FB923C', '#4ADE80', '#38BDF8'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Tall Bunny Ears -->
      <path d="M 190 170 C 160 100 130 20 180 20 C 220 20 220 100 215 170 Z" fill="#ffffff" />
      <path d="M 185 140 C 170 95 155 45 180 45 C 200 45 200 95 200 140 Z" fill="#ffffff" />
      <path d="M 285 170 C 280 100 280 20 320 20 C 370 20 340 100 310 170 Z" fill="#ffffff" />
      <path d="M 300 140 C 300 95 300 45 320 45 C 345 45 330 95 315 140 Z" fill="#ffffff" />
      <!-- Bunny Head -->
      <circle cx="250" cy="220" r="85" fill="#ffffff" />
      <!-- Eyes -->
      <ellipse cx="205" cy="210" rx="12" ry="16" fill="#1E293B" />
      <circle cx="200" cy="205" r="5" fill="#ffffff" stroke="none" />
      <ellipse cx="295" cy="210" rx="12" ry="16" fill="#1E293B" />
      <circle cx="290" cy="205" r="5" fill="#ffffff" stroke="none" />
      <!-- Pink Nose & Cute Mouth -->
      <polygon points="250,235 240,248 260,248" fill="#1E293B" />
      <path d="M 250 248 L 250 258 M 250 258 C 240 268 230 260 225 252 M 250 258 C 260 268 270 260 275 252" />
      <!-- Cute Whiskers -->
      <path d="M 180 245 L 120 240 M 175 258 L 115 265" />
      <path d="M 320 245 L 380 240 M 325 258 L 385 265" />
      <!-- Fluffy Body -->
      <path d="M 185 295 C 140 335 130 430 130 470 L 370 470 C 370 430 360 335 315 295" fill="#ffffff" />
      <!-- Big Giant Carrot in paws -->
      <path d="M 220 330 C 220 320 280 320 280 330 L 260 450 C 255 460 245 460 240 450 Z" fill="#ffffff" />
      <path d="M 235 360 L 260 365 M 238 395 L 258 400 M 242 425 L 255 430" />
      <!-- Carrot Top Leaves -->
      <path d="M 250 320 C 240 280 230 290 245 320 Z" fill="#ffffff" />
      <path d="M 250 320 C 250 275 260 275 255 320 Z" fill="#ffffff" />
      <path d="M 250 320 C 260 280 270 290 255 320 Z" fill="#ffffff" />
      <!-- Fluffy Round Paws Holding Carrot -->
      <circle cx="215" cy="370" r="18" fill="#ffffff" />
      <circle cx="285" cy="370" r="18" fill="#ffffff" />
      <!-- Big Feet -->
      <ellipse cx="160" cy="460" rx="35" ry="18" fill="#ffffff" />
      <ellipse cx="340" cy="460" rx="35" ry="18" fill="#ffffff" />
    </svg>`
  },
  {
    id: 'penguin',
    name: 'Penny the Penguin',
    subtitle: 'Waddling Across the Snowy Iceberg',
    emoji: '🐧',
    category: 'ocean',
    badgeColor: 'bg-teal-400',
    soundName: 'Penny the Penguin',
    funFact: 'Penguins slide on their bellies across the ice like adorable little toboggans!',
    defaultColors: ['#0D9488', '#2DD4BF', '#FBBF24', '#F87171', '#60A5FA'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Falling Snowflakes -->
      <path d="M 80 80 L 80 110 M 65 95 L 95 95 M 70 85 L 90 105 M 70 105 L 90 85" stroke-width="5" />
      <path d="M 420 90 L 420 120 M 405 105 L 435 105 M 410 95 L 430 115 M 410 115 L 430 95" stroke-width="5" />
      <!-- Penguin Body Oval -->
      <ellipse cx="250" cy="270" rx="110" ry="160" fill="#ffffff" />
      <!-- White Heart/Hourglass Tummy -->
      <path d="M 250 170 C 220 130 180 150 180 200 C 180 260 170 330 190 400 C 210 420 290 420 310 400 C 330 330 320 260 320 200 C 320 150 280 130 250 170 Z" fill="#ffffff" />
      <!-- Eyes -->
      <ellipse cx="215" cy="190" rx="12" ry="16" fill="#1E293B" />
      <circle cx="210" cy="185" r="5" fill="#ffffff" stroke="none" />
      <ellipse cx="285" cy="190" rx="12" ry="16" fill="#1E293B" />
      <circle cx="280" cy="185" r="5" fill="#ffffff" stroke="none" />
      <!-- Cute Orange Beak Triangle -->
      <path d="M 230 215 L 270 215 L 250 240 Z" fill="#ffffff" />
      <!-- Dapper Bow Tie -->
      <path d="M 220 260 C 200 245 200 285 220 270 L 250 265 L 280 270 C 300 285 300 245 280 260 Z" fill="#ffffff" />
      <circle cx="250" cy="265" r="7" fill="#ffffff" />
      <!-- Flipper Wings -->
      <path d="M 145 240 C 90 280 80 360 125 380 C 145 350 155 300 150 260" fill="#ffffff" />
      <path d="M 355 240 C 410 280 420 360 375 380 C 355 350 345 300 350 260" fill="#ffffff" />
      <!-- Cute Webbed Feet -->
      <path d="M 180 425 C 160 450 170 470 210 465 C 220 450 210 425 195 425 Z" fill="#ffffff" />
      <path d="M 320 425 C 340 450 330 470 290 465 C 280 450 290 425 305 425 Z" fill="#ffffff" />
      <!-- Floating Iceberg Platform -->
      <path d="M 80 450 L 420 450 L 400 485 L 100 485 Z" fill="#ffffff" />
    </svg>`
  },
  {
    id: 'koala',
    name: 'Koko the Koala',
    subtitle: 'Napping in Eucalyptus Trees',
    emoji: '🐨',
    category: 'safari',
    badgeColor: 'bg-emerald-500',
    soundName: 'Koko the Koala',
    funFact: 'Koalas sleep up to 18 hours a day nestled safely in tree branches!',
    defaultColors: ['#6EE7B7', '#059669', '#F472B6', '#FDE047', '#38BDF8'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Tree Trunk on Left -->
      <path d="M 70 30 L 70 480 M 130 30 L 130 480" stroke-width="9" />
      <path d="M 70 200 C 40 180 30 220 70 210" />
      <!-- Big Fluffy Koala Ears -->
      <circle cx="180" cy="140" r="44" fill="#ffffff" />
      <circle cx="180" cy="140" r="28" fill="#ffffff" />
      <circle cx="360" cy="140" r="44" fill="#ffffff" />
      <circle cx="360" cy="140" r="28" fill="#ffffff" />
      <!-- Fluffy Ear Tufts -->
      <path d="M 140 130 L 125 140 L 140 150 M 400 130 L 415 140 L 400 150" />
      <!-- Koala Head -->
      <circle cx="270" cy="205" r="90" fill="#ffffff" />
      <!-- Big Iconic Oval Nose -->
      <ellipse cx="270" cy="225" rx="28" ry="38" fill="#1E293B" />
      <ellipse cx="262" cy="210" rx="8" ry="14" fill="#ffffff" opacity="0.3" stroke="none" />
      <!-- Eyes -->
      <ellipse cx="220" cy="190" rx="12" ry="16" fill="#1E293B" />
      <circle cx="215" cy="185" r="5" fill="#ffffff" stroke="none" />
      <ellipse cx="320" cy="190" rx="12" ry="16" fill="#1E293B" />
      <circle cx="315" cy="185" r="5" fill="#ffffff" stroke="none" />
      <!-- Cute Smile under Nose -->
      <path d="M 255 270 C 265 278 275 278 285 270" />
      <!-- Hugging Arms around tree -->
      <path d="M 210 280 C 150 260 100 270 100 300 C 100 325 160 330 210 310" fill="#ffffff" />
      <!-- Body -->
      <path d="M 210 290 C 200 360 210 430 220 460 L 370 460 C 370 420 370 340 335 285" fill="#ffffff" />
      <!-- Hugging Leg at bottom -->
      <path d="M 220 410 C 150 390 100 410 100 440 C 100 465 170 470 230 450" fill="#ffffff" />
      <!-- Eucalyptus Leaves -->
      <path d="M 130 100 C 170 70 200 110 130 120 Z" fill="#ffffff" />
      <path d="M 130 150 C 90 130 80 170 130 165 Z" fill="#ffffff" />
      <path d="M 370 300 C 430 270 450 320 380 330 Z" fill="#ffffff" />
    </svg>`
  },
  {
    id: 'turtle',
    name: 'Shelly the Turtle',
    subtitle: 'Swimming with Ocean Bubbles',
    emoji: '🐢',
    category: 'ocean',
    badgeColor: 'bg-green-500',
    soundName: 'Shelly the Turtle',
    funFact: 'Sea turtles have been swimming in Earth\'s oceans since the time of dinosaurs!',
    defaultColors: ['#22C55E', '#16A34A', '#FDE047', '#38BDF8', '#FB923C'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Seaweed on sides -->
      <path d="M 40 480 C 70 400 30 340 60 260 C 80 200 50 140 70 80" stroke-width="8" />
      <path d="M 460 480 C 430 400 470 340 440 260 C 420 200 450 140 430 80" stroke-width="8" />
      <!-- Ocean Bubbles -->
      <circle cx="100" cy="180" r="14" fill="#ffffff" />
      <circle cx="120" cy="130" r="9" fill="#ffffff" />
      <circle cx="390" cy="190" r="12" fill="#ffffff" />
      <circle cx="410" cy="140" r="16" fill="#ffffff" />
      <!-- Flippers / Legs -->
      <path d="M 150 200 C 70 160 50 230 110 270 Z" fill="#ffffff" />
      <path d="M 350 200 C 430 160 450 230 390 270 Z" fill="#ffffff" />
      <path d="M 160 360 C 100 380 90 440 140 440 Z" fill="#ffffff" />
      <path d="M 340 360 C 400 380 410 440 360 440 Z" fill="#ffffff" />
      <!-- Little Tail -->
      <path d="M 240 425 L 250 460 L 260 425" fill="#ffffff" />
      <!-- Big Patterned Shell (Dome) -->
      <ellipse cx="250" cy="300" rx="125" ry="125" fill="#ffffff" />
      <!-- Shell Hexagon / Pattern Plates -->
      <polygon points="250,225 285,250 285,290 250,310 215,290 215,250" fill="#ffffff" />
      <polygon points="250,310 285,330 285,370 250,390 215,370 215,330" fill="#ffffff" />
      <path d="M 215 250 L 150 235 M 285 250 L 350 235" />
      <path d="M 215 290 L 135 300 M 285 290 L 365 300" />
      <path d="M 215 370 L 155 385 M 285 370 L 345 385" />
      <!-- Cute Turtle Head -->
      <ellipse cx="250" cy="140" rx="48" ry="42" fill="#ffffff" />
      <!-- Cheerful Eyes -->
      <ellipse cx="225" cy="130" rx="10" ry="14" fill="#1E293B" />
      <circle cx="222" cy="125" r="4" fill="#ffffff" stroke="none" />
      <ellipse cx="275" cy="130" rx="10" ry="14" fill="#1E293B" />
      <circle cx="272" cy="125" r="4" fill="#ffffff" stroke="none" />
      <!-- Sweet Smile -->
      <path d="M 235 155 C 245 168 255 168 265 155" />
    </svg>`
  },
  {
    id: 'duck',
    name: 'Ducky the Duckling',
    subtitle: 'Splashing in Water Lilies',
    emoji: '🦆',
    category: 'pets',
    badgeColor: 'bg-amber-300',
    soundName: 'Ducky the Duckling',
    funFact: 'Duck feathers are completely waterproof so they always stay warm and dry!',
    defaultColors: ['#FDE047', '#F59E0B', '#FB923C', '#38BDF8', '#4ADE80'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Pond Water Waves -->
      <path d="M 30 420 C 100 395 180 435 250 410 C 320 385 400 425 470 400 L 470 480 L 30 480 Z" fill="#ffffff" />
      <!-- Water Lily Flower & Pad -->
      <ellipse cx="100" cy="445" rx="45" ry="18" fill="#ffffff" />
      <path d="M 100 410 C 90 395 110 395 100 410 Z M 85 418 C 75 405 95 405 85 418 Z M 115 418 C 105 405 125 405 115 418 Z" fill="#ffffff" />
      <!-- Duckling Head -->
      <circle cx="205" cy="180" r="75" fill="#ffffff" />
      <!-- Feather Tuft on Head -->
      <path d="M 195 105 C 190 75 220 75 210 105" fill="#ffffff" />
      <!-- Big Cute Eye -->
      <ellipse cx="230" cy="165" rx="14" ry="18" fill="#1E293B" />
      <circle cx="224" cy="158" r="6" fill="#ffffff" stroke="none" />
      <circle cx="236" cy="172" r="3" fill="#ffffff" stroke="none" />
      <!-- Wide Smiling Orange Bill -->
      <path d="M 265 170 C 340 170 350 205 320 215 C 280 225 255 210 250 195 Z" fill="#ffffff" />
      <path d="M 270 190 C 300 195 325 190 330 185" />
      <!-- Plump Duck Body -->
      <path d="M 160 230 C 90 270 90 380 160 410 C 230 430 350 430 400 370 C 440 320 420 290 370 290 C 300 290 280 230 230 230 Z" fill="#ffffff" />
      <!-- Pointy Tail Feathers -->
      <path d="M 390 320 L 440 280 L 410 340" fill="#ffffff" />
      <!-- Cute Wing on Side -->
      <path d="M 210 290 C 180 320 200 380 270 370 C 310 360 300 300 260 290 Z" fill="#ffffff" />
      <path d="M 230 340 C 250 355 280 345 290 330" />
    </svg>`
  },
  {
    id: 'fox',
    name: 'Foxy the Red Fox',
    subtitle: 'Clever Forest Scout with Fluffy Tail',
    emoji: '🦊',
    category: 'forest',
    badgeColor: 'bg-orange-500',
    soundName: 'Foxy the Fox',
    funFact: 'Foxes use Earth\'s magnetic field to help them hunt and pounce with precision!',
    defaultColors: ['#EA580C', '#F97316', '#FDE047', '#4ADE80', '#38BDF8'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Big Pointy Ears -->
      <path d="M 170 160 L 130 60 L 230 120 Z" fill="#ffffff" />
      <path d="M 170 145 L 148 85 L 210 120 Z" fill="#ffffff" />
      <path d="M 330 160 L 370 60 L 270 120 Z" fill="#ffffff" />
      <path d="M 330 145 L 352 85 L 290 120 Z" fill="#ffffff" />
      <!-- Fox Head -->
      <polygon points="250,285 140,170 360,170" fill="#ffffff" />
      <!-- White Cheeks Mask -->
      <path d="M 250 285 L 140 170 C 190 200 230 220 250 285 Z" fill="#ffffff" />
      <path d="M 250 285 L 360 170 C 310 200 270 220 250 285 Z" fill="#ffffff" />
      <!-- Eyes -->
      <ellipse cx="205" cy="180" rx="12" ry="16" fill="#1E293B" />
      <circle cx="200" cy="175" r="5" fill="#ffffff" stroke="none" />
      <ellipse cx="295" cy="180" rx="12" ry="16" fill="#1E293B" />
      <circle cx="290" cy="175" r="5" fill="#ffffff" stroke="none" />
      <!-- Black Nose Point -->
      <circle cx="250" cy="275" r="12" fill="#1E293B" />
      <!-- Body -->
      <path d="M 190 285 C 160 330 150 430 150 470 L 350 470 C 350 430 340 330 310 285" fill="#ffffff" />
      <!-- White Chest Bib -->
      <path d="M 220 290 C 200 340 220 380 250 390 C 280 380 300 340 280 290 Z" fill="#ffffff" />
      <!-- Giant Fluffy Tail with White Tip -->
      <path d="M 340 400 C 440 380 480 260 420 210 C 370 170 330 250 350 340 Z" fill="#ffffff" />
      <!-- Zigzag White Tip of Tail -->
      <path d="M 420 210 C 400 220 395 240 405 250 L 425 245 L 435 260 C 445 245 450 230 420 210 Z" fill="#ffffff" />
      <!-- Paws -->
      <path d="M 170 470 C 170 430 220 430 220 470 Z" fill="#ffffff" />
      <path d="M 280 470 C 280 430 330 430 330 470 Z" fill="#ffffff" />
      <!-- Forest Mushroom in corner -->
      <path d="M 60 440 C 50 400 110 400 100 440 Z" fill="#ffffff" />
      <circle cx="80" cy="420" r="5" fill="#ffffff" />
      <path d="M 72 440 L 72 470 L 88 470 L 88 440" fill="#ffffff" />
    </svg>`
  },
  {
    id: 'unicorn',
    name: 'Sparkle the Unicorn',
    subtitle: 'Magical Horn with Rainbows & Stars',
    emoji: '🦄',
    category: 'magical',
    badgeColor: 'bg-purple-400',
    soundName: 'Sparkle the Unicorn',
    funFact: 'Legend says unicorns leave trails of glowing stardust wherever they prance!',
    defaultColors: ['#C084FC', '#F472B6', '#38BDF8', '#FDE047', '#34D399'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Rainbow Arc in background -->
      <path d="M 50 300 C 50 140 200 40 360 60" stroke-width="8" />
      <path d="M 50 325 C 50 165 210 65 370 85" stroke-width="8" />
      <!-- Golden Spiral Horn -->
      <path d="M 220 120 L 160 20 L 250 95 Z" fill="#ffffff" />
      <path d="M 195 65 L 230 80 M 180 45 L 210 60 M 210 90 L 242 102" />
      <!-- Ears -->
      <path d="M 260 130 C 270 70 310 80 290 140 Z" fill="#ffffff" />
      <!-- Mane Locks (Flowing hair) -->
      <path d="M 290 140 C 370 120 420 180 380 240 C 440 240 450 330 380 380 C 420 400 400 460 360 460" stroke-width="8" fill="#ffffff" />
      <path d="M 310 180 C 360 200 370 260 340 280" />
      <path d="M 330 280 C 380 300 380 370 340 380" />
      <!-- Unicorn Face & Muzzle -->
      <path d="M 260 140 C 230 140 200 170 180 220 C 160 260 100 280 110 330 C 120 370 190 380 230 340 C 270 300 290 240 290 190 Z" fill="#ffffff" />
      <!-- Nostril & Smile -->
      <circle cx="140" cy="330" r="5" fill="#1E293B" />
      <path d="M 140 348 C 160 360 180 355 190 340" />
      <!-- Beautiful Starry Eye with Lashes -->
      <ellipse cx="225" cy="225" rx="14" ry="18" fill="#1E293B" />
      <circle cx="218" cy="218" r="6" fill="#ffffff" stroke="none" />
      <circle cx="230" cy="232" r="3" fill="#ffffff" stroke="none" />
      <path d="M 235 210 L 245 200 M 240 220 L 252 215" stroke-width="5" />
      <!-- Neck & Body -->
      <path d="M 210 355 C 190 400 170 440 150 480 L 370 480 C 360 430 340 380 310 330" fill="#ffffff" />
      <!-- Sparkle Stars -->
      <path d="M 80 180 L 85 195 L 100 195 L 88 205 L 92 220 L 80 210 L 68 220 L 72 205 L 60 195 L 75 195 Z" fill="#ffffff" />
      <path d="M 430 120 L 433 130 L 445 130 L 435 137 L 438 148 L 430 140 L 422 148 L 425 137 L 415 130 L 427 130 Z" fill="#ffffff" />
    </svg>`
  },
  {
    id: 'hippo',
    name: 'Bubbles the Hippo',
    subtitle: 'Muddy Splashes and Rubber Duckies',
    emoji: '🦛',
    category: 'safari',
    badgeColor: 'bg-blue-400',
    soundName: 'Bubbles the Hippo',
    funFact: 'Hippos can hold their breath underwater for up to 5 full minutes!',
    defaultColors: ['#60A5FA', '#93C5FD', '#F472B6', '#FDE047', '#34D399'],
    svgDrawing: `<svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" stroke="#1E293B" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" fill="none">
      <!-- Muddy / Water Pool -->
      <path d="M 20 440 C 90 410 180 450 260 420 C 340 390 420 440 480 420 L 480 480 L 20 480 Z" fill="#ffffff" />
      <!-- Tiny Round Ears -->
      <circle cx="180" cy="110" r="26" fill="#ffffff" />
      <circle cx="180" cy="110" r="14" fill="#ffffff" />
      <circle cx="320" cy="110" r="26" fill="#ffffff" />
      <circle cx="320" cy="110" r="14" fill="#ffffff" />
      <!-- Hippo Head -->
      <circle cx="250" cy="190" r="85" fill="#ffffff" />
      <!-- Eyes on Top of Head -->
      <ellipse cx="205" cy="165" rx="14" ry="18" fill="#1E293B" />
      <circle cx="200" cy="160" r="6" fill="#ffffff" stroke="none" />
      <ellipse cx="295" cy="165" rx="14" ry="18" fill="#1E293B" />
      <circle cx="290" cy="160" r="6" fill="#ffffff" stroke="none" />
      <!-- Giant Snout Muzzle -->
      <ellipse cx="250" cy="265" rx="90" ry="60" fill="#ffffff" />
      <!-- Big Nostrils -->
      <ellipse cx="205" cy="250" rx="14" ry="18" fill="#1E293B" />
      <ellipse cx="295" cy="250" rx="14" ry="18" fill="#1E293B" />
      <!-- Smiling Hippo Mouth -->
      <path d="M 180 290 C 215 320 285 320 320 290" />
      <!-- Cute rounded teeth -->
      <path d="M 220 298 L 220 312 L 235 312 L 235 302 M 265 302 L 265 312 L 280 312 L 280 298" fill="#ffffff" />
      <!-- Giant Plump Body -->
      <path d="M 160 310 C 110 360 100 440 100 470 L 400 470 C 400 440 390 360 340 310" fill="#ffffff" />
      <!-- Yellow Rubber Ducky on head -->
      <path d="M 235 105 C 235 85 265 85 265 105 C 275 105 285 115 280 125 C 275 135 240 135 235 125 Z" fill="#ffffff" />
      <path d="M 265 95 L 280 98 L 265 103 Z" fill="#ffffff" />
      <circle cx="250" cy="98" r="2" fill="#1E293B" />
      <!-- Splashing Water Bubbles -->
      <circle cx="80" cy="380" r="14" fill="#ffffff" />
      <circle cx="100" cy="340" r="9" fill="#ffffff" />
      <circle cx="410" cy="370" r="16" fill="#ffffff" />
      <circle cx="430" cy="330" r="10" fill="#ffffff" />
    </svg>`
  }
];

export const CATEGORIES = [
  { id: 'all', label: 'All Animals', emoji: '🎨', count: 20 },
  { id: 'safari', label: 'Safari & Jungle', emoji: '🦁', count: 7 },
  { id: 'pets', label: 'Cute Pets', emoji: '🐶', count: 4 },
  { id: 'ocean', label: 'Ocean Friends', emoji: '🐬', count: 4 },
  { id: 'forest', label: 'Forest Friends', emoji: '🦉', count: 3 },
  { id: 'magical', label: 'Dinos & Magic', emoji: '🦄', count: 2 }
];

export const COLOR_PALETTE = [
  // Primary Brights
  { hex: '#EF4444', label: 'Cherry Red', ring: 'ring-red-400' },
  { hex: '#F97316', label: 'Tiger Orange', ring: 'ring-orange-400' },
  { hex: '#FBBF24', label: 'Sunny Yellow', ring: 'ring-amber-300' },
  { hex: '#84CC16', label: 'Lime Green', ring: 'ring-lime-400' },
  { hex: '#10B981', label: 'Jungle Green', ring: 'ring-emerald-400' },
  { hex: '#06B6D4', label: 'Aqua Cyan', ring: 'ring-cyan-400' },
  { hex: '#3B82F6', label: 'Sky Blue', ring: 'ring-blue-400' },
  { hex: '#6366F1', label: 'Indigo Blue', ring: 'ring-indigo-400' },
  { hex: '#8B5CF6', label: 'Magic Purple', ring: 'ring-purple-400' },
  { hex: '#EC4899', label: 'Cotton Pink', ring: 'ring-pink-400' },
  { hex: '#F43F5E', label: 'Strawberry', ring: 'ring-rose-400' },
  { hex: '#92400E', label: 'Teddy Brown', ring: 'ring-amber-800' },
  // Soft & Pastels
  { hex: '#FCA5A5', label: 'Soft Peach', ring: 'ring-red-200' },
  { hex: '#FED7AA', label: 'Cream', ring: 'ring-orange-200' },
  { hex: '#FEF08A', label: 'Buttercup', ring: 'ring-yellow-200' },
  { hex: '#BBF7D0', label: 'Minty', ring: 'ring-green-200' },
  { hex: '#BAE6FD', label: 'Baby Blue', ring: 'ring-sky-200' },
  { hex: '#DDD6FE', label: 'Lavender', ring: 'ring-purple-200' },
  { hex: '#FBCFE8', label: 'Princess Pink', ring: 'ring-pink-200' },
  { hex: '#D7CCC8', label: 'Sand Tan', ring: 'ring-stone-300' },
  // Neutrals
  { hex: '#FFFFFF', label: 'Cloud White', ring: 'ring-slate-300' },
  { hex: '#94A3B8', label: 'Koala Grey', ring: 'ring-slate-400' },
  { hex: '#475569', label: 'Charcoal', ring: 'ring-slate-600' },
  { hex: '#0F172A', label: 'Midnight Black', ring: 'ring-slate-900' }
];

export const STICKER_LIST: { id: string; emoji: string; label: string }[] = [
  { id: 'star', emoji: '⭐', label: 'Gold Star' },
  { id: 'heart', emoji: '💖', label: 'Sparkly Heart' },
  { id: 'rainbow', emoji: '🌈', label: 'Rainbow' },
  { id: 'paw', emoji: '🐾', label: 'Paw Print' },
  { id: 'flower', emoji: '🌸', label: 'Blossom' },
  { id: 'sparkle', emoji: '✨', label: 'Sparkles' },
  { id: 'crown', emoji: '👑', label: 'Crown' },
  { id: 'balloon', emoji: '🎈', label: 'Balloon' }
];
