package com.kids.colouringbook.drawing

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import androidx.core.graphics.PathParser
import java.util.regex.Pattern

object SvgOutlineRenderer {

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1E293B")
        style = Paint.Style.STROKE
        strokeWidth = 7f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val whiteFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val darkFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1E293B")
        style = Paint.Style.FILL
    }

    /**
     * Renders the SVG line art onto the provided canvas.
     * Scales from native 500x500 coordinates to the target canvas bounds.
     */
    fun renderSvgToCanvas(
        svgString: String,
        canvas: Canvas,
        targetWidth: Int,
        targetHeight: Int,
        renderWhiteFills: Boolean = true
    ) {
        val scaleX = targetWidth / 500f
        val scaleY = targetHeight / 500f

        canvas.save()
        canvas.scale(scaleX, scaleY)

        // Parse path tags
        val pathMatcher = Pattern.compile("<path[^>]*d=\"([^\"]+)\"[^>]*>", Pattern.CASE_INSENSITIVE).matcher(svgString)
        while (pathMatcher.find()) {
            val fullTag = pathMatcher.group(0) ?: ""
            val d = pathMatcher.group(1) ?: ""

            try {
                val path = PathParser.createPathFromPathData(d)
                val fillMatch = Pattern.compile("fill=\"([^\"]+)\"").matcher(fullTag)
                val hasFill = fillMatch.find()
                val fillColor = if (hasFill) fillMatch.group(1) else "none"

                val strokeWidthMatch = Pattern.compile("stroke-width=\"([^\"]+)\"").matcher(fullTag)
                val customStrokeWidth = if (strokeWidthMatch.find()) {
                    strokeWidthMatch.group(1)?.toFloatOrNull() ?: 7f
                } else {
                    7f
                }

                if (renderWhiteFills && (fillColor == "#ffffff" || fillColor == "white")) {
                    canvas.drawPath(path, whiteFillPaint)
                } else if (fillColor == "#1E293B" || fillColor == "#000000" || fillColor == "black") {
                    canvas.drawPath(path, darkFillPaint)
                }

                if (!fullTag.contains("stroke=\"none\"")) {
                    strokePaint.strokeWidth = customStrokeWidth
                    canvas.drawPath(path, strokePaint)
                }
            } catch (e: Exception) {
                // Fallback for custom curve path notation if needed
            }
        }

        // Parse circle tags
        val circleMatcher = Pattern.compile("<circle[^>]*cx=\"([^\"]+)\"[^>]*cy=\"([^\"]+)\"[^>]*r=\"([^\"]+)\"[^>]*>", Pattern.CASE_INSENSITIVE).matcher(svgString)
        while (circleMatcher.find()) {
            val fullTag = circleMatcher.group(0) ?: ""
            val cx = circleMatcher.group(1)?.toFloatOrNull() ?: 0f
            val cy = circleMatcher.group(2)?.toFloatOrNull() ?: 0f
            val r = circleMatcher.group(3)?.toFloatOrNull() ?: 0f

            val fillMatch = Pattern.compile("fill=\"([^\"]+)\"").matcher(fullTag)
            val fillColor = if (fillMatch.find()) fillMatch.group(1) else "none"

            if (renderWhiteFills && (fillColor == "#ffffff" || fillColor == "white")) {
                canvas.drawCircle(cx, cy, r, whiteFillPaint)
            } else if (fillColor == "#1E293B" || fillColor == "#000000" || fillColor == "black") {
                canvas.drawCircle(cx, cy, r, darkFillPaint)
            }

            if (!fullTag.contains("stroke=\"none\"")) {
                strokePaint.strokeWidth = 7f
                canvas.drawCircle(cx, cy, r, strokePaint)
            }
        }

        // Parse ellipse tags
        val ellipseMatcher = Pattern.compile("<ellipse[^>]*cx=\"([^\"]+)\"[^>]*cy=\"([^\"]+)\"[^>]*rx=\"([^\"]+)\"[^>]*ry=\"([^\"]+)\"[^>]*>", Pattern.CASE_INSENSITIVE).matcher(svgString)
        while (ellipseMatcher.find()) {
            val fullTag = ellipseMatcher.group(0) ?: ""
            val cx = ellipseMatcher.group(1)?.toFloatOrNull() ?: 0f
            val cy = ellipseMatcher.group(2)?.toFloatOrNull() ?: 0f
            val rx = ellipseMatcher.group(3)?.toFloatOrNull() ?: 0f
            val ry = ellipseMatcher.group(4)?.toFloatOrNull() ?: 0f

            val fillMatch = Pattern.compile("fill=\"([^\"]+)\"").matcher(fullTag)
            val fillColor = if (fillMatch.find()) fillMatch.group(1) else "none"

            val rect = RectF(cx - rx, cy - ry, cx + rx, cy + ry)

            if (renderWhiteFills && (fillColor == "#ffffff" || fillColor == "white")) {
                canvas.drawOval(rect, whiteFillPaint)
            } else if (fillColor == "#1E293B" || fillColor == "#000000" || fillColor == "black") {
                canvas.drawOval(rect, darkFillPaint)
            }

            if (!fullTag.contains("stroke=\"none\"")) {
                strokePaint.strokeWidth = 7f
                canvas.drawOval(rect, strokePaint)
            }
        }

        // Parse polygon tags
        val polygonMatcher = Pattern.compile("<polygon[^>]*points=\"([^\"]+)\"[^>]*>", Pattern.CASE_INSENSITIVE).matcher(svgString)
        while (polygonMatcher.find()) {
            val fullTag = polygonMatcher.group(0) ?: ""
            val pointsStr = polygonMatcher.group(1) ?: ""
            val points = pointsStr.trim().split(Regex("[\\s,]+")).mapNotNull { it.toFloatOrNull() }

            if (points.size >= 4) {
                val polyPath = Path()
                polyPath.moveTo(points[0], points[1])
                for (i in 2 until points.size - 1 step 2) {
                    polyPath.lineTo(points[i], points[i + 1])
                }
                polyPath.close()

                val fillMatch = Pattern.compile("fill=\"([^\"]+)\"").matcher(fullTag)
                val fillColor = if (fillMatch.find()) fillMatch.group(1) else "none"

                if (renderWhiteFills && (fillColor == "#ffffff" || fillColor == "white")) {
                    canvas.drawPath(polyPath, whiteFillPaint)
                } else if (fillColor == "#1E293B" || fillColor == "#000000" || fillColor == "black") {
                    canvas.drawPath(polyPath, darkFillPaint)
                }

                if (!fullTag.contains("stroke=\"none\"")) {
                    strokePaint.strokeWidth = 7f
                    canvas.drawPath(polyPath, strokePaint)
                }
            }
        }

        canvas.restore()
    }
}
