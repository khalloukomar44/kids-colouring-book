package com.kids.colouringbook.drawing

import android.graphics.Bitmap
import android.graphics.Color
import java.util.ArrayDeque

object FloodFill {

    /**
     * Efficient Queue-based 4-way Flood Fill algorithm for Android Bitmaps.
     * Takes outline boundaries into account so coloring fills inside black line art.
     */
    fun floodFill(
        bitmap: Bitmap,
        startX: Int,
        startY: Int,
        targetColor: Int,
        tolerance: Int = 30
    ): Boolean {
        val width = bitmap.width
        val height = bitmap.height

        if (startX !in 0 until width || startY !in 0 until height) return false

        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        val startIndex = startY * width + startX
        val startColor = pixels[startIndex]

        // If clicking on dark outline or same color, skip
        if (isDarkOutline(startColor) || colorsMatch(startColor, targetColor, 5)) {
            return false
        }

        val visited = BooleanArray(width * height)
        val queue = ArrayDeque<Int>()

        queue.add(startIndex)
        visited[startIndex] = true

        while (!queue.isEmpty()) {
            val idx = queue.poll() ?: continue
            pixels[idx] = targetColor

            val x = idx % width
            val y = idx / width

            // 4-way neighbors
            val neighbors = intArrayOf(
                if (x > 0) idx - 1 else -1,
                if (x < width - 1) idx + 1 else -1,
                if (y > 0) idx - width else -1,
                if (y < height - 1) idx + width else -1
            )

            for (nIdx in neighbors) {
                if (nIdx != -1 && !visited[nIdx]) {
                    visited[nIdx] = true
                    val pixelColor = pixels[nIdx]

                    if (!isDarkOutline(pixelColor) && colorsMatch(pixelColor, startColor, tolerance)) {
                        queue.add(nIdx)
                    }
                }
            }
        }

        bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
        return true
    }

    private fun isDarkOutline(color: Int): Boolean {
        val alpha = Color.alpha(color)
        if (alpha < 30) return false
        val r = Color.red(color)
        val g = Color.green(color)
        val b = Color.blue(color)
        // High darkness check (black or near-black line art)
        return (r < 75 && g < 75 && b < 85)
    }

    private fun colorsMatch(c1: Int, c2: Int, tolerance: Int): Boolean {
        if (c1 == c2) return true
        val rDiff = Math.abs(Color.red(c1) - Color.red(c2))
        val gDiff = Math.abs(Color.green(c1) - Color.green(c2))
        val bDiff = Math.abs(Color.blue(c1) - Color.blue(c2))
        val aDiff = Math.abs(Color.alpha(c1) - Color.alpha(c2))
        return rDiff <= tolerance && gDiff <= tolerance && bDiff <= tolerance && aDiff <= tolerance
    }
}
