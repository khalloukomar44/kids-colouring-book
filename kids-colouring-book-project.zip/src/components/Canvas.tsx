import React, { useState, useRef } from 'react';
import { 
  ZoomIn, ZoomOut, Maximize2, RotateCcw, 
  Wifi, Battery, Signal, Sparkles, MessageSquare, Plus
} from 'lucide-react';
import { PrototypeProject, Screen, DeviceType, Action, ComponentBlock, Annotation } from '../types/prototype';
import { InteractiveScreenRenderer } from './InteractiveScreenRenderer';

interface CanvasProps {
  project: PrototypeProject;
  activeScreen: Screen;
  device: DeviceType;
  onDispatchAction: (action: Action) => void;
  selectedBlockId?: string | null;
  onSelectBlock?: (block: ComponentBlock) => void;
  isInspectorMode?: boolean;
  toastMessage?: string | null;
  annotations: Annotation[];
  onAddAnnotation?: (ann: Partial<Annotation>) => void;
  onResolveAnnotation?: (id: string) => void;
}

export const Canvas: React.FC<CanvasProps> = ({
  project,
  activeScreen,
  device,
  onDispatchAction,
  selectedBlockId,
  onSelectBlock,
  isInspectorMode = false,
  toastMessage,
  annotations,
  onAddAnnotation,
  onResolveAnnotation,
}) => {
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [isAddingPin, setIsAddingPin] = useState(false);
  const [activePinId, setActivePinId] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleZoom = (delta: number) => {
    setZoomLevel((prev) => Math.min(150, Math.max(50, prev + delta)));
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isAddingPin || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const xPercent = Math.round(((e.clientX - rect.left) / rect.width) * 100);
    const yPercent = Math.round(((e.clientY - rect.top) / rect.height) * 100);

    const comment = prompt('Enter your design feedback annotation for this hotspot:');
    if (comment && onAddAnnotation) {
      onAddAnnotation({
        screenId: activeScreen.id,
        xPercent,
        yPercent,
        author: 'Reviewer',
        avatarColor: '#6366f1',
        text: comment,
      });
    }
    setIsAddingPin(false);
  };

  // Device frame sizing
  const getDeviceDimensions = () => {
    switch (device) {
      case 'mobile':
        return { width: '393px', height: '820px', isMobile: true, bezel: 'border-[12px] border-slate-900 rounded-[50px] shadow-2xl' };
      case 'tablet':
        return { width: '768px', height: '920px', isMobile: false, bezel: 'border-[12px] border-slate-900 rounded-[36px] shadow-2xl' };
      case 'watch':
        return { width: '280px', height: '360px', isMobile: true, bezel: 'border-[12px] border-slate-900 rounded-[44px] shadow-2xl' };
      case 'desktop':
      default:
        return { width: '100%', height: '100%', isMobile: false, bezel: 'rounded-2xl border border-slate-800/80 shadow-2xl' };
    }
  };

  const dims = getDeviceDimensions();

  return (
    <div className="flex-1 bg-[#060911] overflow-auto relative flex flex-col items-center justify-start p-4 md:p-8 select-none">
      {/* Background Blueprint Grid */}
      <div 
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, #6366f1 1px, transparent 0)`,
          backgroundSize: '24px 24px',
        }}
      />

      {/* Floating Canvas Controls Bar */}
      <div className="sticky top-2 z-30 mb-4 bg-slate-900/90 backdrop-blur-md border border-slate-800/80 rounded-2xl px-3 py-1.5 flex items-center space-x-3 shadow-xl">
        <div className="flex items-center space-x-1">
          <button
            onClick={() => handleZoom(-15)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <span className="text-xs font-mono font-semibold text-slate-300 w-10 text-center">
            {zoomLevel}%
          </span>
          <button
            onClick={() => handleZoom(15)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setZoomLevel(100)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Reset Zoom"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="h-4 w-px bg-slate-800" />

        {/* Pin Feedback Toggle */}
        <button
          onClick={() => setIsAddingPin(!isAddingPin)}
          className={`px-2.5 py-1 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-all ${
            isAddingPin
              ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
              : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800 hover:text-white'
          }`}
        >
          <MessageSquare className="w-3.5 h-3.5" />
          <span>{isAddingPin ? 'Click anywhere to drop Pin' : 'Add Feedback Pin'}</span>
        </button>

        <div className="h-4 w-px bg-slate-800" />

        <div className="text-[11px] font-medium text-slate-400">
          Screen: <span className="text-indigo-400 font-semibold">{activeScreen.name}</span>
        </div>
      </div>

      {/* Live Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-20 right-8 z-50 bg-indigo-600 text-white px-5 py-3 rounded-2xl shadow-2xl border border-indigo-400/30 flex items-center space-x-3 animate-in fade-in slide-in-from-top-4 duration-200">
          <Sparkles className="w-4 h-4 text-amber-300 shrink-0" />
          <span className="text-xs font-bold">{toastMessage}</span>
        </div>
      )}

      {/* Viewport Frame with Zoom Scale */}
      <div
        ref={containerRef}
        onClick={handleCanvasClick}
        style={{
          transform: `scale(${zoomLevel / 100})`,
          transformOrigin: 'top center',
          width: dims.width,
          minHeight: dims.height,
          maxHeight: device === 'desktop' ? 'none' : dims.height,
        }}
        className={`transition-transform duration-150 relative overflow-hidden flex flex-col bg-slate-950 ${dims.bezel} ${
          isAddingPin ? 'cursor-crosshair' : ''
        }`}
      >
        {/* Mobile Device Notch & Status Bar */}
        {dims.isMobile && (
          <div className="h-10 bg-slate-950 px-6 flex items-center justify-between text-white text-[11px] font-semibold shrink-0 z-30 select-none border-b border-slate-900/50">
            <span>09:41</span>
            {/* Dynamic Island Pill */}
            <div className="w-24 h-4.5 bg-black rounded-full flex items-center justify-end px-2 space-x-1">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            </div>
            <div className="flex items-center space-x-1.5">
              <Signal className="w-3 h-3" />
              <Wifi className="w-3 h-3" />
              <Battery className="w-3.5 h-3.5" />
            </div>
          </div>
        )}

        {/* Screen Content Wrapper */}
        <div className="flex-1 overflow-y-auto relative">
          <InteractiveScreenRenderer
            screen={activeScreen}
            theme={project.theme}
            onDispatchAction={onDispatchAction}
            selectedBlockId={selectedBlockId}
            onSelectBlock={onSelectBlock}
            isInspectorMode={isInspectorMode}
          />

          {/* Feedback Annotation Pins Overlay */}
          {annotations
            .filter((a) => a.screenId === activeScreen.id)
            .map((ann) => (
              <div
                key={ann.id}
                style={{
                  left: `${ann.xPercent}%`,
                  top: `${ann.yPercent}%`,
                }}
                className="absolute z-40 -translate-x-1/2 -translate-y-1/2 group"
              >
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setActivePinId(activePinId === ann.id ? null : ann.id);
                  }}
                  className={`w-7 h-7 rounded-full text-white text-xs font-bold flex items-center justify-center shadow-2xl transition-transform duration-200 hover:scale-125 border-2 border-white ${
                    ann.resolved ? 'bg-emerald-600' : 'bg-rose-500 animate-bounce'
                  }`}
                >
                  💬
                </button>

                {/* Comment Popup Card */}
                {activePinId === ann.id && (
                  <div className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-64 bg-slate-900 border border-slate-800 rounded-2xl p-3 text-xs text-white shadow-2xl z-50 space-y-2">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
                      <span className="font-bold text-indigo-400">{ann.author}</span>
                      <span className="text-[10px] text-slate-500">{ann.createdAt}</span>
                    </div>
                    <p className="text-slate-300 text-[11px] leading-relaxed">{ann.text}</p>
                    <div className="flex justify-end space-x-2 pt-1">
                      {onResolveAnnotation && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onResolveAnnotation(ann.id);
                            setActivePinId(null);
                          }}
                          className="text-[10px] px-2 py-1 rounded bg-slate-800 hover:bg-emerald-600/30 text-emerald-400 font-semibold"
                        >
                          {ann.resolved ? 'Reopen' : 'Mark Resolved'}
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}
        </div>

        {/* Mobile Home Bar Indicator */}
        {dims.isMobile && (
          <div className="h-6 bg-slate-950 flex items-center justify-center shrink-0 z-30 select-none">
            <div className="w-32 h-1 bg-slate-700 rounded-full" />
          </div>
        )}
      </div>
    </div>
  );
};
