package com.kids.colouringbook.model

data class AnimalPage(
    val id: String,
    val name: String,
    val subtitle: String,
    val emoji: String,
    val category: String,
    val badgeColorHex: Long,
    val soundName: String,
    val funFact: String,
    val defaultColors: List<Long>,
    val svgDrawing: String
)

data class AnimalCategory(
    val id: String,
    val label: String,
    val emoji: String,
    val count: Int
)

data class SavedArtwork(
    val id: String,
    val animalId: String,
    val animalName: String,
    val animalEmoji: String,
    val filePath: String,
    val createdAt: String
)

data class ColorOption(
    val colorHex: Long,
    val label: String
)
