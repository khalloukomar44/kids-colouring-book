import React, { useState, useEffect } from 'react';
import { SavedArtwork } from '../types/colouring';
import { sounds } from '../utils/soundEffects';
import { X, Trash2, Download, Play, Sparkles, Image as ImageIcon } from 'lucide-react';

interface MyGalleryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectAnimal: (animalId: string) => void;
}

export const MyGalleryModal: React.FC<MyGalleryModalProps> = ({
  isOpen,
  onClose,
  onSelectAnimal,
}) => {
  const [savedArts, setSavedArts] = useState<SavedArtwork[]>([]);

  const loadArts = () => {
    try {
      const list = JSON.parse(localStorage.getItem('kids_colouring_gallery') || '[]');
      setSavedArts(list);
    } catch {
      setSavedArts([]);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadArts();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    sounds.playClear();
    const updated = savedArts.filter((a) => a.id !== id);
    setSavedArts(updated);
    localStorage.setItem('kids_colouring_gallery', JSON.stringify(updated));
  };

  const handleDownload = (art: SavedArtwork, e: React.MouseEvent) => {
    e.stopPropagation();
    sounds.playSuccess();
    const link = document.createElement('a');
    link.download = `${art.animalName}_artwork.png`;
    link.href = art.dataUrl;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fade-in">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl p-5 sm:p-7 shadow-2xl border-4 border-amber-300 ring-4 ring-amber-100 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-amber-100">
          <div className="flex items-center gap-2">
            <span className="text-3xl">🖼️</span>
            <div>
              <h2 className="text-2xl font-black text-slate-800">My Saved Artworks</h2>
              <p className="text-xs font-bold text-slate-400">
                {savedArts.length} {savedArts.length === 1 ? 'drawing' : 'drawings'} saved
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              sounds.playPop(300);
              onClose();
            }}
            className="p-2 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 transition-all btn-3d"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Gallery Grid */}
        <div className="flex-1 overflow-y-auto pr-1 no-scrollbar min-h-[250px]">
          {savedArts.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-8 text-slate-400">
              <div className="text-6xl mb-3 animate-float-slow">🎨</div>
              <p className="font-bold text-base text-slate-600 mb-1">No saved drawings yet!</p>
              <p className="text-xs text-slate-400 max-w-xs">
                Color any cute animal and tap the green &quot;Save&quot; button to keep it here in your personal gallery!
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5 sm:gap-4">
              {savedArts.map((art) => (
                <div
                  key={art.id}
                  onClick={() => {
                    sounds.playPop(520);
                    onSelectAnimal(art.animalId);
                    onClose();
                  }}
                  className="group relative bg-amber-50 rounded-2xl p-2.5 border-3 border-amber-200 hover:border-amber-400 hover:shadow-lg transition-all cursor-pointer flex flex-col items-center"
                >
                  <div className="relative w-full aspect-square bg-white rounded-xl overflow-hidden shadow-inner mb-2 flex items-center justify-center">
                    <img
                      src={art.thumbnailUrl}
                      alt={art.animalName}
                      className="w-full h-full object-contain"
                    />
                    <div className="absolute inset-0 bg-amber-900/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <div className="px-3 py-1.5 rounded-full bg-amber-500 text-white font-black text-xs flex items-center gap-1 shadow-lg">
                        <Play className="w-3.5 h-3.5 fill-current" /> Color More
                      </div>
                    </div>
                  </div>

                  <div className="w-full flex items-center justify-between text-left">
                    <div className="truncate">
                      <p className="font-black text-xs sm:text-sm text-slate-800 truncate">
                        {art.animalEmoji} {art.animalName}
                      </p>
                      <p className="text-[10px] text-slate-400 font-bold">{art.createdAt}</p>
                    </div>

                    <div className="flex items-center gap-1 shrink-0 ml-1">
                      <button
                        onClick={(e) => handleDownload(art, e)}
                        className="p-1.5 rounded-lg bg-emerald-100 text-emerald-700 hover:bg-emerald-200 transition-colors"
                        title="Download image"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={(e) => handleDelete(art.id, e)}
                        className="p-1.5 rounded-lg bg-rose-100 text-rose-600 hover:bg-rose-200 transition-colors"
                        title="Delete artwork"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
