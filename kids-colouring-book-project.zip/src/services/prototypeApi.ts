import { PrototypeProject, Screen, PersonaAuditResult, ABVariant } from '../types/prototype';

export async function generateAIPrototype(
  prompt: string,
  category: string = 'saas',
  device: string = 'desktop',
  style: string = 'dark'
): Promise<PrototypeProject> {
  const res = await fetch('/api/prototype/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt, category, device, style }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to generate prototype');
  }

  const data = await res.json();
  const proto: PrototypeProject = data.prototype;
  if (!proto.id) proto.id = 'proto-' + Date.now();
  if (!proto.annotations) proto.annotations = [];
  proto.createdAt = new Date().toISOString();
  proto.updatedAt = new Date().toISOString();
  return proto;
}

export async function refineScreenWithAI(
  currentScreen: Screen,
  prompt: string,
  theme: any
): Promise<Screen> {
  const res = await fetch('/api/prototype/refine', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ currentScreen, prompt, theme }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to refine screen');
  }

  const data = await res.json();
  return data.screen;
}

export async function addScreenWithAI(
  currentProject: PrototypeProject,
  goal: string
): Promise<Screen> {
  const res = await fetch('/api/prototype/add-screen', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ currentProject, goal }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to add screen');
  }

  const data = await res.json();
  return data.screen;
}

export async function runPersonaAuditWithAI(
  project: PrototypeProject
): Promise<PersonaAuditResult[]> {
  const res = await fetch('/api/prototype/persona-audit', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ project }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to run persona audit');
  }

  const data = await res.json();
  return data.audits || [];
}

export async function generateABVariantWithAI(
  currentScreen: Screen,
  optimizationGoal: string
): Promise<ABVariant> {
  const res = await fetch('/api/prototype/ab-test', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ currentScreen, optimizationGoal }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to generate AB variant');
  }

  const data = await res.json();
  return data.variant;
}
