import React, { useState, useEffect } from 'react';
import { 
  SlidersHorizontal, Sparkles, Trash2, ArrowUp, ArrowDown, 
  Check, Layers, Link as LinkIcon, Edit3
} from 'lucide-react';
import { ComponentBlock, Screen, Action } from '../types/prototype';

interface InspectorPanelProps {
  selectedBlock: ComponentBlock | null;
  activeScreen: Screen;
  allScreens: Screen[];
  onUpdateBlock: (updatedBlock: ComponentBlock) => void;
  onDeleteBlock: (blockId: string) => void;
  onMoveBlock: (blockId: string, direction: 'up' | 'down') => void;
  onClose: () => void;
}

export const InspectorPanel: React.FC<InspectorPanelProps> = ({
  selectedBlock,
  activeScreen,
  allScreens,
  onUpdateBlock,
  onDeleteBlock,
  onMoveBlock,
  onClose,
}) => {
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [badge, setBadge] = useState('');
  const [primaryCta, setPrimaryCta] = useState('');
  const [navTarget, setNavTarget] = useState('');

  useEffect(() => {
    if (selectedBlock) {
      setTitle(selectedBlock.title || '');
      setSubtitle(selectedBlock.subtitle || '');
      setBadge(selectedBlock.props?.badge || '');
      setPrimaryCta(selectedBlock.props?.primaryCta || '');
      setNavTarget(selectedBlock.actions?.onPrimaryClick?.targetScreenId || '');
    }
  }, [selectedBlock]);

  if (!selectedBlock) {
    return (
      <aside className="w-80 border-l border-slate-800/80 bg-slate-950/95 p-6 flex flex-col items-center justify-center text-center space-y-3 select-none">
        <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400">
          <SlidersHorizontal className="w-5 h-5" />
        </div>
        <h4 className="text-sm font-bold text-white">Element Inspector</h4>
        <p className="text-xs text-slate-400 max-w-[200px] leading-relaxed">
          Click any component block in the prototype canvas to inspect and live-tweak its properties.
        </p>
      </aside>
    );
  }

  const handleSave = () => {
    const updatedProps = { ...selectedBlock.props };
    if (badge !== undefined) updatedProps.badge = badge;
    if (primaryCta !== undefined) updatedProps.primaryCta = primaryCta;

    const updatedActions = { ...selectedBlock.actions };
    if (navTarget) {
      updatedActions.onPrimaryClick = {
        type: 'navigate',
        targetScreenId: navTarget,
      };
    }

    const updated: ComponentBlock = {
      ...selectedBlock,
      title,
      subtitle,
      props: updatedProps,
      actions: updatedActions,
    };

    onUpdateBlock(updated);
  };

  return (
    <aside className="w-80 border-l border-slate-800/80 bg-slate-950/95 flex flex-col shrink-0 select-none z-20 overflow-y-auto">
      {/* Header */}
      <div className="p-4 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Edit3 className="w-4 h-4 text-indigo-400" />
          <span className="font-bold text-xs text-white uppercase tracking-wider">
            Inspect: {selectedBlock.type}
          </span>
        </div>
        <button
          onClick={onClose}
          className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded-lg hover:bg-slate-800"
        >
          ✕
        </button>
      </div>

      <div className="p-4 space-y-5 flex-1">
        {/* Block Ordering & Delete Bar */}
        <div className="flex items-center justify-between bg-slate-900/80 p-2 rounded-xl border border-slate-800">
          <span className="text-[11px] font-semibold text-slate-400">Position</span>
          <div className="flex items-center space-x-1">
            <button
              onClick={() => onMoveBlock(selectedBlock.id, 'up')}
              className="p-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
              title="Move Up"
            >
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onMoveBlock(selectedBlock.id, 'down')}
              className="p-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
              title="Move Down"
            >
              <ArrowDown className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onDeleteBlock(selectedBlock.id)}
              className="p-1 rounded-lg bg-slate-800 text-slate-400 hover:text-rose-400"
              title="Delete Block"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Title */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-300">Heading Title</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
          />
        </div>

        {/* Subtitle */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-300">Subtitle / Description</label>
          <textarea
            rows={3}
            value={subtitle}
            onChange={(e) => setSubtitle(e.target.value)}
            className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500 resize-none"
          />
        </div>

        {/* Badge (if applicable) */}
        {selectedBlock.type === 'hero' && (
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Pill Badge Text</label>
            <input
              type="text"
              value={badge}
              onChange={(e) => setBadge(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
          </div>
        )}

        {/* Primary CTA Button Text */}
        {selectedBlock.props?.primaryCta !== undefined && (
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">Primary CTA Label</label>
            <input
              type="text"
              value={primaryCta}
              onChange={(e) => setPrimaryCta(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
          </div>
        )}

        {/* Link / Transition Hotspot */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-300 flex items-center space-x-1.5">
            <LinkIcon className="w-3.5 h-3.5 text-indigo-400" />
            <span>Click Action Link Target</span>
          </label>
          <select
            value={navTarget}
            onChange={(e) => setNavTarget(e.target.value)}
            className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
          >
            <option value="">-- No Navigation Action --</option>
            {allScreens.map((s) => (
              <option key={s.id} value={s.id}>
                Navigate to: {s.name}
              </option>
            ))}
          </select>
        </div>

        <button
          onClick={handleSave}
          className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center space-x-1.5"
        >
          <Check className="w-4 h-4" />
          <span>Apply Changes</span>
        </button>
      </div>
    </aside>
  );
};
