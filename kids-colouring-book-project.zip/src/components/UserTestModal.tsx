import React, { useState, useEffect } from 'react';
import { 
  FlaskConical, CheckCircle2, Clock, Trophy, 
  ArrowRight, Sparkles, RotateCcw, AlertCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { PrototypeProject, Screen } from '../types/prototype';

interface UserTestModalProps {
  project: PrototypeProject;
  activeScreen: Screen;
  onClose: () => void;
  onNavigateScreen: (screenId: string) => void;
}

interface TestTask {
  id: string;
  title: string;
  description: string;
  targetScreenId?: string;
  completed: boolean;
}

export const UserTestModal: React.FC<UserTestModalProps> = ({
  project,
  activeScreen,
  onClose,
  onNavigateScreen,
}) => {
  const [secondsElapsed, setSecondsElapsed] = useState(0);
  const [isRunning, setIsRunning] = useState(true);
  const [tasks, setTasks] = useState<TestTask[]>([
    {
      id: 'task-1',
      title: '1. Inspect the Starting Executive View',
      description: 'Review the primary KPI metrics and verify the data accuracy.',
      targetScreenId: project.initialScreenId,
      completed: true,
    },
    {
      id: 'task-2',
      title: '2. Execute an AI Query Copilot Search',
      description: 'Interact with the Gemini natural language prompt box on the main canvas.',
      completed: false,
    },
    {
      id: 'task-3',
      title: '3. Navigate to Connected Flow Screen',
      description: 'Click any link, row, or sidebar item to transition to screen 2.',
      targetScreenId: project.screens[1]?.id || project.initialScreenId,
      completed: false,
    },
    {
      id: 'task-4',
      title: '4. Open an Interactive Modal & Confirm Action',
      description: 'Trigger the Upgrade or Settings dialog and verify the modal flow.',
      completed: false,
    },
  ]);

  useEffect(() => {
    let timer: any;
    if (isRunning) {
      timer = setInterval(() => {
        setSecondsElapsed((s) => s + 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isRunning]);

  const toggleTask = (id: string) => {
    const updated = tasks.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t));
    setTasks(updated);

    const allDone = updated.every((t) => t.completed);
    if (allDone) {
      setIsRunning(false);
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 },
      });
    }
  };

  const completedCount = tasks.filter((t) => t.completed).length;
  const progressPercent = Math.round((completedCount / tasks.length) * 100);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 select-none animate-in fade-in zoom-in-95 duration-150">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 max-w-xl w-full shadow-2xl space-y-6 text-white relative">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center justify-center">
              <FlaskConical className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold">Live Usability Test Mission</h3>
              <p className="text-xs text-slate-400">Step-by-step interactive scenario testing</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white"
          >
            ✕
          </button>
        </div>

        {/* Timer & Progress Bar */}
        <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4 text-slate-400" />
            <span className="text-xs font-semibold text-slate-300">Elapsed Time:</span>
            <span className="font-mono text-sm font-bold text-amber-400">{formatTime(secondsElapsed)}</span>
          </div>

          <div className="flex items-center space-x-3">
            <div className="text-right">
              <div className="text-xs font-bold text-white">{completedCount}/{tasks.length} Completed</div>
              <div className="text-[10px] text-slate-500">{progressPercent}% progress</div>
            </div>
            <div className="w-16 h-2 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-emerald-500 transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* Tasks List */}
        <div className="space-y-3">
          {tasks.map((task) => (
            <div
              key={task.id}
              onClick={() => toggleTask(task.id)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start justify-between space-x-3 ${
                task.completed
                  ? 'bg-emerald-950/20 border-emerald-500/40 text-slate-300'
                  : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 text-white'
              }`}
            >
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <span className={`text-xs font-bold ${task.completed ? 'line-through text-slate-500' : 'text-white'}`}>
                    {task.title}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">{task.description}</p>
              </div>

              <button
                className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 border transition-all ${
                  task.completed
                    ? 'bg-emerald-600 border-emerald-500 text-white'
                    : 'border-slate-700 bg-slate-900 text-transparent'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>

        {progressPercent === 100 && (
          <div className="p-4 rounded-2xl bg-emerald-950/50 border border-emerald-500/30 text-center space-y-2 animate-bounce">
            <Trophy className="w-8 h-8 text-amber-400 mx-auto" />
            <div className="text-sm font-bold text-white">🎉 Usability Mission Completed!</div>
            <p className="text-xs text-emerald-300">
              Completed all 4 scenario steps in {formatTime(secondsElapsed)}. Prototype friction score is optimal!
            </p>
          </div>
        )}

        <div className="flex justify-end space-x-3 pt-2">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition-all"
          >
            Continue Exploring Prototype
          </button>
        </div>
      </div>
    </div>
  );
};
