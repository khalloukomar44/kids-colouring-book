import React, { useState } from 'react';
import { 
  Sparkles, RefreshCw, Wand2, Plus, ShieldCheck, 
  GitBranch, Zap, Bot, CheckCircle2, ArrowRight
} from 'lucide-react';
import { PrototypeProject, Screen, ABVariant, PersonaAuditResult } from '../types/prototype';
import { 
  generateAIPrototype, 
  refineScreenWithAI, 
  addScreenWithAI, 
  generateABVariantWithAI, 
  runPersonaAuditWithAI 
} from '../services/prototypeApi';

interface AIAssistantModalProps {
  initialTab?: 'generate' | 'refine' | 'add-screen' | 'audit' | 'ab-test';
  project: PrototypeProject;
  activeScreen: Screen;
  onApplyNewProject: (newProject: PrototypeProject) => void;
  onApplyRefinedScreen: (updatedScreen: Screen) => void;
  onApplyNewScreen: (newScreen: Screen) => void;
  onApplyABVariant: (variant: ABVariant) => void;
  onApplyAudits: (audits: PersonaAuditResult[]) => void;
  onClose: () => void;
}

export const AIAssistantModal: React.FC<AIAssistantModalProps> = ({
  initialTab = 'generate',
  project,
  activeScreen,
  onApplyNewProject,
  onApplyRefinedScreen,
  onApplyNewScreen,
  onApplyABVariant,
  onApplyAudits,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'generate' | 'refine' | 'add-screen' | 'ab-test'>(
    initialTab === 'audit' ? 'generate' : initialTab
  );

  const [promptInput, setPromptInput] = useState('');
  const [category, setCategory] = useState<'saas' | 'mobile' | 'ecommerce' | 'ai' | 'fintech' | 'health' | 'devops' | 'custom'>('saas');
  const [device, setDevice] = useState<'desktop' | 'mobile' | 'tablet'>('desktop');
  const [style, setStyle] = useState<'dark' | 'light' | 'slate' | 'navy'>('dark');
  const [isLoading, setIsLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');

  // Sample prompt ideas
  const samplePrompts = [
    'AI-powered Video Generation Studio with timeline editor, prompt bar, and billing modal',
    'Fintech Neo-Bank for Creators with crypto staking, virtual cards, and invoice factoring',
    'Developer Cloud Infrastructure dashboard with Kubernetes cluster health and incident logs',
    'Luxury Fashion Marketplace with 3D product previews and 1-click Apple Pay checkout',
    'AI Healthcare Telemedicine portal with patient vitals monitor and specialist booking calendar',
  ];

  const handleGeneratePrototype = async () => {
    if (!promptInput.trim()) return;
    setIsLoading(true);
    setStatusMessage('🧠 Gemini 3.7 Flash is synthesizing UI hierarchy and screen flows...');
    try {
      const newProto = await generateAIPrototype(promptInput, category, device, style);
      onApplyNewProject(newProto);
      onClose();
    } catch (err: any) {
      alert(err.message || 'Failed to generate prototype');
    } finally {
      setIsLoading(false);
      setStatusMessage('');
    }
  };

  const handleRefineScreen = async () => {
    if (!promptInput.trim()) return;
    setIsLoading(true);
    setStatusMessage('✨ Refining screen layout, blocks, and interactions with Gemini...');
    try {
      const updatedScreen = await refineScreenWithAI(activeScreen, promptInput, project.theme);
      onApplyRefinedScreen(updatedScreen);
      onClose();
    } catch (err: any) {
      alert(err.message || 'Failed to refine screen');
    } finally {
      setIsLoading(false);
      setStatusMessage('');
    }
  };

  const handleAddScreen = async () => {
    if (!promptInput.trim()) return;
    setIsLoading(true);
    setStatusMessage('➕ Crafting new connected flow screen with Gemini...');
    try {
      const newScreen = await addScreenWithAI(project, promptInput);
      onApplyNewScreen(newScreen);
      onClose();
    } catch (err: any) {
      alert(err.message || 'Failed to add screen');
    } finally {
      setIsLoading(false);
      setStatusMessage('');
    }
  };

  const handleGenerateABTest = async () => {
    setIsLoading(true);
    setStatusMessage('⚖️ Generating high-converting A/B Variant B with Gemini CRO reasoning...');
    try {
      const variant = await generateABVariantWithAI(
        activeScreen,
        promptInput || 'Maximize sign-up conversion rate and reduce cognitive friction'
      );
      onApplyABVariant(variant);
      onClose();
    } catch (err: any) {
      alert(err.message || 'Failed to generate A/B variant');
    } finally {
      setIsLoading(false);
      setStatusMessage('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 select-none animate-in fade-in zoom-in-95 duration-150">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8 max-w-2xl w-full shadow-2xl space-y-6 text-white relative overflow-hidden">
        {/* Glowing aura */}
        <div className="absolute -top-24 -right-24 w-72 h-72 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-500 to-emerald-400 p-0.5 shadow-lg shadow-indigo-500/20">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center text-amber-300">
                <Sparkles className="w-5 h-5" />
              </div>
            </div>
            <div>
              <h3 className="text-base font-extrabold tracking-tight">Gemini AI Prototype Co-Pilot</h3>
              <p className="text-xs text-slate-400">Generate, refine, or audit multi-screen interactive flows.</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Mode Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 bg-slate-950 p-1.5 rounded-2xl border border-slate-800">
          <button
            onClick={() => setActiveTab('generate')}
            className={`py-2 px-2 rounded-xl text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all ${
              activeTab === 'generate'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Wand2 className="w-3.5 h-3.5" />
            <span>Generate App</span>
          </button>

          <button
            onClick={() => setActiveTab('refine')}
            className={`py-2 px-2 rounded-xl text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all ${
              activeTab === 'refine'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Refine Screen</span>
          </button>

          <button
            onClick={() => setActiveTab('add-screen')}
            className={`py-2 px-2 rounded-xl text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all ${
              activeTab === 'add-screen'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>+ Add Flow</span>
          </button>

          <button
            onClick={() => setActiveTab('ab-test')}
            className={`py-2 px-2 rounded-xl text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all ${
              activeTab === 'ab-test'
                ? 'bg-indigo-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <GitBranch className="w-3.5 h-3.5" />
            <span>A/B Variant</span>
          </button>
        </div>

        {/* Tab 1: Generate from Prompt */}
        {activeTab === 'generate' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-400">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
                >
                  <option value="saas">SaaS Analytics</option>
                  <option value="mobile">Mobile SuperApp</option>
                  <option value="ecommerce">Luxury E-Commerce</option>
                  <option value="ai">AI Agent Studio</option>
                  <option value="fintech">Fintech & Banking</option>
                  <option value="health">Healthcare & Med</option>
                  <option value="devops">DevOps & Cloud</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-400">Target Device</label>
                <select
                  value={device}
                  onChange={(e) => setDevice(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
                >
                  <option value="desktop">Desktop (1440px)</option>
                  <option value="mobile">Mobile iPhone (393px)</option>
                  <option value="tablet">iPad Tablet (768px)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-semibold text-slate-400">Theme Atmosphere</label>
                <select
                  value={style}
                  onChange={(e) => setStyle(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white"
                >
                  <option value="dark">Dark Titanium</option>
                  <option value="slate">Deep Slate</option>
                  <option value="navy">Midnight Navy</option>
                  <option value="light">Clean Light</option>
                </select>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">
                Describe your vision or product concept
              </label>
              <textarea
                rows={3}
                value={promptInput}
                onChange={(e) => setPromptInput(e.target.value)}
                placeholder="e.g., An autonomous AI agent platform where marketers configure multi-channel campaigns, view live conversion funnels, and test landing page copy variants..."
                className="w-full px-4 py-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500 resize-none leading-relaxed placeholder-slate-500"
              />
            </div>

            {/* Inspiration Chips */}
            <div className="space-y-1.5">
              <div className="text-[11px] font-semibold text-slate-400">Sample prompt ideas:</div>
              <div className="flex flex-wrap gap-1.5">
                {samplePrompts.slice(0, 3).map((idea, idx) => (
                  <button
                    key={idx}
                    onClick={() => setPromptInput(idea)}
                    className="text-[11px] px-2.5 py-1 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 hover:text-white hover:border-indigo-500/50 transition-colors text-left truncate max-w-xs"
                  >
                    💡 {idea}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleGeneratePrototype}
              disabled={isLoading || !promptInput.trim()}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 text-white font-extrabold text-xs shadow-xl shadow-indigo-600/30 hover:opacity-95 transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{statusMessage || 'Synthesizing Prototype...'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>Generate Complete Prototype with Gemini</span>
                </>
              )}
            </button>
          </div>
        )}

        {/* Tab 2: Refine Screen */}
        {activeTab === 'refine' && (
          <div className="space-y-4">
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-slate-300 flex items-center space-x-2">
              <span className="font-semibold text-indigo-400">Target Screen:</span>
              <span className="font-bold text-white">{activeScreen.name}</span>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">
                What modifications would you like to make?
              </label>
              <textarea
                rows={3}
                value={promptInput}
                onChange={(e) => setPromptInput(e.target.value)}
                placeholder="e.g., 'Add a real-time revenue projection chart with monthly toggle', 'Make the CTA high-contrast with dark glass borders', 'Add a customer testimonial carousel'..."
                className="w-full px-4 py-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500 resize-none leading-relaxed placeholder-slate-500"
              />
            </div>

            <button
              onClick={handleRefineScreen}
              disabled={isLoading || !promptInput.trim()}
              className="w-full py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs shadow-xl shadow-indigo-600/30 transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{statusMessage || 'Refining Screen...'}</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>Apply AI Refinement</span>
                </>
              )}
            </button>
          </div>
        )}

        {/* Tab 3: Add Flow Screen */}
        {activeTab === 'add-screen' && (
          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">
                What screen or user flow do you want to add?
              </label>
              <textarea
                rows={3}
                value={promptInput}
                onChange={(e) => setPromptInput(e.target.value)}
                placeholder="e.g., 'A checkout confirmation and shipping tracker screen', 'User profile settings with 2FA security controls', 'AI prompt template library drawer'..."
                className="w-full px-4 py-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500 resize-none leading-relaxed placeholder-slate-500"
              />
            </div>

            <button
              onClick={handleAddScreen}
              disabled={isLoading || !promptInput.trim()}
              className="w-full py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold text-xs shadow-xl shadow-indigo-600/30 transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{statusMessage || 'Creating Screen...'}</span>
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4 text-amber-300" />
                  <span>Generate & Link New Screen</span>
                </>
              )}
            </button>
          </div>
        )}

        {/* Tab 4: A/B CRO Variant */}
        {activeTab === 'ab-test' && (
          <div className="space-y-4">
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-slate-300 flex items-center space-x-2">
              <span className="font-semibold text-indigo-400">Baseline Screen:</span>
              <span className="font-bold text-white">{activeScreen.name}</span>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300">
                Optimization Objective
              </label>
              <input
                type="text"
                value={promptInput}
                onChange={(e) => setPromptInput(e.target.value)}
                placeholder="e.g., Maximize trial signups by increasing social proof and outcome-driven copy"
                className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <button
              onClick={handleGenerateABTest}
              disabled={isLoading}
              className="w-full py-3.5 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-extrabold text-xs shadow-xl shadow-purple-600/30 transition-all flex items-center justify-center space-x-2 disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{statusMessage || 'Synthesizing CRO Variant...'}</span>
                </>
              ) : (
                <>
                  <GitBranch className="w-4 h-4 text-amber-300" />
                  <span>Generate High-Converting Variant B</span>
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
