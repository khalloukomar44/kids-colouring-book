import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const archiver = require('archiver');

const outputZipPath = path.resolve('kids-colouring-book-project.zip');
const output = fs.createWriteStream(outputZipPath);

// archiver.create or new archiver.ZipArchive
const archive = archiver.create ? archiver.create('zip', { zlib: { level: 9 } }) : new archiver.ZipArchive({ zlib: { level: 9 } });

output.on('close', function () {
  console.log(`Successfully created ZIP archive: ${outputZipPath} (${(archive.pointer() / 1024 / 1024).toFixed(2)} MB)`);
});

archive.on('error', function (err) {
  throw err;
});

archive.pipe(output);

archive.glob('**/*', {
  cwd: process.cwd(),
  ignore: [
    'node_modules/**',
    '.git/**',
    'dist/**',
    '*.zip',
    '*.tar.gz'
  ],
  dot: true
});

archive.finalize();
