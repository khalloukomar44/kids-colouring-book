package com.kids.colouringbook.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.kids.colouringbook.model.SavedArtwork
import com.kids.colouringbook.sound.SoundEffects
import com.kids.colouringbook.storage.GalleryStorage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class GalleryViewModel(application: Application) : AndroidViewModel(application) {

    private val _artworks = MutableStateFlow<List<SavedArtwork>>(emptyList())
    val artworks: StateFlow<List<SavedArtwork>> = _artworks.asStateFlow()

    init {
        loadArtworks()
    }

    fun loadArtworks() {
        _artworks.value = GalleryStorage.loadAllArtworks(getApplication())
    }

    fun deleteArtwork(id: String) {
        GalleryStorage.deleteArtwork(getApplication(), id)
        loadArtworks()
        SoundEffects.playClear()
    }

    fun shareArtwork(artwork: SavedArtwork) {
        GalleryStorage.shareArtwork(getApplication(), artwork)
    }
}
