# Kids Colouring Book - Android App 🎨📱

This directory contains the native Android Studio project written in **Kotlin** and **Jetpack Compose**.

## How to Export / Build a Downloadable APK

### Method 1: Using Android Studio (Recommended UI Method)
1. **Open Project**: Launch Android Studio, select **Open**, and browse to this `/android` folder.
2. **Sync Gradle**: Let Android Studio download dependencies and sync the project automatically.
3. **Build Debug APK**:
   - Go to top menu: **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
   - Once completed, click the pop-up notification **"locate"** (or find the file at `android/app/build/outputs/apk/debug/app-debug.apk`).
4. **Build Release / Signed APK**:
   - Go to top menu: **Build** > **Generate Signed Bundle / APK...**
   - Choose **APK** and click **Next**.
   - Select or create your keystore (or choose debug keystore for testing), select **release**, and click **Finish**.
   - Your optimized APK will be in `android/app/build/outputs/apk/release/app-release.apk`.

---

### Method 2: Using Command Line (Terminal)
Open a terminal in the `/android` directory:

```bash
# Navigate to android folder
cd android

# Build Debug APK
./gradlew assembleDebug

# Build Release APK (unsigned or configured with signing config)
./gradlew assembleRelease
```

The generated APK will be available at:
* **Debug APK**: `android/app/build/outputs/apk/debug/app-debug.apk`
* **Release APK**: `android/app/build/outputs/apk/release/app-release-unsigned.apk`

---

### How to Install the APK on Your Android Device
1. Transfer the `.apk` file to your phone via USB, Google Drive, Email, or WhatsApp.
2. On your Android phone, open your **Files** app and tap `app-debug.apk`.
3. If prompted, enable **"Install from unknown sources"** / **"Allow from this source"**.
4. Tap **Install** and enjoy colouring!
