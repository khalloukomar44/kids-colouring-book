import React, { useState } from 'react';
import { 
  Sparkles, Zap, Activity, Shield, Bot, Users, TrendingUp, 
  Download, Plus, Search, ChevronRight, ArrowUpRight, CheckCircle2,
  AlertCircle, Settings, Bell, HelpCircle, BarChart3, Send, 
  QrCode, RefreshCw, PlusCircle, Laptop, ArrowDownLeft, Car,
  ShoppingBag, Headphones, ShieldCheck, Check, Info, ArrowRight,
  SlidersHorizontal, CreditCard, LayoutDashboard, Layers, Clock, Wallet,
  ArrowRightLeft
} from 'lucide-react';
import { Screen, ComponentBlock, Action, ThemeConfig, ScreenModal } from '../types/prototype';

interface InteractiveScreenRendererProps {
  screen: Screen;
  theme: ThemeConfig;
  onDispatchAction: (action: Action) => void;
  selectedBlockId?: string | null;
  onSelectBlock?: (block: ComponentBlock) => void;
  isInspectorMode?: boolean;
}

export const InteractiveScreenRenderer: React.FC<InteractiveScreenRendererProps> = ({
  screen,
  theme,
  onDispatchAction,
  selectedBlockId,
  onSelectBlock,
  isInspectorMode = false,
}) => {
  // Local state for interactive UI
  const [activeModal, setActiveModal] = useState<ScreenModal | null>(null);
  const [activeChartTimeframe, setActiveChartTimeframe] = useState('30D');
  const [promptInputValue, setPromptInputValue] = useState('');
  const [tableFilter, setTableFilter] = useState('');
  const [pricingCycle, setPricingCycle] = useState<'monthly' | 'annual'>('monthly');
  const [formInputs, setFormInputs] = useState<Record<string, any>>({});

  // Theme styling helpers
  const isDark = theme.bgStyle !== 'light';
  const bgClass = theme.bgStyle === 'light' 
    ? 'bg-slate-50 text-slate-900' 
    : theme.bgStyle === 'navy' 
    ? 'bg-[#0b1329] text-slate-100'
    : theme.bgStyle === 'slate'
    ? 'bg-[#0f172a] text-slate-100'
    : 'bg-[#090d16] text-slate-100';

  const cardBgClass = theme.bgStyle === 'light'
    ? 'bg-white border-slate-200 shadow-sm text-slate-900'
    : 'bg-slate-900/80 border-slate-800/80 text-slate-100 shadow-lg';

  const borderClass = theme.borderRadius || 'rounded-2xl';

  const handleAction = (action?: Action) => {
    if (!action) return;
    if (action.type === 'open_modal' && action.modalId) {
      const modal = screen.modals?.find((m) => m.id === action.modalId);
      if (modal) {
        setActiveModal(modal);
        return;
      }
    }
    if (action.type === 'close_modal') {
      setActiveModal(null);
      return;
    }
    onDispatchAction(action);
  };

  const getIconComponent = (iconName?: string) => {
    switch (iconName) {
      case 'Sparkles': return Sparkles;
      case 'Zap': return Zap;
      case 'Activity': return Activity;
      case 'Shield': return Shield;
      case 'Bot': return Bot;
      case 'Users': return Users;
      case 'TrendingUp': return TrendingUp;
      case 'Download': return Download;
      case 'Plus': return Plus;
      case 'Wallet': return Wallet;
      case 'CreditCard': return CreditCard;
      case 'Clock': return Clock;
      case 'ArrowRightLeft': return ArrowRightLeft;
      case 'ShoppingBag': return ShoppingBag;
      case 'Headphones': return Headphones;
      case 'ShieldCheck': return ShieldCheck;
      case 'Laptop': return Laptop;
      case 'ArrowDownLeft': return ArrowDownLeft;
      case 'Car': return Car;
      default: return Activity;
    }
  };

  return (
    <div className={`w-full min-h-full ${bgClass} font-sans flex flex-col relative transition-colors duration-200 selection:bg-indigo-500 selection:text-white`}>
      {/* 1. Navigation Header Bar */}
      {screen.navBar && (
        <header className={`px-6 py-3.5 border-b sticky top-0 z-20 backdrop-blur-md flex items-center justify-between ${
          theme.bgStyle === 'light' ? 'bg-white/80 border-slate-200' : 'bg-slate-950/80 border-slate-800/80'
        }`}>
          <div className="flex items-center space-x-6">
            {/* Brand Logo & Name */}
            <div className="flex items-center space-x-2.5 cursor-pointer">
              <div 
                className="w-8 h-8 rounded-xl flex items-center justify-center text-white shadow-md"
                style={{ backgroundColor: theme.primaryColor }}
              >
                {React.createElement(getIconComponent(screen.navBar.logoIcon), { className: 'w-4 h-4' })}
              </div>
              <span className="font-extrabold text-sm tracking-tight">{screen.navBar.brandName}</span>
            </div>

            {/* Links */}
            {screen.navBar.links && screen.navBar.links.length > 0 && (
              <nav className="hidden md:flex items-center space-x-1">
                {screen.navBar.links.map((link) => (
                  <button
                    key={link.id}
                    onClick={() => handleAction(link.action)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      link.active
                        ? isDark ? 'bg-slate-800 text-white shadow-sm' : 'bg-slate-100 text-slate-900 font-bold'
                        : isDark ? 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    {link.label}
                  </button>
                ))}
              </nav>
            )}
          </div>

          {/* Right Actions */}
          {screen.navBar.rightActions && (
            <div className="flex items-center space-x-2">
              {screen.navBar.rightActions.map((ra) => {
                const IconComp = ra.icon ? getIconComponent(ra.icon) : null;
                const isPrimary = ra.variant === 'primary' || !ra.variant;
                return (
                  <button
                    key={ra.id}
                    onClick={() => handleAction(ra.action)}
                    style={isPrimary ? { backgroundColor: theme.primaryColor } : {}}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-all shadow-sm ${
                      isPrimary
                        ? 'text-white hover:opacity-90 shadow-md'
                        : isDark
                        ? 'bg-slate-800 text-slate-200 hover:bg-slate-700 border border-slate-700'
                        : 'bg-slate-100 text-slate-800 hover:bg-slate-200 border border-slate-200'
                    }`}
                  >
                    {IconComp && <IconComp className="w-3.5 h-3.5" />}
                    <span>{ra.label}</span>
                  </button>
                );
              })}
            </div>
          )}
        </header>
      )}

      {/* Main Body */}
      <div className="flex-1 flex flex-col md:flex-row">
        {/* Sidebar (if present) */}
        {screen.sideBar && (
          <aside className={`w-56 border-r p-4 space-y-6 hidden md:block shrink-0 ${
            theme.bgStyle === 'light' ? 'bg-slate-50/80 border-slate-200' : 'bg-slate-950/40 border-slate-800/80'
          }`}>
            {screen.sideBar.header && (
              <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 px-3">
                {screen.sideBar.header}
              </div>
            )}
            <nav className="space-y-1">
              {screen.sideBar.items.map((item) => {
                const IconComp = getIconComponent(item.icon);
                return (
                  <button
                    key={item.id}
                    onClick={() => handleAction(item.action)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                      item.active
                        ? isDark
                          ? 'bg-indigo-600/20 text-indigo-400 font-semibold border border-indigo-500/30'
                          : 'bg-indigo-50 text-indigo-600 font-semibold border border-indigo-200'
                        : isDark
                        ? 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`}
                  >
                    <span className="flex items-center space-x-2.5">
                      <IconComp className="w-4 h-4 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </span>
                    {item.badge && (
                      <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono ${
                        isDark ? 'bg-slate-800 text-slate-300' : 'bg-slate-200 text-slate-700'
                      }`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </aside>
        )}

        {/* Content Blocks Canvas */}
        <main className="flex-1 p-6 md:p-8 space-y-6 max-w-6xl mx-auto w-full">
          {screen.blocks.map((block) => {
            const isSelected = isInspectorMode && selectedBlockId === block.id;

            return (
              <div
                key={block.id}
                onClick={() => {
                  if (isInspectorMode && onSelectBlock) {
                    onSelectBlock(block);
                  }
                }}
                className={`transition-all ${
                  isInspectorMode
                    ? `cursor-pointer hover:ring-2 hover:ring-indigo-400 rounded-2xl ${
                        isSelected ? 'ring-2 ring-indigo-500 shadow-xl' : ''
                      }`
                    : ''
                }`}
              >
                {renderBlockContent(block)}
              </div>
            );
          })}
        </main>
      </div>

      {/* Mobile Bottom Navigation (if present) */}
      {screen.bottomNav && (
        <nav className={`sticky bottom-0 z-20 px-4 py-2.5 border-t flex items-center justify-around backdrop-blur-lg ${
          theme.bgStyle === 'light' ? 'bg-white/90 border-slate-200' : 'bg-slate-950/90 border-slate-800/90'
        }`}>
          {screen.bottomNav.items.map((item) => {
            const IconComp = getIconComponent(item.icon);
            return (
              <button
                key={item.id}
                onClick={() => handleAction(item.action)}
                className={`flex flex-col items-center space-y-1 transition-all ${
                  item.active
                    ? 'text-indigo-400 font-semibold'
                    : isDark ? 'text-slate-400 hover:text-slate-200' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <IconComp className="w-4 h-4" />
                <span className="text-[10px]">{item.label}</span>
              </button>
            );
          })}
        </nav>
      )}

      {/* Active Modal Flow Dialog */}
      {activeModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in zoom-in-95 duration-150">
          <div className={`w-full ${
            activeModal.size === 'lg' ? 'max-w-3xl' : activeModal.size === 'sm' ? 'max-w-sm' : 'max-w-lg'
          } ${cardBgClass} ${borderClass} p-6 border shadow-2xl space-y-6`}>
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
              <div>
                <h3 className="text-base font-bold text-white">{activeModal.title}</h3>
                {activeModal.subtitle && (
                  <p className="text-xs text-slate-400 mt-0.5">{activeModal.subtitle}</p>
                )}
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="w-8 h-8 rounded-xl bg-slate-800/80 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              {activeModal.blocks?.map((mb) => (
                <div key={mb.id}>{renderBlockContent(mb)}</div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );

  // Helper block renderer
  function renderBlockContent(block: ComponentBlock) {
    switch (block.type) {
      case 'hero':
        return (
          <section className={`p-8 md:p-12 border ${borderClass} relative overflow-hidden space-y-6 ${
            isDark
              ? 'bg-gradient-to-br from-indigo-950/40 via-slate-900/60 to-slate-900/30 border-indigo-500/20 shadow-xl'
              : 'bg-gradient-to-br from-indigo-50/70 via-white to-slate-50 border-indigo-100 shadow-md'
          }`}>
            {block.props?.badge && (
              <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{block.props.badge}</span>
              </div>
            )}

            <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight max-w-3xl leading-tight">
              {block.title || 'Transform your digital workflow'}
            </h1>

            {block.subtitle && (
              <p className="text-slate-400 text-sm md:text-base max-w-2xl leading-relaxed">
                {block.subtitle}
              </p>
            )}

            {/* Metrics Pills (if any) */}
            {block.props?.metrics && (
              <div className="flex flex-wrap gap-4 pt-2">
                {block.props.metrics.map((m: any, idx: number) => (
                  <div key={idx} className="px-4 py-2 rounded-xl bg-slate-900/60 border border-slate-800/80">
                    <div className="text-xs text-slate-400">{m.label}</div>
                    <div className="text-sm font-bold text-white">{m.value}</div>
                  </div>
                ))}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-3 pt-2">
              {block.props?.primaryCta && (
                <button
                  onClick={() => handleAction(block.actions?.onPrimaryClick)}
                  style={{ backgroundColor: theme.primaryColor }}
                  className="px-6 py-3 rounded-xl text-white font-semibold text-xs md:text-sm shadow-lg hover:opacity-95 transition-all flex items-center space-x-2"
                >
                  <span>{block.props.primaryCta}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}
              {block.props?.secondaryCta && (
                <button
                  onClick={() => handleAction(block.actions?.onSecondaryClick)}
                  className={`px-6 py-3 rounded-xl text-xs md:text-sm font-semibold border transition-all ${
                    isDark
                      ? 'bg-slate-900/80 hover:bg-slate-800 text-slate-200 border-slate-700/80'
                      : 'bg-white hover:bg-slate-50 text-slate-800 border-slate-200'
                  }`}
                >
                  {block.props.secondaryCta}
                </button>
              )}
            </div>
          </section>
        );

      case 'ai_prompt_box':
        return (
          <div className={`p-5 md:p-6 border ${cardBgClass} ${borderClass} space-y-4`}>
            <div className="flex items-center space-x-2.5">
              <div 
                className="w-7 h-7 rounded-lg flex items-center justify-center text-white shadow-sm"
                style={{ backgroundColor: theme.primaryColor }}
              >
                <Bot className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold">{block.title || 'Gemini Intelligence Copilot'}</h3>
                {block.subtitle && <p className="text-xs text-slate-400">{block.subtitle}</p>}
              </div>
            </div>

            {/* Prompt Input Form */}
            <div className="flex items-center space-x-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={promptInputValue}
                  onChange={(e) => setPromptInputValue(e.target.value)}
                  placeholder={block.props?.placeholder || 'Type an instruction or query...'}
                  className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${
                    isDark ? 'bg-slate-950 border-slate-800 text-white placeholder-slate-500' : 'bg-slate-50 border-slate-200 text-slate-900 placeholder-slate-400'
                  }`}
                />
              </div>
              <button
                onClick={() => {
                  handleAction(block.actions?.onExecute || {
                    type: 'toast',
                    toastMessage: `🤖 Copilot executed: "${promptInputValue || 'Default query'}"`,
                    toastType: 'success',
                  });
                  setPromptInputValue('');
                }}
                style={{ backgroundColor: theme.primaryColor }}
                className="px-4 py-3 rounded-xl text-white font-semibold text-xs hover:opacity-90 transition-all flex items-center space-x-1.5 shadow-md shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Ask AI</span>
              </button>
            </div>

            {/* Quick Prompt Chips */}
            {block.props?.quickPrompts && (
              <div className="flex flex-wrap gap-2 pt-1">
                {block.props.quickPrompts.map((qp: string, idx: number) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setPromptInputValue(qp);
                      handleAction(block.actions?.onExecute || {
                        type: 'toast',
                        toastMessage: `🤖 Copilot generated insights for: "${qp}"`,
                        toastType: 'info',
                      });
                    }}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-medium border transition-all ${
                      isDark
                        ? 'bg-slate-950/60 hover:bg-slate-800 border-slate-800 text-slate-300'
                        : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
                    }`}
                  >
                    💡 {qp}
                  </button>
                ))}
              </div>
            )}
          </div>
        );

      case 'stats_grid':
        const cols = block.props?.columns || 4;
        const gridColsClass = cols === 2 ? 'grid-cols-1 sm:grid-cols-2' : cols === 3 ? 'grid-cols-1 sm:grid-cols-3' : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4';
        return (
          <section className={`grid ${gridColsClass} gap-4`}>
            {block.props?.items?.map((item: any) => (
              <div
                key={item.id}
                onClick={() => handleAction({ type: 'toast', toastMessage: `Drilling down into ${item.label}...`, toastType: 'info' })}
                className={`p-5 border ${cardBgClass} ${borderClass} hover:border-slate-700 cursor-pointer transition-all space-y-2`}
              >
                <div className="text-xs font-medium text-slate-400">{item.label}</div>
                <div className="flex items-baseline justify-between">
                  <div className="text-2xl font-extrabold tracking-tight">{item.value}</div>
                  <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full border ${
                    item.trend === 'up'
                      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                      : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                  }`}>
                    {item.change}
                  </span>
                </div>
                {item.subtext && (
                  <div className="text-[11px] text-slate-400 pt-0.5">{item.subtext}</div>
                )}
              </div>
            ))}
          </section>
        );

      case 'chart':
        return (
          <section className={`p-6 border ${cardBgClass} ${borderClass} space-y-6`}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold">{block.title || 'Analytics Breakdown'}</h3>
                {block.subtitle && <p className="text-xs text-slate-400 mt-0.5">{block.subtitle}</p>}
              </div>

              {/* Timeframe selector tabs */}
              <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-xl border border-slate-800/80">
                {['7D', '30D', '90D', '1Y'].map((tf) => (
                  <button
                    key={tf}
                    onClick={() => {
                      setActiveChartTimeframe(tf);
                      handleAction(block.actions?.onTimeframeChange);
                    }}
                    className={`px-3 py-1 text-xs font-semibold rounded-lg transition-all ${
                      activeChartTimeframe === tf
                        ? 'bg-indigo-600 text-white shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {tf}
                  </button>
                ))}
              </div>
            </div>

            {/* Simulated Live Interactive Bar & Area Chart */}
            <div className="h-56 flex items-end justify-between gap-3 pt-6 border-b border-slate-800/80 pb-2">
              {block.props?.dataPoints?.map((dp: any, idx: number) => {
                const heightPercent = Math.min(100, Math.max(25, (dp.value / 150000) * 100));
                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-2 group cursor-pointer">
                    <div className="w-full bg-slate-800/40 rounded-t-xl h-full flex items-end relative overflow-hidden">
                      <div
                        className="w-full rounded-t-xl transition-all duration-500 group-hover:opacity-100 opacity-80"
                        style={{
                          height: `${heightPercent}%`,
                          backgroundColor: theme.primaryColor,
                        }}
                      />
                    </div>
                    <span className="text-[10px] font-semibold text-slate-400 truncate max-w-full">
                      {dp.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </section>
        );

      case 'data_table':
        return (
          <section className={`p-6 border ${cardBgClass} ${borderClass} space-y-4`}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold">{block.title || 'Directory'}</h3>
                {block.subtitle && <p className="text-xs text-slate-400 mt-0.5">{block.subtitle}</p>}
              </div>

              <div className="relative max-w-xs w-full">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={tableFilter}
                  onChange={(e) => setTableFilter(e.target.value)}
                  placeholder={block.props?.searchPlaceholder || 'Search records...'}
                  className={`w-full pl-9 pr-3 py-2 rounded-xl text-xs border focus:outline-none focus:ring-2 focus:ring-indigo-500 ${
                    isDark ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                  }`}
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800/80 text-slate-400 uppercase font-semibold text-[10px] tracking-wider">
                    {block.props?.headers?.map((h: string, idx: number) => (
                      <th key={idx} className="pb-3 px-3">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {block.props?.rows
                    ?.filter((r: any) =>
                      !tableFilter ||
                      r.name?.toLowerCase().includes(tableFilter.toLowerCase()) ||
                      r.tier?.toLowerCase().includes(tableFilter.toLowerCase())
                    )
                    .map((row: any) => (
                      <tr
                        key={row.id}
                        onClick={() => handleAction(block.actions?.onRowClick || { type: 'toast', toastMessage: `Opened ${row.name}`, toastType: 'info' })}
                        className="hover:bg-slate-800/30 transition-colors cursor-pointer"
                      >
                        <td className="py-3 px-3">
                          <div className="font-semibold text-white">{row.name}</div>
                          {row.sub && <div className="text-[10px] text-slate-400">{row.sub}</div>}
                        </td>
                        <td className="py-3 px-3 text-slate-300">{row.tier || '-'}</td>
                        <td className="py-3 px-3 font-mono font-bold text-emerald-400">{row.mrr || '-'}</td>
                        <td className="py-3 px-3 text-slate-400">{row.health || '-'}</td>
                        <td className="py-3 px-3">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold border ${
                            row.statusColor === 'green'
                              ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                              : row.statusColor === 'amber'
                              ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                              : 'bg-rose-500/10 text-rose-400 border-rose-500/20'
                          }`}>
                            {row.status || 'Active'}
                          </span>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </section>
        );

      case 'card_grid':
        return (
          <section className="space-y-4">
            {block.title && (
              <div>
                <h3 className="text-base font-bold">{block.title}</h3>
                {block.subtitle && <p className="text-xs text-slate-400 mt-0.5">{block.subtitle}</p>}
              </div>
            )}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {block.props?.cards?.map((card: any) => (
                <div
                  key={card.id}
                  onClick={() => handleAction(block.actions?.onCardClick || { type: 'toast', toastMessage: `Selected ${card.title}`, toastType: 'info' })}
                  className={`p-5 border ${cardBgClass} ${borderClass} hover:border-indigo-500/60 transition-all cursor-pointer flex flex-col justify-between space-y-4`}
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-sm text-white">{card.title}</span>
                      {card.badge && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                          {card.badge}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 leading-relaxed">{card.description}</p>
                  </div>

                  {card.metrics && (
                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800/80">
                      {card.metrics.map((m: any, idx: number) => (
                        <div key={idx}>
                          <div className="text-[10px] text-slate-400">{m.label}</div>
                          <div className="text-xs font-bold text-white">{m.value}</div>
                        </div>
                      ))}
                    </div>
                  )}

                  {card.ctaText && (
                    <button
                      style={{ backgroundColor: theme.primaryColor }}
                      className="w-full py-2 rounded-xl text-white font-semibold text-xs shadow-md hover:opacity-90 transition-all flex items-center justify-center space-x-1.5"
                    >
                      <span>{card.ctaText}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </section>
        );

      case 'pricing_table':
        return (
          <section className="space-y-6">
            <div className="text-center space-y-2">
              <h3 className="text-xl font-extrabold">{block.title || 'Simple, transparent pricing'}</h3>
              {block.subtitle && <p className="text-xs text-slate-400">{block.subtitle}</p>}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {block.props?.tiers?.map((tier: any, idx: number) => (
                <div
                  key={idx}
                  className={`p-6 border ${borderClass} flex flex-col justify-between space-y-6 ${
                    tier.popular
                      ? 'bg-slate-900 border-indigo-500/80 shadow-2xl shadow-indigo-950/60 relative'
                      : cardBgClass
                  }`}
                >
                  {tier.popular && (
                    <span className="absolute -top-3 right-6 px-3 py-1 rounded-full text-[10px] font-bold bg-indigo-600 text-white shadow-lg">
                      MOST POPULAR
                    </span>
                  )}
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-lg font-bold text-white">{tier.name}</h4>
                      <p className="text-xs text-slate-400 mt-1">{tier.description}</p>
                    </div>
                    <div className="flex items-baseline space-x-1">
                      <span className="text-3xl font-extrabold text-white">{tier.price}</span>
                      <span className="text-xs text-slate-400">{tier.period}</span>
                    </div>

                    <div className="space-y-2 pt-2 border-t border-slate-800/80">
                      {tier.features?.map((f: string, fIdx: number) => (
                        <div key={fIdx} className="flex items-center space-x-2 text-xs text-slate-300">
                          <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                          <span>{f}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={() => handleAction(block.actions?.onSelectTier || { type: 'toast', toastMessage: `Selected plan: ${tier.name}`, toastType: 'success' })}
                    style={tier.popular ? { backgroundColor: theme.primaryColor } : {}}
                    className={`w-full py-2.5 rounded-xl font-bold text-xs transition-all shadow-md ${
                      tier.popular
                        ? 'text-white hover:opacity-95'
                        : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                    }`}
                  >
                    {tier.ctaLabel || 'Get Started'}
                  </button>
                </div>
              ))}
            </div>
          </section>
        );

      case 'mobile_balance_card':
        return (
          <div className="space-y-5">
            {/* Visual Glassmorphic Payment Card */}
            <div className={`p-6 rounded-3xl bg-gradient-to-tr from-slate-900 via-indigo-950/80 to-slate-900 border border-indigo-500/30 text-white shadow-2xl space-y-6 relative overflow-hidden`}>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold">{block.props?.currency || 'Total Balance'}</div>
                  <div className="text-3xl font-black tracking-tight">{block.props?.balance || '$0.00'}</div>
                </div>
                <div className="text-xs font-bold px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  {block.props?.dailyChange}
                </div>
              </div>

              <div className="flex items-center justify-between text-xs font-mono pt-4 border-t border-slate-800/80 text-slate-300">
                <span>{block.props?.cardHolder || 'User Card'}</span>
                <span>{block.props?.cardNumberMask || '•••• 8829'}</span>
              </div>
            </div>

            {/* Quick Action Icons Bar */}
            {block.props?.actions && (
              <div className="grid grid-cols-4 gap-2">
                {block.props.actions.map((act: any) => {
                  const IconComp = getIconComponent(act.icon);
                  return (
                    <button
                      key={act.id}
                      onClick={() => handleAction(act.action)}
                      className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800/80 hover:border-indigo-500/60 hover:bg-slate-900 text-white flex flex-col items-center space-y-1.5 transition-all"
                    >
                      <div 
                        className="w-8 h-8 rounded-xl flex items-center justify-center text-white shadow-sm"
                        style={{ backgroundColor: theme.primaryColor }}
                      >
                        <IconComp className="w-4 h-4" />
                      </div>
                      <span className="text-[11px] font-semibold text-slate-200">{act.label}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        );

      case 'activity_feed':
        return (
          <section className={`p-6 border ${cardBgClass} ${borderClass} space-y-4`}>
            {block.title && (
              <div>
                <h3 className="text-base font-bold">{block.title}</h3>
                {block.subtitle && <p className="text-xs text-slate-400 mt-0.5">{block.subtitle}</p>}
              </div>
            )}
            <div className="divide-y divide-slate-800/80">
              {block.props?.items?.map((it: any) => {
                const IconComp = getIconComponent(it.icon);
                return (
                  <div
                    key={it.id}
                    onClick={() => handleAction(block.actions?.onItemClick || { type: 'toast', toastMessage: `Selected ${it.title}`, toastType: 'info' })}
                    className="py-3 flex items-center justify-between hover:bg-slate-800/30 px-2 rounded-xl transition-colors cursor-pointer"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-9 h-9 rounded-xl bg-slate-800/80 flex items-center justify-center text-indigo-400">
                        <IconComp className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white">{it.title}</div>
                        <div className="text-[10px] text-slate-400">{it.sub}</div>
                      </div>
                    </div>
                    <div className={`text-xs font-mono font-bold ${
                      it.type === 'income' ? 'text-emerald-400' : 'text-slate-200'
                    }`}>
                      {it.amount}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        );

      case 'form_card':
        return (
          <div className={`p-6 border ${cardBgClass} ${borderClass} space-y-4`}>
            {block.title && (
              <div>
                <h3 className="text-base font-bold">{block.title}</h3>
                {block.subtitle && <p className="text-xs text-slate-400 mt-0.5">{block.subtitle}</p>}
              </div>
            )}

            <div className="space-y-3">
              {block.props?.fields?.map((f: any) => (
                <div key={f.id} className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-300">{f.label}</label>
                  {f.type === 'select' ? (
                    <select
                      value={formInputs[f.id] || f.options?.[0]}
                      onChange={(e) => setFormInputs({ ...formInputs, [f.id]: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500"
                    >
                      {f.options?.map((opt: string) => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  ) : f.type === 'switch' ? (
                    <div className="flex items-center justify-between pt-1">
                      <span className="text-xs text-slate-400">Active</span>
                      <input
                        type="checkbox"
                        defaultChecked={f.defaultChecked}
                        className="w-4 h-4 accent-indigo-600 rounded cursor-pointer"
                      />
                    </div>
                  ) : (
                    <input
                      type={f.type || 'text'}
                      value={formInputs[f.id] || ''}
                      onChange={(e) => setFormInputs({ ...formInputs, [f.id]: e.target.value })}
                      placeholder={f.placeholder || ''}
                      disabled={f.disabled}
                      className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white focus:outline-none focus:border-indigo-500 placeholder-slate-500"
                    />
                  )}
                </div>
              ))}
            </div>

            <button
              onClick={() => handleAction(block.actions?.onSubmit || { type: 'toast', toastMessage: 'Form submitted successfully!', toastType: 'success' })}
              style={{ backgroundColor: theme.primaryColor }}
              className="w-full py-2.5 rounded-xl text-white font-bold text-xs shadow-md hover:opacity-90 transition-all"
            >
              {block.props?.submitLabel || 'Submit Form'}
            </button>
          </div>
        );

      case 'banner_alert':
        return (
          <div className="p-4 rounded-2xl bg-indigo-950/50 border border-indigo-500/30 flex items-center justify-between gap-4">
            <div className="flex items-center space-x-3">
              <Sparkles className="w-5 h-5 text-indigo-400 shrink-0" />
              <div>
                <div className="text-xs font-bold text-white">{block.title}</div>
                <div className="text-[11px] text-slate-400">{block.subtitle}</div>
              </div>
            </div>
            {block.props?.actionLabel && (
              <button
                onClick={() => handleAction(block.actions?.onAction)}
                className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs shrink-0 transition-all"
              >
                {block.props.actionLabel}
              </button>
            )}
          </div>
        );

      default:
        return (
          <div className={`p-6 border ${cardBgClass} ${borderClass} space-y-2`}>
            <h4 className="text-sm font-bold">{block.title || block.type}</h4>
            <p className="text-xs text-slate-400">{block.subtitle || ''}</p>
          </div>
        );
    }
  }
};
