export type DeviceType = 'desktop' | 'mobile' | 'tablet' | 'watch';

export type ActionType = 
  | 'navigate' 
  | 'open_modal' 
  | 'close_modal' 
  | 'toast' 
  | 'toggle_state' 
  | 'simulate_ai' 
  | 'external';

export interface Action {
  type: ActionType;
  targetScreenId?: string;
  modalId?: string;
  toastMessage?: string;
  toastType?: 'success' | 'info' | 'warning';
  stateKey?: string;
  aiPrompt?: string;
  label?: string;
}

export type BlockType = 
  | 'hero'
  | 'stats_grid'
  | 'chart'
  | 'data_table'
  | 'card_grid'
  | 'feature_list'
  | 'form_card'
  | 'pricing_table'
  | 'ai_prompt_box'
  | 'mobile_balance_card'
  | 'timeline_steps'
  | 'chat_interface'
  | 'banner_alert'
  | 'component_showcase'
  | 'activity_feed';

export interface ComponentBlock {
  id: string;
  type: BlockType;
  title?: string;
  subtitle?: string;
  props: Record<string, any>;
  actions?: Record<string, Action>;
}

export interface ScreenModal {
  id: string;
  title: string;
  subtitle?: string;
  size?: 'sm' | 'md' | 'lg';
  blocks: ComponentBlock[];
  closeAction?: Action;
}

export interface Screen {
  id: string;
  name: string;
  type: 'page' | 'modal' | 'drawer';
  badge?: string;
  navBar?: {
    brandName: string;
    logoIcon?: string;
    links: { id: string; label: string; action: Action; active?: boolean }[];
    rightActions?: { id: string; label: string; icon?: string; action: Action; variant?: 'primary' | 'secondary' | 'ghost' }[];
  };
  sideBar?: {
    header?: string;
    items: { id: string; label: string; icon: string; badge?: string; active?: boolean; action: Action }[];
  };
  bottomNav?: {
    items: { id: string; label: string; icon: string; active?: boolean; action: Action }[];
  };
  blocks: ComponentBlock[];
  modals?: ScreenModal[];
}

export interface ThemeConfig {
  primaryColor: string; // e.g. '#6366f1' or 'indigo'
  accentColor: string;
  bgStyle: 'dark' | 'light' | 'zinc' | 'slate' | 'navy';
  fontFamily: 'Inter' | 'Plus Jakarta Sans' | 'Space Grotesk' | 'Playfair' | 'JetBrains Mono';
  borderRadius: 'rounded-none' | 'rounded-md' | 'rounded-xl' | 'rounded-2xl' | 'rounded-full';
  density: 'compact' | 'comfortable' | 'spacious';
}

export interface Annotation {
  id: string;
  screenId: string;
  xPercent: number;
  yPercent: number;
  author: string;
  avatarColor: string;
  text: string;
  resolved: boolean;
  createdAt: string;
}

export interface PersonaAuditResult {
  personaName: string;
  personaRole: string;
  avatar: string;
  overallScore: number; // 0 - 100
  summary: string;
  heuristics: {
    name: string;
    score: number; // 1 - 5
    note: string;
  }[];
  positives: string[];
  frictionPoints: string[];
  recommendations: string[];
  predictedHeatmapAreas: {
    label: string;
    interestLevel: 'high' | 'medium' | 'low';
    clickLikelihood: number; // %
  }[];
}

export interface ABVariant {
  id: string;
  name: string;
  hypothesis: string;
  predictedConversionLift: string;
  keyChanges: string[];
  variantScreen: Screen;
}

export interface PrototypeProject {
  id: string;
  title: string;
  description: string;
  category: 'saas' | 'mobile' | 'ecommerce' | 'ai' | 'fintech' | 'health' | 'devops' | 'custom';
  device: DeviceType;
  theme: ThemeConfig;
  screens: Screen[];
  initialScreenId: string;
  annotations: Annotation[];
  personaAudits?: PersonaAuditResult[];
  abVariants?: ABVariant[];
  createdAt: string;
  updatedAt: string;
}

export type ViewMode = 
  | 'interactive' 
  | 'flow-map' 
  | 'inspector' 
  | 'usability-audit' 
  | 'user-test' 
  | 'code-export' 
  | 'presentation';
