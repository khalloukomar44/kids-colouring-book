package com.kids.colouringbook.model

enum class StickerType(val id: String, val emoji: String, val label: String) {
    STAR("star", "⭐", "Gold Star"),
    HEART("heart", "💖", "Sparkly Heart"),
    RAINBOW("rainbow", "🌈", "Rainbow"),
    PAW("paw", "🐾", "Paw Print"),
    FLOWER("flower", "🌸", "Blossom"),
    SPARKLE("sparkle", "✨", "Sparkles"),
    CROWN("crown", "👑", "Crown"),
    BALLOON("balloon", "🎈", "Balloon")
}
