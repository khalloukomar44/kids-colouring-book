import React, { useState } from 'react';
import { 
  Layers, Plus, Trash2, Copy, Sparkles, Palette, 
  Component, Layout, BarChart, Table, CreditCard, 
  Bot, MessageSquare, Tag, ShieldCheck, ChevronRight, 
  Sliders, Check, RefreshCw
} from 'lucide-react';
import { PrototypeProject, Screen, BlockType, ComponentBlock, ThemeConfig } from '../types/prototype';

interface SidebarProps {
  project: PrototypeProject;
  activeScreenId: string;
  onSelectScreen: (screenId: string) => void;
  onAddScreen: (newScreen: Screen) => void;
  onDeleteScreen: (screenId: string) => void;
  onDuplicateScreen: (screenId: string) => void;
  onInsertBlock: (block: ComponentBlock) => void;
  onUpdateTheme: (newTheme: Partial<ThemeConfig>) => void;
  onOpenAIModal: (tab: 'generate' | 'refine' | 'add-screen' | 'audit' | 'ab-test') => void;
}

type TabType = 'screens' | 'components' | 'theme';

export const Sidebar: React.FC<SidebarProps> = ({
  project,
  activeScreenId,
  onSelectScreen,
  onAddScreen,
  onDeleteScreen,
  onDuplicateScreen,
  onInsertBlock,
  onUpdateTheme,
  onOpenAIModal,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('screens');

  const handleCreateBlankScreen = () => {
    const newId = 'screen-' + Date.now();
    const newScreen: Screen = {
      id: newId,
      name: `New Screen ${project.screens.length + 1}`,
      type: 'page',
      badge: 'Custom',
      navBar: {
        brandName: project.title.split(' - ')[0] || 'App',
        links: [
          { id: 'l1', label: 'Home', action: { type: 'navigate', targetScreenId: project.initialScreenId } },
        ],
      },
      blocks: [
        {
          id: 'blk-' + Date.now(),
          type: 'hero',
          title: 'Welcome to your new screen',
          subtitle: 'Add components or use AI co-pilot to craft high-fidelity blocks.',
          props: {
            badge: 'Fresh Canvas',
            primaryCta: 'Explore Features',
            secondaryCta: 'Contact Us',
          },
        },
      ],
    };
    onAddScreen(newScreen);
  };

  const handleQuickAddBlock = (type: BlockType) => {
    const id = 'block-' + Date.now();
    let newBlock: ComponentBlock;

    switch (type) {
      case 'stats_grid':
        newBlock = {
          id,
          type: 'stats_grid',
          title: 'Key Performance Indicators',
          props: {
            columns: 4,
            items: [
              { id: 's1', label: 'Conversion Rate', value: '4.82%', change: '+1.2%', trend: 'up', subtext: 'Top 10% sector' },
              { id: 's2', label: 'Avg Order Value', value: '$84.50', change: '+8.4%', trend: 'up', subtext: '+$6.20 vs last week' },
              { id: 's3', label: 'Session Duration', value: '3m 42s', change: '+14.1%', trend: 'up', subtext: 'Mobile optimized' },
              { id: 's4', label: 'NPS Score', value: '+74', change: '+5 pts', trend: 'up', subtext: 'World-class benchmark' },
            ],
          },
        };
        break;

      case 'chart':
        newBlock = {
          id,
          type: 'chart',
          title: 'Engagement & Velocity Trends',
          subtitle: 'Telemetry streamed via live webhooks',
          props: {
            chartType: 'area',
            dataPoints: [
              { label: 'Mon', value: 12000 },
              { label: 'Tue', value: 19000 },
              { label: 'Wed', value: 34000 },
              { label: 'Thu', value: 48000 },
              { label: 'Fri', value: 62000 },
              { label: 'Sat', value: 78000 },
              { label: 'Sun', value: 92000 },
            ],
          },
        };
        break;

      case 'ai_prompt_box':
        newBlock = {
          id,
          type: 'ai_prompt_box',
          title: 'Gemini Copilot Query Assistant',
          subtitle: 'Natural language interface into application data and automation pipelines',
          props: {
            placeholder: 'Ask: "Generate a summary of today\'s conversion bottlenecks..."',
            quickPrompts: ['Summarize daily metrics', 'Find top converting channels', 'Draft email report'],
          },
        };
        break;

      case 'data_table':
        newBlock = {
          id,
          type: 'data_table',
          title: 'Operational Records & Inventory',
          subtitle: 'Filtered by active workspace permissions',
          props: {
            searchPlaceholder: 'Search records...',
            headers: ['Item Name', 'Category', 'Volume', 'Status'],
            rows: [
              { id: 'r1', name: 'Alpha Telemetry Node', sub: 'Cluster 01', tier: 'High Priority', mrr: '14,200 req/s', status: 'Online', statusColor: 'green' },
              { id: 'r2', name: 'Beta Ingestion Pipeline', sub: 'Cluster 02', tier: 'Standard', mrr: '8,400 req/s', status: 'Healthy', statusColor: 'green' },
              { id: 'r3', name: 'Gamma Cache Router', sub: 'Edge US', tier: 'Critical', mrr: '24,900 req/s', status: 'Online', statusColor: 'green' },
            ],
          },
        };
        break;

      case 'pricing_table':
        newBlock = {
          id,
          type: 'pricing_table',
          title: 'Transparent Scalable Plans',
          subtitle: 'Simple pricing tailored to high-growth teams',
          props: {
            tiers: [
              {
                name: 'Pro Starter',
                price: '$49',
                period: '/month',
                description: 'Ideal for independent builders and small studios.',
                features: ['Unlimited prototypes', 'Gemini AI assistant', 'Export React & HTML', 'Community support'],
                ctaLabel: 'Choose Starter',
                popular: false,
              },
              {
                name: 'Enterprise Ultra',
                price: '$199',
                period: '/month',
                description: 'Dedicated cloud sandbox, custom domain & SOC2 audit logs.',
                features: ['All Pro features', 'Real-time collaborative canvas', 'Custom fine-tuned AI models', 'Dedicated SLA'],
                ctaLabel: 'Start 14-Day Free Trial',
                popular: true,
              },
            ],
          },
        };
        break;

      case 'form_card':
        newBlock = {
          id,
          type: 'form_card',
          title: 'Quick Onboarding & Setup',
          subtitle: 'Configure your credentials and workspace settings',
          props: {
            fields: [
              { id: 'workspace-name', label: 'Workspace Name', type: 'text', placeholder: 'e.g., Acme Innovations' },
              { id: 'plan-type', label: 'Select Tier', type: 'select', options: ['Starter Cloud', 'Growth Pro', 'Dedicated Enterprise'] },
              { id: 'opt-in', label: 'Enable AI Agent Autopilot', type: 'switch', defaultChecked: true },
            ],
            submitLabel: 'Save & Continue',
          },
        };
        break;

      default:
        newBlock = {
          id,
          type: 'hero',
          title: 'Modern Product Feature',
          subtitle: 'Engage users with clear value propositions and delightful micro-interactions.',
          props: {
            badge: 'New Component',
            primaryCta: 'Action Button',
            secondaryCta: 'Secondary Link',
          },
        };
    }

    onInsertBlock(newBlock);
  };

  const themeColors = [
    { name: 'Indigo Aura', primary: '#6366f1', accent: '#10b981' },
    { name: 'Emerald Mint', primary: '#10b981', accent: '#6366f1' },
    { name: 'Violet Cyber', primary: '#8b5cf6', accent: '#ec4899' },
    { name: 'Cyan Neon', primary: '#06b6d4', accent: '#3b82f6' },
    { name: 'Amber Solar', primary: '#f59e0b', accent: '#ef4444' },
    { name: 'Rose Crimson', primary: '#f43f5e', accent: '#8b5cf6' },
    { name: 'Titanium Slate', primary: '#475569', accent: '#38bdf8' },
  ];

  return (
    <aside className="w-80 border-r border-slate-800/80 bg-slate-950/95 flex flex-col shrink-0 select-none z-20">
      {/* Tab Switcher */}
      <div className="p-3 border-b border-slate-800/80">
        <div className="grid grid-cols-3 gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800/80">
          <button
            onClick={() => setActiveTab('screens')}
            className={`py-1.5 px-2 rounded-lg text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all ${
              activeTab === 'screens' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Screens</span>
          </button>

          <button
            onClick={() => setActiveTab('components')}
            className={`py-1.5 px-2 rounded-lg text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all ${
              activeTab === 'components' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Component className="w-3.5 h-3.5" />
            <span>Library</span>
          </button>

          <button
            onClick={() => setActiveTab('theme')}
            className={`py-1.5 px-2 rounded-lg text-xs font-semibold flex items-center justify-center space-x-1.5 transition-all ${
              activeTab === 'theme' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>Tokens</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Screens List */}
      {activeTab === 'screens' && (
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Prototype Flow ({project.screens.length})
            </span>
            <div className="flex items-center space-x-1">
              <button
                onClick={handleCreateBlankScreen}
                className="p-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition-colors"
                title="Add Blank Screen"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => onOpenAIModal('add-screen')}
                className="px-2 py-1 rounded-lg bg-indigo-600/20 border border-indigo-500/30 text-indigo-300 text-[11px] font-semibold flex items-center space-x-1 hover:bg-indigo-600/30 transition-colors"
                title="Generate Connected Flow Screen with Gemini AI"
              >
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>+ AI Screen</span>
              </button>
            </div>
          </div>

          {/* Screens Cards List */}
          <div className="space-y-2">
            {project.screens.map((screen, idx) => {
              const isActive = screen.id === activeScreenId;
              return (
                <div
                  key={screen.id}
                  onClick={() => onSelectScreen(screen.id)}
                  className={`group p-3 rounded-2xl border transition-all cursor-pointer ${
                    isActive
                      ? 'bg-slate-900 border-indigo-500/80 shadow-lg shadow-indigo-950/50'
                      : 'bg-slate-900/40 border-slate-800/80 hover:bg-slate-900/70 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center space-x-2">
                      <span className="w-5 h-5 rounded-full bg-slate-800 text-[10px] font-mono font-bold flex items-center justify-center text-slate-400">
                        {idx + 1}
                      </span>
                      <span className="font-semibold text-xs text-white truncate max-w-[140px]">
                        {screen.name}
                      </span>
                    </div>

                    {screen.badge && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 font-medium border border-indigo-500/20">
                        {screen.badge}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                    <span>{screen.blocks.length} UI blocks</span>

                    {/* Quick Actions */}
                    <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDuplicateScreen(screen.id);
                        }}
                        className="p-1 text-slate-400 hover:text-white hover:bg-slate-800 rounded"
                        title="Duplicate Screen"
                      >
                        <Copy className="w-3 h-3" />
                      </button>

                      {project.screens.length > 1 && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteScreen(screen.id);
                          }}
                          className="p-1 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded"
                          title="Delete Screen"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* AI Screen Refiner Prompt Banner */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-br from-indigo-950/40 via-purple-950/20 to-slate-900 border border-indigo-500/20 space-y-2">
            <div className="flex items-center space-x-2 text-indigo-300 text-xs font-bold">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>AI Flow Optimization</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Generate linked checkout modals, customer detail drawers, or A/B variants in seconds.
            </p>
            <button
              onClick={() => onOpenAIModal('refine')}
              className="w-full py-1.5 px-3 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/40 border border-indigo-500/40 text-indigo-200 text-xs font-semibold transition-all flex items-center justify-center space-x-1.5"
            >
              <span>Refine Active Screen</span>
              <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      )}

      {/* Tab 2: Component Library */}
      {activeTab === 'components' && (
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
            Click to Append to Screen
          </div>

          <div className="grid grid-cols-1 gap-2">
            {[
              { type: 'ai_prompt_box' as BlockType, label: 'Gemini Copilot Box', icon: Bot, desc: 'Interactive AI prompt input & quick chips' },
              { type: 'stats_grid' as BlockType, label: 'Metric Stats Grid', icon: BarChart, desc: '4-column KPI cards with trend pills' },
              { type: 'chart' as BlockType, label: 'Interactive Chart', icon: BarChart, desc: 'Area/Bar metric visualizer with timeframe tabs' },
              { type: 'data_table' as BlockType, label: 'Data Directory Table', icon: Table, desc: 'Searchable rows with status badges' },
              { type: 'pricing_table' as BlockType, label: 'Pricing Matrix', icon: CreditCard, desc: 'Multi-tier pricing cards with annual toggle' },
              { type: 'form_card' as BlockType, label: 'Interactive Form', icon: Sliders, desc: 'Inputs, dropdowns, switches & submit action' },
              { type: 'hero' as BlockType, label: 'Hero Banner Section', icon: Layout, desc: 'Headline, badge, CTA buttons & subtext' },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.type}
                  onClick={() => handleQuickAddBlock(item.type)}
                  className="w-full text-left p-3 rounded-2xl bg-slate-900/60 border border-slate-800/80 hover:border-indigo-500/60 hover:bg-slate-900 transition-all flex items-start space-x-3 group"
                >
                  <div className="w-8 h-8 rounded-xl bg-slate-800 group-hover:bg-indigo-600/20 group-hover:text-indigo-400 text-slate-400 flex items-center justify-center shrink-0 transition-colors">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white group-hover:text-indigo-300 transition-colors">
                      {item.label}
                    </div>
                    <div className="text-[11px] text-slate-400 line-clamp-1">
                      {item.desc}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 3: Design Tokens & Theme */}
      {activeTab === 'theme' && (
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          {/* Color Palettes */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Primary Brand Accent
            </span>
            <div className="grid grid-cols-1 gap-2">
              {themeColors.map((clr) => {
                const isSelected = project.theme.primaryColor === clr.primary;
                return (
                  <button
                    key={clr.name}
                    onClick={() => onUpdateTheme({ primaryColor: clr.primary, accentColor: clr.accent })}
                    className={`w-full p-2.5 rounded-xl border flex items-center justify-between transition-all ${
                      isSelected
                        ? 'bg-slate-900 border-indigo-500/80'
                        : 'bg-slate-900/40 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <div
                        className="w-5 h-5 rounded-lg shadow-sm"
                        style={{ backgroundColor: clr.primary }}
                      />
                      <span className="text-xs font-medium text-slate-200">{clr.name}</span>
                    </div>
                    {isSelected && <Check className="w-3.5 h-3.5 text-indigo-400" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Background Canvas Style */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Background Canvas Style
            </span>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'dark', label: 'Dark Titanium' },
                { id: 'slate', label: 'Deep Slate' },
                { id: 'navy', label: 'Midnight Navy' },
                { id: 'light', label: 'Clean Light' },
              ].map((style) => (
                <button
                  key={style.id}
                  onClick={() => onUpdateTheme({ bgStyle: style.id as any })}
                  className={`py-2 px-3 rounded-xl border text-xs font-medium transition-all text-center ${
                    project.theme.bgStyle === style.id
                      ? 'bg-indigo-600 text-white border-indigo-500'
                      : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  {style.label}
                </button>
              ))}
            </div>
          </div>

          {/* Border Radius */}
          <div className="space-y-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Border Radius Geometry
            </span>
            <div className="grid grid-cols-3 gap-1.5 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
              {[
                { id: 'rounded-md', label: 'Sharp' },
                { id: 'rounded-xl', label: 'Smooth' },
                { id: 'rounded-2xl', label: 'Pill' },
              ].map((r) => (
                <button
                  key={r.id}
                  onClick={() => onUpdateTheme({ borderRadius: r.id as any })}
                  className={`py-1.5 text-xs font-medium rounded-lg transition-all ${
                    project.theme.borderRadius === r.id
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </aside>
  );
};
