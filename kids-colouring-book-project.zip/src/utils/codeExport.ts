import { PrototypeProject, Screen, ComponentBlock } from '../types/prototype';

export function generateReactCode(project: PrototypeProject, activeScreen: Screen): string {
  return `/**
 * @name ${project.title} - ${activeScreen.name}
 * Generated with ProtoCraft AI Interactive Prototype Studio
 */

import React, { useState } from 'react';
import { 
  Sparkles, Zap, Activity, Shield, Bot, Users, TrendingUp, 
  Download, Plus, Search, ChevronRight, ArrowUpRight, CheckCircle2,
  AlertCircle, Settings, Bell, HelpCircle, BarChart3
} from 'lucide-react';

export default function ${sanitizeComponentName(activeScreen.name)}() {
  const [activeTab, setActiveTab] = useState('overview');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased flex flex-col selection:bg-indigo-500 selection:text-white">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 right-5 z-50 bg-indigo-600 text-white px-5 py-3 rounded-xl shadow-2xl flex items-center space-x-3 border border-indigo-400/30 animate-bounce">
          <Sparkles className="w-5 h-5 text-indigo-200" />
          <span className="font-medium text-sm">{toastMessage}</span>
        </div>
      )}

      ${activeScreen.navBar ? `
      {/* Navigation Header */}
      <header className="border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md sticky top-0 z-40 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-8">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-emerald-400 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <span className="font-bold text-lg tracking-tight bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">
              ${activeScreen.navBar.brandName || project.title}
            </span>
          </div>

          <nav className="hidden md:flex items-center space-x-1">
            ${activeScreen.navBar.links?.map(l => `
            <button 
              key="${l.id}"
              onClick={() => triggerToast('Navigating to ${l.label}...')}
              className="px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${l.active ? 'bg-slate-800 text-white font-semibold' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'}"
            >
              ${l.label}
            </button>`).join('') || ''}
          </nav>
        </div>

        <div className="flex items-center space-x-3">
          ${activeScreen.navBar.rightActions?.map(ra => `
          <button 
            key="${ra.id}"
            onClick={() => setIsModalOpen(true)}
            className="px-4 py-2 rounded-xl text-sm font-semibold transition-all ${ra.variant === 'primary' ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30' : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'}"
          >
            ${ra.label}
          </button>`).join('') || ''}
        </div>
      </header>` : ''}

      {/* Main Content Layout */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        ${activeScreen.sideBar ? `
        {/* Sidebar */}
        <aside className="w-64 border-r border-slate-800/80 bg-slate-900/30 p-4 space-y-6 hidden md:block">
          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-3">
            ${activeScreen.sideBar.header || 'Menu'}
          </div>
          <nav className="space-y-1">
            ${activeScreen.sideBar.items?.map(it => `
            <button
              key="${it.id}"
              onClick={() => triggerToast('Selected: ${it.label}')}
              className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${it.active ? 'bg-indigo-600/15 text-indigo-400 border border-indigo-500/20' : 'text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'}"
            >
              <span className="flex items-center space-x-3">
                <Activity className="w-4 h-4" />
                <span>${it.label}</span>
              </span>
              ${it.badge ? `<span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono">${it.badge}</span>` : ''}
            </button>`).join('') || ''}
          </nav>
        </aside>` : ''}

        {/* Content Container */}
        <main className="flex-1 p-6 md:p-8 overflow-y-auto space-y-8 max-w-7xl mx-auto w-full">
          ${activeScreen.blocks.map(block => renderBlockSnippet(block)).join('\n\n          ')}
        </main>
      </div>

      {/* Interactive Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-lg w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-white">Action Flow Dialog</h3>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white text-sm px-2 py-1 rounded-lg hover:bg-slate-800"
              >
                ✕
              </button>
            </div>
            <p className="text-sm text-slate-400">This flow was designed in ProtoCraft. Hook your API endpoints to make this fully transactional!</p>
            <div className="pt-4 flex justify-end space-x-3">
              <button 
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-sm font-medium hover:bg-slate-700"
              >
                Cancel
              </button>
              <button 
                onClick={() => { setIsModalOpen(false); triggerToast('Flow confirmed successfully!'); }}
                className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-sm font-medium hover:bg-indigo-500 shadow-lg shadow-indigo-600/30"
              >
                Confirm & Proceed
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
`;
}

function renderBlockSnippet(block: ComponentBlock): string {
  switch (block.type) {
    case 'hero':
      return `{/* Hero Section */}
          <section className="bg-gradient-to-b from-indigo-950/40 via-slate-900/50 to-slate-900/20 border border-indigo-500/20 rounded-3xl p-8 md:p-12 space-y-6 relative overflow-hidden">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>${block.props?.badge || 'Feature Preview'}</span>
            </div>
            <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight text-white max-w-3xl leading-tight">
              ${block.title || 'Next-Generation Intelligent Platform'}
            </h1>
            <p className="text-slate-400 text-base md:text-lg max-w-2xl">
              ${block.subtitle || 'Built with AI-driven components and modern reactive architecture.'}
            </p>
            <div className="flex flex-wrap gap-4 pt-2">
              <button 
                onClick={() => setIsModalOpen(true)}
                className="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-sm shadow-xl shadow-indigo-600/30 transition-all"
              >
                ${block.props?.primaryCta || 'Get Started Now'}
              </button>
              <button 
                onClick={() => triggerToast('Action triggered')}
                className="px-6 py-3 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-200 font-semibold text-sm border border-slate-700/80 transition-all"
              >
                ${block.props?.secondaryCta || 'Learn More'}
              </button>
            </div>
          </section>`;

    case 'stats_grid':
      return `{/* Stats Grid */}
          <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            ${block.props?.items?.map((item: any) => `
            <div key="${item.id}" className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800/80 hover:border-slate-700 transition-all space-y-2">
              <div className="text-xs font-medium text-slate-400">${item.label}</div>
              <div className="flex items-baseline justify-between">
                <div className="text-2xl font-bold text-white tracking-tight">${item.value}</div>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full ${item.trend === 'up' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'}">
                  ${item.change}
                </span>
              </div>
              <div className="text-xs text-slate-400 pt-1">${item.subtext || ''}</div>
            </div>`).join('') || ''}
          </section>`;

    case 'chart':
      return `{/* Analytics Chart Card */}
          <section className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-bold text-white">${block.title || 'Performance Metrics'}</h3>
                <p className="text-sm text-slate-400">${block.subtitle || 'Real-time telemetry'}</p>
              </div>
              <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
                {['7D', '30D', '90D', '1Y'].map(t => (
                  <button 
                    key={t}
                    onClick={() => triggerToast('Selected timeframe: ' + t)}
                    className="px-3 py-1 text-xs font-medium rounded-lg text-slate-400 hover:text-white transition-colors"
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
            
            {/* Visual Bar Graph Simulation */}
            <div className="h-64 flex items-end justify-between gap-3 pt-6 border-b border-slate-800 pb-2">
              ${block.props?.dataPoints?.map((dp: any, idx: number) => `
              <div key="${idx}" className="flex-1 flex flex-col items-center gap-2 group">
                <div className="w-full bg-indigo-500/20 group-hover:bg-indigo-500/30 rounded-t-lg transition-all relative overflow-hidden" style={{ height: '${Math.min(100, Math.max(20, (dp.value / 150000) * 100))}%' }}>
                  <div className="absolute inset-0 bg-gradient-to-t from-indigo-600 to-emerald-400 opacity-75" />
                </div>
                <span className="text-[10px] font-medium text-slate-400 truncate">${dp.label}</span>
              </div>`).join('') || ''}
            </div>
          </section>`;

    case 'data_table':
      return `{/* Data Table */}
          <section className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-lg font-bold text-white">${block.title || 'Directory'}</h3>
                <p className="text-sm text-slate-400">${block.subtitle || 'Live records'}</p>
              </div>
              <input 
                type="text"
                placeholder="Search..."
                className="px-4 py-2 rounded-xl bg-slate-950 border border-slate-800 text-sm text-white focus:outline-none focus:border-indigo-500 max-w-xs"
              />
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 text-xs uppercase">
                    ${block.props?.headers?.map((h: string) => `<th className="pb-3 px-3">${h}</th>`).join('') || ''}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  ${block.props?.rows?.map((r: any) => `
                  <tr key="${r.id}" className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-3 px-3 font-semibold text-white">${r.name}</td>
                    <td className="py-3 px-3 text-slate-400">${r.tier || r.sub || '-'}</td>
                    <td className="py-3 px-3 font-mono text-emerald-400">${r.mrr || r.health || '-'}</td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        ${r.status || 'Active'}
                      </span>
                    </td>
                  </tr>`).join('') || ''}
                </tbody>
              </table>
            </div>
          </section>`;

    default:
      return `{/* Content Block: ${block.title || block.type} */}
          <section className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800/80 space-y-3">
            <h3 className="text-lg font-bold text-white">${block.title || 'Feature Block'}</h3>
            <p className="text-sm text-slate-400">${block.subtitle || ''}</p>
          </section>`;
  }
}

function sanitizeComponentName(name: string): string {
  return name.replace(/[^a-zA-Z0-9]/g, '') || 'PrototypeScreen';
}

export function generateHTMLCode(project: PrototypeProject, activeScreen: Screen): string {
  return `<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${project.title} - ${activeScreen.name}</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Inter', sans-serif; }
  </style>
</head>
<body class="bg-slate-950 text-slate-100 min-h-screen antialiased flex flex-col">
  <!-- Top Navigation -->
  <header class="border-b border-slate-800 bg-slate-900/80 backdrop-blur-md sticky top-0 z-40 px-6 py-4 flex items-center justify-between">
    <div class="flex items-center space-x-3">
      <div class="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center font-bold text-white">P</div>
      <span class="font-bold text-lg text-white">${project.title}</span>
    </div>
    <div class="flex items-center space-x-3">
      <button onclick="alert('Action completed!')" class="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold">
        Launch Flow
      </button>
    </div>
  </header>

  <!-- Main Container -->
  <main class="p-8 max-w-7xl mx-auto w-full space-y-8">
    <div class="p-8 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
      <span class="text-xs uppercase font-bold text-indigo-400 tracking-wider">Screen Preview</span>
      <h1 class="text-3xl font-extrabold text-white">${activeScreen.name}</h1>
      <p class="text-slate-400 max-w-2xl">${project.description}</p>
    </div>
  </main>
</body>
</html>`;
}
