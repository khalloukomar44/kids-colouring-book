package com.kids.colouringbook.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kids.colouringbook.data.AnimalData
import com.kids.colouringbook.drawing.DrawingEngine
import com.kids.colouringbook.model.AnimalPage
import com.kids.colouringbook.model.BrushSize
import com.kids.colouringbook.model.StickerType
import com.kids.colouringbook.model.ToolMode
import com.kids.colouringbook.sound.SoundEffects
import com.kids.colouringbook.sound.SpeechHelper
import com.kids.colouringbook.storage.GalleryStorage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ColouringViewModel(application: Application) : AndroidViewModel(application) {

    val drawingEngine = DrawingEngine()
    private val speechHelper = SpeechHelper(application)

    private val _currentAnimalIndex = MutableStateFlow(0)
    val currentAnimalIndex: StateFlow<Int> = _currentAnimalIndex.asStateFlow()

    private val _currentTool = MutableStateFlow(ToolMode.BRUSH)
    val currentTool: StateFlow<ToolMode> = _currentTool.asStateFlow()

    private val _selectedColorHex = MutableStateFlow(AnimalData.COLORS[0].colorHex)
    val selectedColorHex: StateFlow<Long> = _selectedColorHex.asStateFlow()

    private val _brushSize = MutableStateFlow(BrushSize.MEDIUM)
    val brushSize: StateFlow<BrushSize> = _brushSize.asStateFlow()

    private val _selectedSticker = MutableStateFlow(StickerType.STAR)
    val selectedSticker: StateFlow<StickerType> = _selectedSticker.asStateFlow()

    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()

    private val _canRedo = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()

    private val _isSaved = MutableStateFlow(false)
    val isSaved: StateFlow<Boolean> = _isSaved.asStateFlow()

    private val _showSaveDialog = MutableStateFlow(false)
    val showSaveDialog: StateFlow<Boolean> = _showSaveDialog.asStateFlow()

    private val _showClearDialog = MutableStateFlow(false)
    val showClearDialog: StateFlow<Boolean> = _showClearDialog.asStateFlow()

    private val _soundEnabled = MutableStateFlow(true)
    val soundEnabled: StateFlow<Boolean> = _soundEnabled.asStateFlow()

    private val _savedArtworkBitmap = MutableStateFlow<Bitmap?>(null)
    val savedArtworkBitmap: StateFlow<Bitmap?> = _savedArtworkBitmap.asStateFlow()

    val currentAnimal: AnimalPage
        get() = AnimalData.ANIMAL_PAGES[_currentAnimalIndex.value]

    fun selectAnimal(animalId: String) {
        val index = AnimalData.ANIMAL_PAGES.indexOfFirst { it.id == animalId }
        if (index != -1) {
            _currentAnimalIndex.value = index
            resetDrawingState()
            SoundEffects.playPageTurn()
        }
    }

    fun nextAnimal() {
        val nextIdx = (_currentAnimalIndex.value + 1) % AnimalData.ANIMAL_PAGES.size
        _currentAnimalIndex.value = nextIdx
        resetDrawingState()
        SoundEffects.playPageTurn()
    }

    fun prevAnimal() {
        val prevIdx = if (_currentAnimalIndex.value > 0) _currentAnimalIndex.value - 1 else AnimalData.ANIMAL_PAGES.size - 1
        _currentAnimalIndex.value = prevIdx
        resetDrawingState()
        SoundEffects.playPageTurn()
    }

    fun setTool(tool: ToolMode) {
        _currentTool.value = tool
        if (tool == ToolMode.ERASER) {
            SoundEffects.playEraser()
        } else if (tool == ToolMode.RAINBOW || tool == ToolMode.SPARKLE) {
            SoundEffects.playMagic()
        } else {
            SoundEffects.playPop()
        }
    }

    fun setColor(colorHex: Long) {
        _selectedColorHex.value = colorHex
        if (_currentTool.value == ToolMode.ERASER) {
            _currentTool.value = ToolMode.BRUSH
        }
        SoundEffects.playPop(580f)
    }

    fun setBrushSize(size: BrushSize) {
        _brushSize.value = size
        SoundEffects.playPop(480f)
    }

    fun setSticker(sticker: StickerType) {
        _selectedSticker.value = sticker
        SoundEffects.playPop(620f)
    }

    fun onDrawingAction() {
        _canUndo.value = drawingEngine.canUndo()
        _canRedo.value = drawingEngine.canRedo()
        _isSaved.value = false
    }

    fun undo() {
        drawingEngine.undo()
        _canUndo.value = drawingEngine.canUndo()
        _canRedo.value = drawingEngine.canRedo()
        SoundEffects.playPop(440f)
    }

    fun redo() {
        drawingEngine.redo()
        _canUndo.value = drawingEngine.canUndo()
        _canRedo.value = drawingEngine.canRedo()
        SoundEffects.playPop(540f)
    }

    fun showClearConfirm() {
        _showClearDialog.value = true
    }

    fun hideClearConfirm() {
        _showClearDialog.value = false
    }

    fun clearDrawing() {
        drawingEngine.clearCanvas()
        _canUndo.value = drawingEngine.canUndo()
        _canRedo.value = drawingEngine.canRedo()
        _showClearDialog.value = false
        SoundEffects.playClear()
    }

    fun saveArtwork() {
        val mergedBitmap = drawingEngine.getMergedArtworkBitmap()
        _savedArtworkBitmap.value = mergedBitmap

        viewModelScope.launch {
            GalleryStorage.saveArtwork(getApplication(), currentAnimal, mergedBitmap)
            _isSaved.value = true
            _showSaveDialog.value = true
            SoundEffects.playSuccess()
        }
    }

    fun dismissSaveDialog() {
        _showSaveDialog.value = false
    }

    fun exportToPictures() {
        _savedArtworkBitmap.value?.let { bitmap ->
            GalleryStorage.exportToPictures(getApplication(), bitmap, currentAnimal.name)
            SoundEffects.playPop(700f)
        }
    }

    fun shareCurrentArtwork() {
        _savedArtworkBitmap.value?.let { bitmap ->
            val artwork = GalleryStorage.saveArtwork(getApplication(), currentAnimal, bitmap)
            GalleryStorage.shareArtwork(getApplication(), artwork)
        }
    }

    fun toggleSound() {
        _soundEnabled.value = !_soundEnabled.value
        SoundEffects.isEnabled = _soundEnabled.value
    }

    fun speakAnimalFact() {
        speechHelper.speak("${currentAnimal.name}! ${currentAnimal.funFact}")
    }

    private fun resetDrawingState() {
        _isSaved.value = false
        _canUndo.value = false
        _canRedo.value = false
        _currentTool.value = ToolMode.BRUSH
    }

    override fun onCleared() {
        super.onCleared()
        speechHelper.shutdown()
    }
}
