import React from 'react';
import { 
  Sparkles, Monitor, Smartphone, Tablet, Watch, 
  Layers, Play, Code2, ShieldAlert, Cpu, Share2, 
  RotateCcw, SlidersHorizontal, Plus, ChevronDown, 
  ExternalLink, Eye, FlaskConical, Download
} from 'lucide-react';
import { PrototypeProject, DeviceType, ViewMode } from '../types/prototype';
import { SAMPLE_PROTOTYPES } from '../data/samplePrototypes';

interface HeaderProps {
  currentProject: PrototypeProject;
  onSelectProject: (proj: PrototypeProject) => void;
  viewMode: ViewMode;
  onSelectViewMode: (mode: ViewMode) => void;
  device: DeviceType;
  onChangeDevice: (dev: DeviceType) => void;
  onOpenAIModal: (tab?: 'generate' | 'refine' | 'add-screen' | 'audit' | 'ab-test') => void;
  onOpenCodeExport: () => void;
  onOpenUserTest: () => void;
  onResetProject: () => void;
  onNewBlankProject: () => void;
  onShare: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentProject,
  onSelectProject,
  viewMode,
  onSelectViewMode,
  device,
  onChangeDevice,
  onOpenAIModal,
  onOpenCodeExport,
  onOpenUserTest,
  onResetProject,
  onNewBlankProject,
  onShare,
}) => {
  return (
    <header className="h-16 border-b border-slate-800/90 bg-slate-950/95 backdrop-blur-md px-4 flex items-center justify-between select-none z-30 sticky top-0">
      {/* Left: Brand + Project Switcher */}
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 via-purple-500 to-emerald-400 p-0.5 shadow-lg shadow-indigo-500/25">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center text-white">
              <Cpu className="w-4 h-4 text-indigo-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <span className="font-extrabold text-sm tracking-tight text-white">ProtoCraft</span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                AI STUDIO
              </span>
            </div>
          </div>
        </div>

        <div className="h-6 w-px bg-slate-800" />

        {/* Project Selector Dropdown */}
        <div className="relative group">
          <div className="flex items-center space-x-2 px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 cursor-pointer text-xs font-medium text-slate-200 transition-all max-w-[220px]">
            <span className="truncate font-semibold">{currentProject.title}</span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          </div>

          <div className="absolute top-full left-0 mt-1.5 w-72 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-2 hidden group-hover:block z-50 animate-in fade-in zoom-in-95 duration-150">
            <div className="text-[11px] font-bold text-slate-400 px-3 py-1.5 uppercase tracking-wider">
              Templates & Projects
            </div>
            <div className="space-y-1">
              {SAMPLE_PROTOTYPES.map((p) => (
                <button
                  key={p.id}
                  onClick={() => onSelectProject(p)}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center justify-between transition-colors ${
                    p.id === currentProject.id
                      ? 'bg-indigo-600/20 text-indigo-300 font-semibold border border-indigo-500/30'
                      : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <span className="truncate">{p.title}</span>
                  <span className="text-[10px] text-slate-400 uppercase font-mono px-1.5 py-0.5 rounded bg-slate-800">
                    {p.category}
                  </span>
                </button>
              ))}
            </div>
            <div className="border-t border-slate-800 mt-2 pt-2 flex items-center space-x-1">
              <button
                onClick={onNewBlankProject}
                className="w-full text-left px-3 py-1.5 rounded-xl text-xs text-indigo-400 hover:bg-indigo-950/40 font-medium flex items-center space-x-2"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Create New Prototype</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Center: View Modes & Device Selectors */}
      <div className="flex items-center space-x-3">
        {/* Device Switcher */}
        <div className="hidden lg:flex items-center bg-slate-900/90 border border-slate-800/80 p-1 rounded-xl space-x-0.5">
          <button
            onClick={() => onChangeDevice('desktop')}
            className={`p-1.5 rounded-lg transition-all ${
              device === 'desktop' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Desktop 1440px Viewport"
          >
            <Monitor className="w-4 h-4" />
          </button>
          <button
            onClick={() => onChangeDevice('tablet')}
            className={`p-1.5 rounded-lg transition-all ${
              device === 'tablet' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Tablet 768px Viewport"
          >
            <Tablet className="w-4 h-4" />
          </button>
          <button
            onClick={() => onChangeDevice('mobile')}
            className={`p-1.5 rounded-lg transition-all ${
              device === 'mobile' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Mobile iPhone 393px Viewport"
          >
            <Smartphone className="w-4 h-4" />
          </button>
        </div>

        {/* View Mode Navigation Tabs */}
        <div className="flex items-center bg-slate-900/90 border border-slate-800/80 p-1 rounded-xl space-x-1">
          <button
            onClick={() => onSelectViewMode('interactive')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
              viewMode === 'interactive'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Interactive</span>
          </button>

          <button
            onClick={() => onSelectViewMode('flow-map')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
              viewMode === 'flow-map'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Flow Map</span>
          </button>

          <button
            onClick={() => onSelectViewMode('inspector')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
              viewMode === 'inspector'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Inspector</span>
          </button>

          <button
            onClick={() => onSelectViewMode('usability-audit')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-all ${
              viewMode === 'usability-audit'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>UX Audit & Heatmap</span>
          </button>
        </div>
      </div>

      {/* Right: AI Tools & Export & Presentation */}
      <div className="flex items-center space-x-2.5">
        {/* Run User Test Mission */}
        <button
          onClick={onOpenUserTest}
          className="hidden xl:flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white text-xs font-medium transition-all"
        >
          <FlaskConical className="w-3.5 h-3.5 text-amber-400" />
          <span>Simulate Test</span>
        </button>

        {/* AI Co-Pilot Button */}
        <button
          onClick={() => onOpenAIModal('generate')}
          className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-600 bg-size-200 hover:bg-right text-white text-xs font-bold shadow-lg shadow-indigo-600/30 transition-all duration-300 hover:scale-[1.02]"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin-slow" />
          <span>AI Co-Pilot</span>
        </button>

        {/* Code Export */}
        <button
          onClick={onOpenCodeExport}
          className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white transition-all"
          title="Export React / HTML / JSON Code"
        >
          <Code2 className="w-4 h-4 text-slate-300" />
        </button>

        {/* Present Fullscreen */}
        <button
          onClick={() => onSelectViewMode('presentation')}
          className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white transition-all"
          title="Present Fullscreen"
        >
          <Eye className="w-4 h-4 text-slate-300" />
        </button>

        {/* Share Button */}
        <button
          onClick={onShare}
          className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white transition-all"
          title="Share Live Prototype Link"
        >
          <Share2 className="w-4 h-4 text-slate-300" />
        </button>
      </div>
    </header>
  );
};
