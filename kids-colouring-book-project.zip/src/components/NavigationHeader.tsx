import React, { useState } from 'react';
import { AnimalPage } from '../types/colouring';
import { sounds } from '../utils/soundEffects';
import { Home, ChevronLeft, ChevronRight, Volume2, VolumeX, Download, Volume1 } from 'lucide-react';

interface NavigationHeaderProps {
  currentAnimal: AnimalPage;
  currentIndex: number;
  totalCount: number;
  onPrev: () => void;
  onNext: () => void;
  onGoHome: () => void;
  onSaveClick: () => void;
}

export const NavigationHeader: React.FC<NavigationHeaderProps> = ({
  currentAnimal,
  currentIndex,
  totalCount,
  onPrev,
  onNext,
  onGoHome,
  onSaveClick,
}) => {
  const [soundEnabled, setSoundEnabled] = useState(sounds.enabled);

  const toggleSound = () => {
    sounds.enabled = !soundEnabled;
    setSoundEnabled(!soundEnabled);
    if (!soundEnabled) {
      sounds.playPop(520);
    }
  };

  const handleSpeak = () => {
    sounds.speak(`${currentAnimal.name}! ${currentAnimal.funFact}`);
  };

  return (
    <header className="w-full bg-white/90 backdrop-blur-md rounded-3xl p-2.5 sm:p-3 shadow-lg border-4 border-amber-200 ring-2 ring-amber-100 flex items-center justify-between gap-2">
      {/* Home & Sound Buttons */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        <button
          onClick={() => {
            sounds.playPop(420);
            onGoHome();
          }}
          className="p-2.5 sm:p-3 rounded-2xl bg-amber-400 text-amber-950 hover:bg-amber-500 btn-3d transition-all flex items-center justify-center"
          title="Back to All Animals"
        >
          <Home className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2.5]" />
        </button>

        <button
          onClick={toggleSound}
          className={`p-2.5 sm:p-3 rounded-2xl btn-3d transition-all ${
            soundEnabled
              ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200'
              : 'bg-slate-100 text-slate-400 hover:bg-slate-200'
          }`}
          title={soundEnabled ? 'Mute sounds' : 'Enable sounds'}
        >
          {soundEnabled ? (
            <Volume2 className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2.5]" />
          ) : (
            <VolumeX className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2.5]" />
          )}
        </button>
      </div>

      {/* Center Animal Name & Voice Reader */}
      <div className="flex items-center gap-2">
        {/* Previous Button */}
        <button
          onClick={() => {
            sounds.playPageTurn();
            onPrev();
          }}
          className="p-2 sm:p-2.5 rounded-2xl bg-amber-200 text-amber-900 hover:bg-amber-300 btn-3d transition-all flex items-center justify-center"
          title="Previous Animal Page"
        >
          <ChevronLeft className="w-6 h-6 sm:w-7 sm:h-7 stroke-[3]" />
        </button>

        {/* Animal Badge */}
        <button
          onClick={handleSpeak}
          className="flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-1.5 sm:py-2 rounded-2xl bg-gradient-to-r from-amber-100 to-amber-200 border-2 border-amber-300 text-amber-950 font-black btn-3d hover:scale-105 transition-all text-left"
          title="Click to hear fun animal facts!"
        >
          <span className="text-2xl sm:text-3xl animate-bounce-subtle">{currentAnimal.emoji}</span>
          <div className="flex flex-col">
            <span className="text-xs font-bold text-amber-700 uppercase tracking-wider leading-none">
              {currentIndex + 1} of {totalCount}
            </span>
            <span className="text-sm sm:text-base font-black truncate max-w-[110px] sm:max-w-[160px]">
              {currentAnimal.name}
            </span>
          </div>
          <Volume1 className="w-4 h-4 text-amber-600 ml-0.5 animate-pulse" />
        </button>

        {/* Next Button */}
        <button
          onClick={() => {
            sounds.playPageTurn();
            onNext();
          }}
          className="p-2 sm:p-2.5 rounded-2xl bg-amber-400 text-amber-950 hover:bg-amber-500 btn-3d transition-all flex items-center justify-center shadow-md animate-pulse-glow"
          title="Next Animal Page"
        >
          <ChevronRight className="w-6 h-6 sm:w-7 sm:h-7 stroke-[3]" />
        </button>
      </div>

      {/* Save Button */}
      <button
        onClick={() => {
          sounds.playSuccess();
          onSaveClick();
        }}
        className="flex items-center gap-1.5 px-3 sm:px-4 py-2.5 sm:py-3 rounded-2xl bg-emerald-500 text-white font-black text-sm sm:text-base btn-3d hover:bg-emerald-600 transition-all shadow-lg ring-2 ring-emerald-300 shrink-0"
        title="Save your artwork"
      >
        <Download className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2.5]" />
        <span className="hidden xs:inline">Save</span>
      </button>
    </header>
  );
};
