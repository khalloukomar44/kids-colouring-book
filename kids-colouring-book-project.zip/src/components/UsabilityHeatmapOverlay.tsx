import React, { useState } from 'react';
import { 
  ShieldAlert, Sparkles, CheckCircle2, AlertTriangle, 
  Lightbulb, Star, Flame, Eye, ChevronRight, RefreshCw, BarChart2
} from 'lucide-react';
import { PrototypeProject, PersonaAuditResult } from '../types/prototype';
import { runPersonaAuditWithAI } from '../services/prototypeApi';

interface UsabilityHeatmapOverlayProps {
  project: PrototypeProject;
  onUpdateAudits: (audits: PersonaAuditResult[]) => void;
}

export const UsabilityHeatmapOverlay: React.FC<UsabilityHeatmapOverlayProps> = ({
  project,
  onUpdateAudits,
}) => {
  const [selectedPersonaIdx, setSelectedPersonaIdx] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(false);
  const [showThermalHeatmap, setShowThermalHeatmap] = useState(true);

  const audits = project.personaAudits || [];
  const activePersona = audits[selectedPersonaIdx];

  const handleRunAudit = async () => {
    setIsLoading(true);
    try {
      const results = await runPersonaAuditWithAI(project);
      onUpdateAudits(results);
    } catch (err: any) {
      alert(err.message || 'Failed to run usability audit');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex-1 bg-[#060911] overflow-auto p-6 md:p-8 select-none relative">
      {/* Blueprint background */}
      <div 
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, #10b981 1px, transparent 0)`,
          backgroundSize: '24px 24px',
        }}
      />

      <div className="max-w-6xl mx-auto space-y-8 relative z-10">
        {/* Top Header Bar */}
        <div className="bg-slate-900/80 backdrop-blur-md p-6 rounded-3xl border border-slate-800/80 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <ShieldAlert className="w-5 h-5 text-emerald-400" />
              <h2 className="text-lg font-bold text-white">AI UX Research & Persona Usability Audit</h2>
            </div>
            <p className="text-xs text-slate-400">
              Evaluated against Nielsen-Norman 10 Usability Heuristics, WCAG 2.2 AA accessibility, and cognitive friction models.
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={() => setShowThermalHeatmap(!showThermalHeatmap)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-all border ${
                showThermalHeatmap
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span>{showThermalHeatmap ? 'Heatmap Overlay: Active' : 'Heatmap Overlay: Off'}</span>
            </button>

            <button
              onClick={handleRunAudit}
              disabled={isLoading}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-600/30 flex items-center space-x-1.5 transition-all disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Auditing with Gemini...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Re-Run AI Persona Audit</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Personas Switcher */}
        {audits.length > 0 ? (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {audits.map((persona, idx) => {
                const isSelected = idx === selectedPersonaIdx;
                return (
                  <button
                    key={idx}
                    onClick={() => setSelectedPersonaIdx(idx)}
                    className={`p-4 rounded-2xl border text-left transition-all ${
                      isSelected
                        ? 'bg-slate-900 border-emerald-500 shadow-xl ring-2 ring-emerald-500/30'
                        : 'bg-slate-900/40 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2.5">
                        <span className="text-2xl">{persona.avatar || '👩‍💼'}</span>
                        <div>
                          <div className="font-bold text-xs text-white">{persona.personaName}</div>
                          <div className="text-[10px] text-slate-400">{persona.personaRole}</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-base font-black text-emerald-400">{persona.overallScore}/100</div>
                        <div className="text-[10px] text-slate-500 font-mono">Usability</div>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Active Persona Detailed Analysis */}
            {activePersona && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Left: Summary & Heuristics Breakdown */}
                <div className="lg:col-span-2 space-y-6">
                  {/* Summary Card */}
                  <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800/80 space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                        <span>Executive Usability Assessment</span>
                      </h3>
                      <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        Score: {activePersona.overallScore}/100
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      {activePersona.summary}
                    </p>
                  </div>

                  {/* Nielsen Heuristics Rating */}
                  <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800/80 space-y-4">
                    <h3 className="text-sm font-bold text-white">Nielsen Usability Heuristics Scoring</h3>
                    <div className="space-y-3">
                      {activePersona.heuristics?.map((h, idx) => (
                        <div key={idx} className="space-y-1 bg-slate-950/60 p-3 rounded-xl border border-slate-800/60">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-semibold text-slate-200">{h.name}</span>
                            <div className="flex items-center space-x-1">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <Star
                                  key={star}
                                  className={`w-3 h-3 ${
                                    star <= h.score ? 'text-amber-400 fill-amber-400' : 'text-slate-700'
                                  }`}
                                />
                              ))}
                              <span className="text-[11px] font-mono font-bold text-slate-400 ml-1">
                                {h.score}/5
                              </span>
                            </div>
                          </div>
                          <p className="text-[11px] text-slate-400 leading-normal">{h.note}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Right: Positives, Frictions, Recommendations & Heatmap */}
                <div className="space-y-6">
                  {/* Positives */}
                  <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800/80 space-y-3">
                    <div className="text-xs font-bold text-emerald-400 flex items-center space-x-2">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>UX Strengths & Highlights</span>
                    </div>
                    <div className="space-y-2">
                      {activePersona.positives?.map((pos, idx) => (
                        <div key={idx} className="text-xs text-slate-300 flex items-start space-x-2">
                          <span className="text-emerald-400 text-sm leading-none">•</span>
                          <span>{pos}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Friction Points */}
                  <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800/80 space-y-3">
                    <div className="text-xs font-bold text-rose-400 flex items-center space-x-2">
                      <AlertTriangle className="w-4 h-4" />
                      <span>Identified Friction Bottlenecks</span>
                    </div>
                    <div className="space-y-2">
                      {activePersona.frictionPoints?.map((fric, idx) => (
                        <div key={idx} className="text-xs text-slate-300 flex items-start space-x-2">
                          <span className="text-rose-400 text-sm leading-none">•</span>
                          <span>{fric}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Predicted Attention Heatmap */}
                  {activePersona.predictedHeatmapAreas && (
                    <div className="p-5 rounded-3xl bg-slate-900/80 border border-slate-800/80 space-y-3">
                      <div className="text-xs font-bold text-amber-400 flex items-center space-x-2">
                        <Flame className="w-4 h-4" />
                        <span>Predicted User Attention Heatmap</span>
                      </div>
                      <div className="space-y-2">
                        {activePersona.predictedHeatmapAreas.map((area, idx) => (
                          <div key={idx} className="space-y-1 bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                            <div className="flex items-center justify-between text-xs">
                              <span className="font-semibold text-slate-200">{area.label}</span>
                              <span className="text-amber-400 font-mono font-bold">{area.clickLikelihood}% CTR</span>
                            </div>
                            <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                              <div
                                className="h-full bg-gradient-to-r from-amber-500 to-rose-500"
                                style={{ width: `${area.clickLikelihood}%` }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="p-12 rounded-3xl bg-slate-900/50 border border-slate-800 text-center space-y-4">
            <div className="w-16 h-16 rounded-3xl bg-emerald-500/10 text-emerald-400 mx-auto flex items-center justify-center">
              <ShieldAlert className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-white">No Persona Audit Run Yet</h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Simulate UX researchers and real prospective users testing this prototype. Click below to analyze Nielsen heuristics and click heatmaps.
            </p>
            <button
              onClick={handleRunAudit}
              disabled={isLoading}
              className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-xl shadow-emerald-600/30"
            >
              Run AI Usability Audit
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
