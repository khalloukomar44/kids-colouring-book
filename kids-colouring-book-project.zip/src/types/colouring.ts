export type ToolMode = 'brush' | 'crayon' | 'rainbow' | 'sparkle' | 'fill' | 'eraser' | 'sticker';

export type BrushSize = 'small' | 'medium' | 'large' | 'giant';

export type StickerType = 'star' | 'heart' | 'paw' | 'flower' | 'rainbow' | 'sparkle' | 'crown' | 'balloon';

export interface AnimalPage {
  id: string;
  name: string;
  subtitle: string;
  emoji: string;
  category: 'safari' | 'pets' | 'ocean' | 'forest' | 'magical';
  badgeColor: string;
  soundName: string;
  funFact: string;
  svgDrawing: string; // SVG path data or full SVG markup for rendering outline
  defaultColors?: string[]; // Recommended starter color palette for this animal
}

export interface SavedArtwork {
  id: string;
  animalId: string;
  animalName: string;
  animalEmoji: string;
  dataUrl: string;
  createdAt: string;
  thumbnailUrl: string;
}
