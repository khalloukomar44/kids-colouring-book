package com.kids.colouringbook.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kids.colouringbook.data.AnimalData
import com.kids.colouringbook.model.ColorOption
import com.kids.colouringbook.model.StickerType
import com.kids.colouringbook.model.ToolMode
import com.kids.colouringbook.ui.theme.SlateText

@Composable
fun ColorPalette(
    selectedColorHex: Long,
    currentTool: ToolMode,
    selectedSticker: StickerType,
    defaultColors: List<Long>,
    onColorSelect: (Long) -> Unit,
    onToolSelect: (ToolMode) -> Unit,
    onStickerSelect: (StickerType) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFFFFBEB))
            .padding(vertical = 8.dp)
    ) {
        // Tool Mode Selection Bar (Brush, Crayon, Rainbow, Sparkle, Fill, Stickers)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ToolButton(
                emoji = "🖌️",
                label = "Paint",
                isSelected = currentTool == ToolMode.BRUSH,
                onClick = { onToolSelect(ToolMode.BRUSH) }
            )
            ToolButton(
                emoji = "🖍️",
                label = "Crayon",
                isSelected = currentTool == ToolMode.CRAYON,
                onClick = { onToolSelect(ToolMode.CRAYON) }
            )
            ToolButton(
                emoji = "🌈",
                label = "Rainbow",
                isSelected = currentTool == ToolMode.RAINBOW,
                onClick = { onToolSelect(ToolMode.RAINBOW) }
            )
            ToolButton(
                emoji = "✨",
                label = "Glitter",
                isSelected = currentTool == ToolMode.SPARKLE,
                onClick = { onToolSelect(ToolMode.SPARKLE) }
            )
            ToolButton(
                emoji = "🪣",
                label = "Fill",
                isSelected = currentTool == ToolMode.FILL,
                onClick = { onToolSelect(ToolMode.FILL) }
            )
            ToolButton(
                emoji = "⭐",
                label = "Stickers",
                isSelected = currentTool == ToolMode.STICKER,
                onClick = { onToolSelect(ToolMode.STICKER) }
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // If Sticker mode is active, show stickers row; otherwise show 24 colors palette
        if (currentTool == ToolMode.STICKER) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StickerType.values().forEach { sticker ->
                    val isSelected = selectedSticker == sticker
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .shadow(if (isSelected) 4.dp else 2.dp, CircleShape)
                            .clip(CircleShape)
                            .background(if (isSelected) Color(0xFFFEF3C7) else Color.White)
                            .border(
                                if (isSelected) 3.dp else 2.dp,
                                if (isSelected) Color(0xFFF59E0B) else Color(0xFFE2E8F0),
                                CircleShape
                            )
                            .clickable { onStickerSelect(sticker) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = sticker.emoji,
                            fontSize = 28.sp
                        )
                    }
                }
            }
        } else {
            // 24 Chunky Child-Friendly Color Circles in two scrollable rows
            val halfSize = AnimalData.COLORS.size / 2
            val row1 = AnimalData.COLORS.take(halfSize)
            val row2 = AnimalData.COLORS.drop(halfSize)

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    row1.forEach { colorOpt ->
                        ColorCircle(
                            colorOpt = colorOpt,
                            isSelected = selectedColorHex == colorOpt.colorHex && currentTool != ToolMode.ERASER,
                            onClick = { onColorSelect(colorOpt.colorHex) }
                        )
                    }
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    row2.forEach { colorOpt ->
                        ColorCircle(
                            colorOpt = colorOpt,
                            isSelected = selectedColorHex == colorOpt.colorHex && currentTool != ToolMode.ERASER,
                            onClick = { onColorSelect(colorOpt.colorHex) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolButton(
    emoji: String,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .height(38.dp)
            .shadow(if (isSelected) 3.dp else 1.dp, RoundedCornerShape(19.dp))
            .clip(RoundedCornerShape(19.dp))
            .background(
                if (isSelected) Brush.horizontalGradient(
                    listOf(Color(0xFFF59E0B), Color(0xFFEA580C))
                ) else Brush.horizontalGradient(
                    listOf(Color.White, Color.White)
                )
            )
            .border(
                2.dp,
                if (isSelected) Color(0xFFFDE68A) else Color(0xFFE2E8F0),
                RoundedCornerShape(19.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = emoji, fontSize = 16.sp)
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontWeight = FontWeight.Black,
                fontSize = 12.sp,
                color = if (isSelected) Color.White else SlateText
            )
        }
    }
}

@Composable
private fun ColorCircle(
    colorOpt: ColorOption,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val color = Color(colorOpt.colorHex)
    val isLightColor = colorOpt.colorHex == 0xFFFFFFFFL || colorOpt.colorHex == 0xFFFEF08AL

    Box(
        modifier = Modifier
            .size(38.dp)
            .shadow(if (isSelected) 4.dp else 2.dp, CircleShape)
            .clip(CircleShape)
            .background(color)
            .border(
                if (isSelected) 3.dp else 2.dp,
                if (isSelected) Color(0xFFF59E0B) else if (isLightColor) Color(0xFFCBD5E1) else Color.White,
                CircleShape
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (isSelected) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = "Selected Color",
                tint = if (isLightColor) Color(0xFF1E293B) else Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
