package com.kids.colouringbook.model

enum class BrushSize(val strokeWidth: Float, val label: String, val dotRadiusDp: Int) {
    SMALL(12f, "Fine", 4),
    MEDIUM(24f, "Medium", 8),
    LARGE(44f, "Thick", 12),
    GIANT(70f, "Giant", 16)
}
