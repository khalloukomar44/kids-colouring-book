package com.kids.colouringbook.model

enum class ToolMode(val label: String) {
    BRUSH("Paint Brush"),
    CRAYON("Crayon"),
    RAINBOW("Rainbow Magic"),
    SPARKLE("Glitter Sparkle"),
    FILL("Bucket Fill"),
    ERASER("Eraser"),
    STICKER("Sticker Stamp")
}
