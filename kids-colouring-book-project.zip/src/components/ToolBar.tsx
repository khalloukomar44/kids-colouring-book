import React from 'react';
import { ToolMode, BrushSize } from '../types/colouring';
import { sounds } from '../utils/soundEffects';
import { Undo2, Redo2, Trash2, Eraser } from 'lucide-react';

interface ToolBarProps {
  toolMode: ToolMode;
  onSelectToolMode: (mode: ToolMode) => void;
  brushSize: BrushSize;
  onSelectBrushSize: (size: BrushSize) => void;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  onClearClick: () => void;
}

export const ToolBar: React.FC<ToolBarProps> = ({
  toolMode,
  onSelectToolMode,
  brushSize,
  onSelectBrushSize,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  onClearClick,
}) => {
  const SIZES: { id: BrushSize; label: string; dotSize: string }[] = [
    { id: 'small', label: 'Fine', dotSize: 'w-2 h-2' },
    { id: 'medium', label: 'Medium', dotSize: 'w-3.5 h-3.5' },
    { id: 'large', label: 'Thick', dotSize: 'w-5 h-5' },
    { id: 'giant', label: 'Giant', dotSize: 'w-7 h-7' },
  ];

  return (
    <div className="w-full bg-white/95 backdrop-blur-md rounded-3xl p-2.5 sm:p-3.5 shadow-xl border-4 border-amber-200 ring-2 ring-amber-100 flex items-center justify-between gap-2">
      {/* Eraser Button */}
      <button
        onClick={() => {
          onSelectToolMode('eraser');
          sounds.playEraser();
        }}
        className={`flex items-center gap-1.5 px-3 sm:px-4 py-2.5 sm:py-3 rounded-2xl font-black text-sm sm:text-base btn-3d transition-all shrink-0 ${
          toolMode === 'eraser'
            ? 'bg-pink-500 text-white ring-4 ring-pink-300 scale-105 shadow-lg'
            : 'bg-pink-100 text-pink-700 hover:bg-pink-200'
        }`}
        title="Eraser tool"
      >
        <Eraser className="w-5 h-5 sm:w-6 sm:h-6" />
        <span className="hidden xs:inline">Eraser</span>
      </button>

      {/* Brush Size Selector */}
      <div className="flex items-center gap-1 sm:gap-2 bg-amber-50 p-1.5 rounded-2xl border border-amber-200">
        {SIZES.map((s) => {
          const isSelected = brushSize === s.id;
          return (
            <button
              key={s.id}
              onClick={() => {
                onSelectBrushSize(s.id);
                sounds.playPop(400);
              }}
              title={`${s.label} Brush`}
              className={`w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center btn-3d transition-all ${
                isSelected
                  ? 'bg-amber-500 text-white ring-2 ring-amber-300 scale-110 shadow-md'
                  : 'bg-white text-slate-700 hover:bg-amber-100'
              }`}
            >
              <div
                className={`${s.dotSize} rounded-full ${
                  isSelected ? 'bg-white' : 'bg-slate-700'
                }`}
              />
            </button>
          );
        })}
      </div>

      {/* Action Buttons: Undo, Redo, Clear */}
      <div className="flex items-center gap-1.5 sm:gap-2">
        {/* Undo */}
        <button
          onClick={() => {
            if (canUndo) onUndo();
          }}
          disabled={!canUndo}
          className={`p-2.5 sm:p-3 rounded-2xl btn-3d transition-all ${
            canUndo
              ? 'bg-amber-400 text-amber-950 hover:bg-amber-500 cursor-pointer'
              : 'bg-slate-100 text-slate-300 cursor-not-allowed opacity-50'
          }`}
          title="Undo last stroke"
        >
          <Undo2 className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2.5]" />
        </button>

        {/* Redo */}
        <button
          onClick={() => {
            if (canRedo) onRedo();
          }}
          disabled={!canRedo}
          className={`p-2.5 sm:p-3 rounded-2xl btn-3d transition-all ${
            canRedo
              ? 'bg-amber-400 text-amber-950 hover:bg-amber-500 cursor-pointer'
              : 'bg-slate-100 text-slate-300 cursor-not-allowed opacity-50'
          }`}
          title="Redo stroke"
        >
          <Redo2 className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2.5]" />
        </button>

        {/* Clear Canvas */}
        <button
          onClick={() => {
            sounds.playPop(300);
            onClearClick();
          }}
          className="p-2.5 sm:p-3 rounded-2xl bg-rose-100 text-rose-600 hover:bg-rose-500 hover:text-white btn-3d transition-all"
          title="Start fresh / clean page"
        >
          <Trash2 className="w-5 h-5 sm:w-6 sm:h-6 stroke-[2.5]" />
        </button>
      </div>
    </div>
  );
};
